﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Abm_Cliente
{
    public partial class frm_abmCliente : Form
    {
        string rol;
        string usuario;

        public frm_abmCliente(string user, string r)
        {
            this.usuario = user;
            this.rol = r;
            InitializeComponent();
        }

        private void btn_alta_Click(object sender, EventArgs e)
        {
            Abm_Cliente.Alta ac = new Abm_Cliente.Alta(usuario, rol);
            ac.Show();
        }

        private void btn_baja_Click(object sender, EventArgs e)
        {
            Abm_Cliente.Baja_Modificacion_de_Clientes bc = new Abm_Cliente.Baja_Modificacion_de_Clientes();
            bc.Show();
        }

        private void frm_abmCliente_Load(object sender, EventArgs e)
        {

        }
    }
}
