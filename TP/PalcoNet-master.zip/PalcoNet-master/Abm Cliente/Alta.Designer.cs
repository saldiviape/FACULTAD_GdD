﻿namespace PalcoNet.Abm_Cliente
{
    partial class Alta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_codigoPostal = new System.Windows.Forms.TextBox();
            this.lab_codigoPostal = new System.Windows.Forms.Label();
            this.btn_Limpiar = new System.Windows.Forms.Button();
            this.btn_Guardar = new System.Windows.Forms.Button();
            this.txt_localidad = new System.Windows.Forms.TextBox();
            this.lab_localidad = new System.Windows.Forms.Label();
            this.txt_depto = new System.Windows.Forms.TextBox();
            this.lab_depto = new System.Windows.Forms.Label();
            this.txt_piso = new System.Windows.Forms.TextBox();
            this.lab_piso = new System.Windows.Forms.Label();
            this.txt_direccion = new System.Windows.Forms.TextBox();
            this.lab_direccion = new System.Windows.Forms.Label();
            this.txt_telefono = new System.Windows.Forms.TextBox();
            this.lab_telefono = new System.Windows.Forms.Label();
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.lab_Nombre = new System.Windows.Forms.Label();
            this.txt_mail = new System.Windows.Forms.TextBox();
            this.lab_mail = new System.Windows.Forms.Label();
            this.txt_CUIL = new System.Windows.Forms.TextBox();
            this.lab_CUIL = new System.Windows.Forms.Label();
            this.txt_apellido = new System.Windows.Forms.TextBox();
            this.lab_apellido = new System.Windows.Forms.Label();
            this.txt_nroDoc = new System.Windows.Forms.TextBox();
            this.lab_nroDoc = new System.Windows.Forms.Label();
            this.lab_tipoDoc = new System.Windows.Forms.Label();
            this.cmb_tipoDoc = new System.Windows.Forms.ComboBox();
            this.dtp_fechaNac = new System.Windows.Forms.DateTimePicker();
            this.lab_fechaNac = new System.Windows.Forms.Label();
            this.dtp_fechaCreacion = new System.Windows.Forms.DateTimePicker();
            this.lab_fechaCreacion = new System.Windows.Forms.Label();
            this.chk_tarjeta = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // txt_codigoPostal
            // 
            this.txt_codigoPostal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_codigoPostal.Location = new System.Drawing.Point(229, 328);
            this.txt_codigoPostal.Margin = new System.Windows.Forms.Padding(4);
            this.txt_codigoPostal.Name = "txt_codigoPostal";
            this.txt_codigoPostal.Size = new System.Drawing.Size(351, 26);
            this.txt_codigoPostal.TabIndex = 311;
            // 
            // lab_codigoPostal
            // 
            this.lab_codigoPostal.AutoSize = true;
            this.lab_codigoPostal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_codigoPostal.Location = new System.Drawing.Point(96, 331);
            this.lab_codigoPostal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_codigoPostal.Name = "lab_codigoPostal";
            this.lab_codigoPostal.Size = new System.Drawing.Size(113, 20);
            this.lab_codigoPostal.TabIndex = 81;
            this.lab_codigoPostal.Text = "Codigo Postal";
            this.lab_codigoPostal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_Limpiar
            // 
            this.btn_Limpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Limpiar.Location = new System.Drawing.Point(47, 502);
            this.btn_Limpiar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Limpiar.Name = "btn_Limpiar";
            this.btn_Limpiar.Size = new System.Drawing.Size(235, 50);
            this.btn_Limpiar.TabIndex = 320;
            this.btn_Limpiar.Text = "Limpiar";
            this.btn_Limpiar.UseVisualStyleBackColor = true;
            this.btn_Limpiar.Click += new System.EventHandler(this.btn_Limpiar_Click);
            // 
            // btn_Guardar
            // 
            this.btn_Guardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Guardar.Location = new System.Drawing.Point(339, 502);
            this.btn_Guardar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Guardar.Name = "btn_Guardar";
            this.btn_Guardar.Size = new System.Drawing.Size(235, 50);
            this.btn_Guardar.TabIndex = 321;
            this.btn_Guardar.Text = "Guardar";
            this.btn_Guardar.UseVisualStyleBackColor = true;
            this.btn_Guardar.Click += new System.EventHandler(this.btn_Guardar_Click);
            // 
            // txt_localidad
            // 
            this.txt_localidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_localidad.Location = new System.Drawing.Point(229, 294);
            this.txt_localidad.Margin = new System.Windows.Forms.Padding(4);
            this.txt_localidad.Name = "txt_localidad";
            this.txt_localidad.Size = new System.Drawing.Size(351, 26);
            this.txt_localidad.TabIndex = 310;
            // 
            // lab_localidad
            // 
            this.lab_localidad.AutoSize = true;
            this.lab_localidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_localidad.Location = new System.Drawing.Point(128, 297);
            this.lab_localidad.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_localidad.Name = "lab_localidad";
            this.lab_localidad.Size = new System.Drawing.Size(81, 20);
            this.lab_localidad.TabIndex = 79;
            this.lab_localidad.Text = "Localidad";
            this.lab_localidad.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_depto
            // 
            this.txt_depto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_depto.Location = new System.Drawing.Point(391, 260);
            this.txt_depto.Margin = new System.Windows.Forms.Padding(4);
            this.txt_depto.Name = "txt_depto";
            this.txt_depto.Size = new System.Drawing.Size(189, 26);
            this.txt_depto.TabIndex = 309;
            // 
            // lab_depto
            // 
            this.lab_depto.AutoSize = true;
            this.lab_depto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_depto.Location = new System.Drawing.Point(325, 263);
            this.lab_depto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_depto.Name = "lab_depto";
            this.lab_depto.Size = new System.Drawing.Size(58, 20);
            this.lab_depto.TabIndex = 78;
            this.lab_depto.Text = "Depto.";
            this.lab_depto.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_piso
            // 
            this.txt_piso.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_piso.Location = new System.Drawing.Point(229, 260);
            this.txt_piso.Margin = new System.Windows.Forms.Padding(4);
            this.txt_piso.Name = "txt_piso";
            this.txt_piso.Size = new System.Drawing.Size(88, 26);
            this.txt_piso.TabIndex = 308;
            // 
            // lab_piso
            // 
            this.lab_piso.AutoSize = true;
            this.lab_piso.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_piso.Location = new System.Drawing.Point(167, 263);
            this.lab_piso.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_piso.Name = "lab_piso";
            this.lab_piso.Size = new System.Drawing.Size(42, 20);
            this.lab_piso.TabIndex = 77;
            this.lab_piso.Text = "Piso";
            this.lab_piso.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_direccion
            // 
            this.txt_direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_direccion.Location = new System.Drawing.Point(229, 226);
            this.txt_direccion.Margin = new System.Windows.Forms.Padding(4);
            this.txt_direccion.Name = "txt_direccion";
            this.txt_direccion.Size = new System.Drawing.Size(351, 26);
            this.txt_direccion.TabIndex = 307;
            // 
            // lab_direccion
            // 
            this.lab_direccion.AutoSize = true;
            this.lab_direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_direccion.Location = new System.Drawing.Point(128, 229);
            this.lab_direccion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_direccion.Name = "lab_direccion";
            this.lab_direccion.Size = new System.Drawing.Size(81, 20);
            this.lab_direccion.TabIndex = 76;
            this.lab_direccion.Text = "Direccion";
            this.lab_direccion.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_telefono
            // 
            this.txt_telefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_telefono.Location = new System.Drawing.Point(229, 191);
            this.txt_telefono.Margin = new System.Windows.Forms.Padding(4);
            this.txt_telefono.Name = "txt_telefono";
            this.txt_telefono.Size = new System.Drawing.Size(351, 26);
            this.txt_telefono.TabIndex = 306;
            // 
            // lab_telefono
            // 
            this.lab_telefono.AutoSize = true;
            this.lab_telefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_telefono.Location = new System.Drawing.Point(136, 194);
            this.lab_telefono.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_telefono.Name = "lab_telefono";
            this.lab_telefono.Size = new System.Drawing.Size(73, 20);
            this.lab_telefono.TabIndex = 73;
            this.lab_telefono.Text = "Teléfono";
            this.lab_telefono.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_nombre
            // 
            this.txt_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nombre.Location = new System.Drawing.Point(229, 22);
            this.txt_nombre.Margin = new System.Windows.Forms.Padding(4);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(351, 26);
            this.txt_nombre.TabIndex = 300;
            // 
            // lab_Nombre
            // 
            this.lab_Nombre.AutoSize = true;
            this.lab_Nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Nombre.Location = new System.Drawing.Point(141, 28);
            this.lab_Nombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_Nombre.Name = "lab_Nombre";
            this.lab_Nombre.Size = new System.Drawing.Size(68, 20);
            this.lab_Nombre.TabIndex = 67;
            this.lab_Nombre.Text = "Nombre";
            this.lab_Nombre.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_mail
            // 
            this.txt_mail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_mail.Location = new System.Drawing.Point(229, 157);
            this.txt_mail.Margin = new System.Windows.Forms.Padding(4);
            this.txt_mail.Name = "txt_mail";
            this.txt_mail.Size = new System.Drawing.Size(351, 26);
            this.txt_mail.TabIndex = 305;
            // 
            // lab_mail
            // 
            this.lab_mail.AutoSize = true;
            this.lab_mail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_mail.Location = new System.Drawing.Point(169, 160);
            this.lab_mail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_mail.Name = "lab_mail";
            this.lab_mail.Size = new System.Drawing.Size(40, 20);
            this.lab_mail.TabIndex = 64;
            this.lab_mail.Text = "Mail";
            this.lab_mail.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_CUIL
            // 
            this.txt_CUIL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CUIL.Location = new System.Drawing.Point(229, 124);
            this.txt_CUIL.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CUIL.Name = "txt_CUIL";
            this.txt_CUIL.Size = new System.Drawing.Size(351, 26);
            this.txt_CUIL.TabIndex = 304;
            // 
            // lab_CUIL
            // 
            this.lab_CUIL.AutoSize = true;
            this.lab_CUIL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_CUIL.Location = new System.Drawing.Point(162, 127);
            this.lab_CUIL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_CUIL.Name = "lab_CUIL";
            this.lab_CUIL.Size = new System.Drawing.Size(47, 20);
            this.lab_CUIL.TabIndex = 62;
            this.lab_CUIL.Text = "CUIL";
            this.lab_CUIL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_apellido
            // 
            this.txt_apellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_apellido.Location = new System.Drawing.Point(229, 56);
            this.txt_apellido.Margin = new System.Windows.Forms.Padding(4);
            this.txt_apellido.Name = "txt_apellido";
            this.txt_apellido.Size = new System.Drawing.Size(351, 26);
            this.txt_apellido.TabIndex = 301;
            // 
            // lab_apellido
            // 
            this.lab_apellido.AutoSize = true;
            this.lab_apellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_apellido.Location = new System.Drawing.Point(141, 59);
            this.lab_apellido.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_apellido.Name = "lab_apellido";
            this.lab_apellido.Size = new System.Drawing.Size(68, 20);
            this.lab_apellido.TabIndex = 85;
            this.lab_apellido.Text = "Apellido";
            this.lab_apellido.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_nroDoc
            // 
            this.txt_nroDoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nroDoc.Location = new System.Drawing.Point(382, 90);
            this.txt_nroDoc.Margin = new System.Windows.Forms.Padding(4);
            this.txt_nroDoc.Name = "txt_nroDoc";
            this.txt_nroDoc.Size = new System.Drawing.Size(198, 26);
            this.txt_nroDoc.TabIndex = 303;
            // 
            // lab_nroDoc
            // 
            this.lab_nroDoc.AutoSize = true;
            this.lab_nroDoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_nroDoc.Location = new System.Drawing.Point(338, 93);
            this.lab_nroDoc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_nroDoc.Name = "lab_nroDoc";
            this.lab_nroDoc.Size = new System.Drawing.Size(36, 20);
            this.lab_nroDoc.TabIndex = 87;
            this.lab_nroDoc.Text = "Nro";
            this.lab_nroDoc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lab_tipoDoc
            // 
            this.lab_tipoDoc.AutoSize = true;
            this.lab_tipoDoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_tipoDoc.Location = new System.Drawing.Point(168, 93);
            this.lab_tipoDoc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_tipoDoc.Name = "lab_tipoDoc";
            this.lab_tipoDoc.Size = new System.Drawing.Size(41, 20);
            this.lab_tipoDoc.TabIndex = 88;
            this.lab_tipoDoc.Text = "Tipo";
            this.lab_tipoDoc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmb_tipoDoc
            // 
            this.cmb_tipoDoc.FormattingEnabled = true;
            this.cmb_tipoDoc.Items.AddRange(new object[] {
            "DNI",
            "LC",
            "LE"});
            this.cmb_tipoDoc.Location = new System.Drawing.Point(229, 90);
            this.cmb_tipoDoc.Name = "cmb_tipoDoc";
            this.cmb_tipoDoc.Size = new System.Drawing.Size(88, 24);
            this.cmb_tipoDoc.TabIndex = 302;
            // 
            // dtp_fechaNac
            // 
            this.dtp_fechaNac.CustomFormat = "yyyy/MM/dd HH:mm:ss";
            this.dtp_fechaNac.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_fechaNac.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_fechaNac.Location = new System.Drawing.Point(229, 364);
            this.dtp_fechaNac.Margin = new System.Windows.Forms.Padding(4);
            this.dtp_fechaNac.Name = "dtp_fechaNac";
            this.dtp_fechaNac.Size = new System.Drawing.Size(351, 26);
            this.dtp_fechaNac.TabIndex = 312;
            // 
            // lab_fechaNac
            // 
            this.lab_fechaNac.AutoSize = true;
            this.lab_fechaNac.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_fechaNac.Location = new System.Drawing.Point(92, 369);
            this.lab_fechaNac.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_fechaNac.Name = "lab_fechaNac";
            this.lab_fechaNac.Size = new System.Drawing.Size(117, 20);
            this.lab_fechaNac.TabIndex = 91;
            this.lab_fechaNac.Text = "Fecha de Nac.";
            this.lab_fechaNac.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dtp_fechaCreacion
            // 
            this.dtp_fechaCreacion.CustomFormat = "yyyy/MM/dd HH:mm:ss";
            this.dtp_fechaCreacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_fechaCreacion.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_fechaCreacion.Location = new System.Drawing.Point(229, 398);
            this.dtp_fechaCreacion.Margin = new System.Windows.Forms.Padding(4);
            this.dtp_fechaCreacion.Name = "dtp_fechaCreacion";
            this.dtp_fechaCreacion.Size = new System.Drawing.Size(351, 26);
            this.dtp_fechaCreacion.TabIndex = 313;
            // 
            // lab_fechaCreacion
            // 
            this.lab_fechaCreacion.AutoSize = true;
            this.lab_fechaCreacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_fechaCreacion.Location = new System.Drawing.Point(59, 403);
            this.lab_fechaCreacion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_fechaCreacion.Name = "lab_fechaCreacion";
            this.lab_fechaCreacion.Size = new System.Drawing.Size(150, 20);
            this.lab_fechaCreacion.TabIndex = 105;
            this.lab_fechaCreacion.Text = "Fecha de Creacion";
            this.lab_fechaCreacion.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // chk_tarjeta
            // 
            this.chk_tarjeta.AutoSize = true;
            this.chk_tarjeta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.chk_tarjeta.Location = new System.Drawing.Point(132, 453);
            this.chk_tarjeta.Name = "chk_tarjeta";
            this.chk_tarjeta.Size = new System.Drawing.Size(397, 22);
            this.chk_tarjeta.TabIndex = 322;
            this.chk_tarjeta.Text = "Click aquí si desea asociar una tarjeta de credito";
            this.chk_tarjeta.UseVisualStyleBackColor = true;
            // 
            // Alta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(643, 579);
            this.Controls.Add(this.chk_tarjeta);
            this.Controls.Add(this.dtp_fechaCreacion);
            this.Controls.Add(this.lab_fechaCreacion);
            this.Controls.Add(this.dtp_fechaNac);
            this.Controls.Add(this.lab_fechaNac);
            this.Controls.Add(this.cmb_tipoDoc);
            this.Controls.Add(this.lab_tipoDoc);
            this.Controls.Add(this.txt_nroDoc);
            this.Controls.Add(this.lab_nroDoc);
            this.Controls.Add(this.txt_apellido);
            this.Controls.Add(this.lab_apellido);
            this.Controls.Add(this.txt_codigoPostal);
            this.Controls.Add(this.lab_codigoPostal);
            this.Controls.Add(this.btn_Limpiar);
            this.Controls.Add(this.btn_Guardar);
            this.Controls.Add(this.txt_localidad);
            this.Controls.Add(this.lab_localidad);
            this.Controls.Add(this.txt_depto);
            this.Controls.Add(this.lab_depto);
            this.Controls.Add(this.txt_piso);
            this.Controls.Add(this.lab_piso);
            this.Controls.Add(this.txt_direccion);
            this.Controls.Add(this.lab_direccion);
            this.Controls.Add(this.txt_telefono);
            this.Controls.Add(this.lab_telefono);
            this.Controls.Add(this.txt_nombre);
            this.Controls.Add(this.lab_Nombre);
            this.Controls.Add(this.txt_mail);
            this.Controls.Add(this.lab_mail);
            this.Controls.Add(this.txt_CUIL);
            this.Controls.Add(this.lab_CUIL);
            this.Name = "Alta";
            this.Text = "Alta de Cliente";
            this.Load += new System.EventHandler(this.Alta_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_codigoPostal;
        private System.Windows.Forms.Label lab_codigoPostal;
        private System.Windows.Forms.Button btn_Limpiar;
        private System.Windows.Forms.Button btn_Guardar;
        private System.Windows.Forms.TextBox txt_localidad;
        private System.Windows.Forms.Label lab_localidad;
        private System.Windows.Forms.TextBox txt_depto;
        private System.Windows.Forms.Label lab_depto;
        private System.Windows.Forms.TextBox txt_piso;
        private System.Windows.Forms.Label lab_piso;
        private System.Windows.Forms.TextBox txt_direccion;
        private System.Windows.Forms.Label lab_direccion;
        private System.Windows.Forms.TextBox txt_telefono;
        private System.Windows.Forms.Label lab_telefono;
        private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.Label lab_Nombre;
        private System.Windows.Forms.TextBox txt_mail;
        private System.Windows.Forms.Label lab_mail;
        private System.Windows.Forms.TextBox txt_CUIL;
        private System.Windows.Forms.Label lab_CUIL;
        private System.Windows.Forms.TextBox txt_apellido;
        private System.Windows.Forms.Label lab_apellido;
        private System.Windows.Forms.TextBox txt_nroDoc;
        private System.Windows.Forms.Label lab_nroDoc;
        private System.Windows.Forms.Label lab_tipoDoc;
        private System.Windows.Forms.ComboBox cmb_tipoDoc;
        private System.Windows.Forms.DateTimePicker dtp_fechaNac;
        private System.Windows.Forms.Label lab_fechaNac;
        private System.Windows.Forms.DateTimePicker dtp_fechaCreacion;
        private System.Windows.Forms.Label lab_fechaCreacion;
        private System.Windows.Forms.CheckBox chk_tarjeta;
    }
}