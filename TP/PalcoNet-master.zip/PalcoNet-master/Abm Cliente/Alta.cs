﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PalcoNet.libreria;

namespace PalcoNet.Abm_Cliente
{
    public partial class Alta : Form
    {
        string usuario;
        string rol;

        public Alta(string user, string r)
        {
            this.usuario = user;
            this.rol = r;
            InitializeComponent();
        }

        private void btn_Limpiar_Click(object sender, EventArgs e)
        {
            Limpiar limpiar = new Limpiar();
            limpiar.limpiarCampos(this);
        }

        private bool altaCliente()
        {
            string consultaIdRol = string.Format("SELECT idRol FROM DATEROS.rol WHERE nombre = '" + rol + "'");
            DataSet dscr = Utilidades.ejecutar(consultaIdRol);
            string idRol = dscr.Tables[0].Rows[0]["idRol"].ToString();

            if ((Convert.ToDateTime(dtp_fechaNac.Value) <  Properties.Settings.Default.FechaDelSistema) & (Convert.ToDateTime(dtp_fechaCreacion.Value) < Properties.Settings.Default.FechaDelSistema))
                if (rol == "Administrativo")
                {
                    try
                    {
                        string cmd = string.Format("EXEC DATEROS.altaClienteAdmin '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}'", txt_nombre.Text.Trim(), txt_apellido.Text.Trim(), cmb_tipoDoc.Text.Trim(), txt_nroDoc.Text.Trim(), txt_CUIL.Text.Trim(), txt_mail.Text.Trim(), txt_telefono.Text.Trim(), txt_direccion.Text.Trim(), txt_piso.Text.Trim(), txt_depto.Text.Trim(), txt_localidad.Text.Trim(), txt_codigoPostal.Text.Trim(), Convert.ToDateTime(dtp_fechaNac.Value.ToString()), Convert.ToDateTime(dtp_fechaCreacion.Value.ToString()));
                        libreria.Utilidades.ejecutar(cmd);
                        MessageBox.Show("Se ha creado correctamente el nuevo cliente");
                        this.Hide();
                        return true;
                    }
                    catch (Exception error)
                    {
                        MessageBox.Show("Ha ocurrido un error: " + error.Message);
                        return false;
                    }
                }
                else
                    try
                    {
                        string cmd = string.Format("EXEC DATEROS.altaCliente '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', '{14}', '{15}'", txt_nombre.Text.Trim(), txt_apellido.Text.Trim(), cmb_tipoDoc.Text.Trim(), txt_nroDoc.Text.Trim(), txt_CUIL.Text.Trim(), txt_mail.Text.Trim(), txt_telefono.Text.Trim(), txt_direccion.Text.Trim(), txt_piso.Text.Trim(), txt_depto.Text.Trim(), txt_localidad.Text.Trim(), txt_codigoPostal.Text.Trim(), Convert.ToDateTime(dtp_fechaNac.Value.ToString()), Convert.ToDateTime(dtp_fechaCreacion.Value.ToString()), usuario, idRol);
                        libreria.Utilidades.ejecutar(cmd);
                        MessageBox.Show("Se ha creado correctamente el nuevo cliente");
                        this.Hide();
                        return true;
                    }
                    catch (Exception error)
                    {
                        MessageBox.Show("Ha ocurrido un error: " + error.Message);
                        return false;
                    }
            else
                MessageBox.Show("Por favor verifique las fechas");
                return false;
        }

        private void btn_Guardar_Click(object sender, EventArgs e)
        {
            if (chk_tarjeta.Checked)
            {
                if (this.altaCliente())
                {
                    string consultaUsername = string.Format("SELECT username FROM DATEROS.clientes WHERE docNum = '" + txt_nroDoc.Text + "' AND cuil = '" + txt_CUIL.Text + "'");
                    DataSet dscl = Utilidades.ejecutar(consultaUsername);
                    string username = dscl.Tables[0].Rows[0]["username"].ToString();

                    Comprar.Alta_Tarjeta at = new Comprar.Alta_Tarjeta(username);
                    at.Show();
                }
            }
            else
            {
                this.altaCliente();
            }      
        }

        private void Alta_Load(object sender, EventArgs e)
        {
            cmb_tipoDoc.DropDownStyle = ComboBoxStyle.DropDownList;
        }
    }
}
