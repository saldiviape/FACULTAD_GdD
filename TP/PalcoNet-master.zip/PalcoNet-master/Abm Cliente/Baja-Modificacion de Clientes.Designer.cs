﻿namespace PalcoNet.Abm_Cliente
{
    partial class Baja_Modificacion_de_Clientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.chk_nombre = new System.Windows.Forms.CheckBox();
            this.chk_apellido = new System.Windows.Forms.CheckBox();
            this.chk_dni = new System.Windows.Forms.CheckBox();
            this.txt_apellido = new System.Windows.Forms.TextBox();
            this.txt_dni = new System.Windows.Forms.TextBox();
            this.btn_baja = new System.Windows.Forms.Button();
            this.btn_modificar = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_Limpiar = new System.Windows.Forms.Button();
            this.btn_Buscar = new System.Windows.Forms.Button();
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.chk_email = new System.Windows.Forms.CheckBox();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.btn_habilitar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // chk_nombre
            // 
            this.chk_nombre.AutoSize = true;
            this.chk_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_nombre.Location = new System.Drawing.Point(87, 66);
            this.chk_nombre.Margin = new System.Windows.Forms.Padding(4);
            this.chk_nombre.Name = "chk_nombre";
            this.chk_nombre.Size = new System.Drawing.Size(90, 24);
            this.chk_nombre.TabIndex = 126;
            this.chk_nombre.Text = "Nombre";
            this.chk_nombre.UseVisualStyleBackColor = true;
            // 
            // chk_apellido
            // 
            this.chk_apellido.AutoSize = true;
            this.chk_apellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_apellido.Location = new System.Drawing.Point(87, 100);
            this.chk_apellido.Margin = new System.Windows.Forms.Padding(4);
            this.chk_apellido.Name = "chk_apellido";
            this.chk_apellido.Size = new System.Drawing.Size(90, 24);
            this.chk_apellido.TabIndex = 125;
            this.chk_apellido.Text = "Apellido";
            this.chk_apellido.UseVisualStyleBackColor = true;
            // 
            // chk_dni
            // 
            this.chk_dni.AutoSize = true;
            this.chk_dni.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_dni.Location = new System.Drawing.Point(87, 134);
            this.chk_dni.Margin = new System.Windows.Forms.Padding(4);
            this.chk_dni.Name = "chk_dni";
            this.chk_dni.Size = new System.Drawing.Size(60, 24);
            this.chk_dni.TabIndex = 124;
            this.chk_dni.Text = "DNI";
            this.chk_dni.UseVisualStyleBackColor = true;
            // 
            // txt_apellido
            // 
            this.txt_apellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_apellido.Location = new System.Drawing.Point(238, 98);
            this.txt_apellido.Margin = new System.Windows.Forms.Padding(4);
            this.txt_apellido.Name = "txt_apellido";
            this.txt_apellido.Size = new System.Drawing.Size(389, 26);
            this.txt_apellido.TabIndex = 123;
            // 
            // txt_dni
            // 
            this.txt_dni.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_dni.Location = new System.Drawing.Point(238, 132);
            this.txt_dni.Margin = new System.Windows.Forms.Padding(4);
            this.txt_dni.Name = "txt_dni";
            this.txt_dni.Size = new System.Drawing.Size(389, 26);
            this.txt_dni.TabIndex = 122;
            // 
            // btn_baja
            // 
            this.btn_baja.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_baja.Location = new System.Drawing.Point(145, 542);
            this.btn_baja.Margin = new System.Windows.Forms.Padding(4);
            this.btn_baja.Name = "btn_baja";
            this.btn_baja.Size = new System.Drawing.Size(235, 50);
            this.btn_baja.TabIndex = 121;
            this.btn_baja.Text = "Dar De Baja";
            this.btn_baja.UseVisualStyleBackColor = true;
            this.btn_baja.Click += new System.EventHandler(this.btn_baja_Click);
            // 
            // btn_modificar
            // 
            this.btn_modificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_modificar.Location = new System.Drawing.Point(403, 542);
            this.btn_modificar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_modificar.Name = "btn_modificar";
            this.btn_modificar.Size = new System.Drawing.Size(235, 50);
            this.btn_modificar.TabIndex = 120;
            this.btn_modificar.Text = "Modificar Datos";
            this.btn_modificar.UseVisualStyleBackColor = true;
            this.btn_modificar.Click += new System.EventHandler(this.btn_modificar_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(35, 279);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(707, 247);
            this.dataGridView1.TabIndex = 119;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(31, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(283, 24);
            this.label1.TabIndex = 118;
            this.label1.Text = "Seleccionar Filtros de Búsqueda";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_Limpiar
            // 
            this.btn_Limpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Limpiar.Location = new System.Drawing.Point(35, 212);
            this.btn_Limpiar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Limpiar.Name = "btn_Limpiar";
            this.btn_Limpiar.Size = new System.Drawing.Size(235, 50);
            this.btn_Limpiar.TabIndex = 117;
            this.btn_Limpiar.Text = "Limpiar";
            this.btn_Limpiar.UseVisualStyleBackColor = true;
            this.btn_Limpiar.Click += new System.EventHandler(this.btn_Limpiar_Click);
            // 
            // btn_Buscar
            // 
            this.btn_Buscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Buscar.Location = new System.Drawing.Point(507, 212);
            this.btn_Buscar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Buscar.Name = "btn_Buscar";
            this.btn_Buscar.Size = new System.Drawing.Size(235, 50);
            this.btn_Buscar.TabIndex = 116;
            this.btn_Buscar.Text = "Buscar";
            this.btn_Buscar.UseVisualStyleBackColor = true;
            this.btn_Buscar.Click += new System.EventHandler(this.btn_Buscar_Click);
            // 
            // txt_nombre
            // 
            this.txt_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nombre.Location = new System.Drawing.Point(238, 64);
            this.txt_nombre.Margin = new System.Windows.Forms.Padding(4);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(389, 26);
            this.txt_nombre.TabIndex = 115;
            // 
            // chk_email
            // 
            this.chk_email.AutoSize = true;
            this.chk_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_email.Location = new System.Drawing.Point(87, 168);
            this.chk_email.Margin = new System.Windows.Forms.Padding(4);
            this.chk_email.Name = "chk_email";
            this.chk_email.Size = new System.Drawing.Size(73, 24);
            this.chk_email.TabIndex = 128;
            this.chk_email.Text = "Email";
            this.chk_email.UseVisualStyleBackColor = true;
            // 
            // txt_email
            // 
            this.txt_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_email.Location = new System.Drawing.Point(238, 166);
            this.txt_email.Margin = new System.Windows.Forms.Padding(4);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(389, 26);
            this.txt_email.TabIndex = 127;
            // 
            // btn_habilitar
            // 
            this.btn_habilitar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_habilitar.Location = new System.Drawing.Point(275, 605);
            this.btn_habilitar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_habilitar.Name = "btn_habilitar";
            this.btn_habilitar.Size = new System.Drawing.Size(235, 50);
            this.btn_habilitar.TabIndex = 129;
            this.btn_habilitar.Text = "Habilitacion Clientes";
            this.btn_habilitar.UseVisualStyleBackColor = true;
            this.btn_habilitar.Click += new System.EventHandler(this.btn_habilitar_Click);
            // 
            // Baja_Modificacion_de_Clientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(773, 664);
            this.Controls.Add(this.btn_habilitar);
            this.Controls.Add(this.chk_email);
            this.Controls.Add(this.txt_email);
            this.Controls.Add(this.chk_nombre);
            this.Controls.Add(this.chk_apellido);
            this.Controls.Add(this.chk_dni);
            this.Controls.Add(this.txt_apellido);
            this.Controls.Add(this.txt_dni);
            this.Controls.Add(this.btn_baja);
            this.Controls.Add(this.btn_modificar);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Limpiar);
            this.Controls.Add(this.btn_Buscar);
            this.Controls.Add(this.txt_nombre);
            this.Name = "Baja_Modificacion_de_Clientes";
            this.Text = "Baja y Modificacion de Clientes";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox chk_nombre;
        private System.Windows.Forms.CheckBox chk_apellido;
        private System.Windows.Forms.CheckBox chk_dni;
        private System.Windows.Forms.TextBox txt_apellido;
        private System.Windows.Forms.TextBox txt_dni;
        private System.Windows.Forms.Button btn_baja;
        private System.Windows.Forms.Button btn_modificar;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Limpiar;
        private System.Windows.Forms.Button btn_Buscar;
        private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.CheckBox chk_email;
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.Button btn_habilitar;
    }
}