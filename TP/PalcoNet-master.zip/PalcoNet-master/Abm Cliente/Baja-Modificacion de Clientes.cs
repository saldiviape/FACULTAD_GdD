﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Abm_Cliente
{
    public partial class Baja_Modificacion_de_Clientes : Form
    {
        comandos cma = new comandos();

        public Baja_Modificacion_de_Clientes()
        {
            InitializeComponent();
        }

        private void btn_Limpiar_Click(object sender, EventArgs e)
        {
            Limpiar limpiar = new Limpiar();
            limpiar.limpiarCampos(this);
        }

        private void btn_Buscar_Click(object sender, EventArgs e)
        {
            if (chk_apellido.Checked & chk_dni.Checked & chk_email.Checked & chk_nombre.Checked)
            {
                cma.llenarDataGridView(dataGridView1, "SELECT nombre, apellido, docTipo, docNum, mail, c.username FROM DATEROS.clientes c, DATEROS.usuario u WHERE nombre LIKE '" + txt_nombre.Text + "' + '%' AND apellido LIKE '" + txt_apellido.Text + "' + '%' AND mail LIKE '" + txt_email.Text + "' + '%' AND docNum = '" + txt_dni.Text + "' AND c.username=u.username AND u.estado != 'Dado De Baja'");
            }
            else
            {
                if (chk_apellido.Checked & chk_dni.Checked & chk_email.Checked)
                {
                    cma.llenarDataGridView(dataGridView1, "SELECT nombre, apellido, docTipo, docNum, mail, c.username FROM DATEROS.clientes c, DATEROS.usuario u WHERE apellido LIKE '" + txt_apellido.Text + "' + '%' AND mail LIKE '" + txt_email.Text + "' + '%' AND docNum = '" + txt_dni.Text + "' AND c.username=u.username AND u.estado != 'Dado De Baja'");
                }

                if (chk_apellido.Checked & chk_dni.Checked & chk_nombre.Checked)
                {
                    cma.llenarDataGridView(dataGridView1, "SELECT nombre, apellido, docTipo, docNum, mail, c.username FROM DATEROS.clientes c, DATEROS.usuario u WHERE nombre LIKE '" + txt_nombre.Text + "' + '%' AND apellido LIKE '" + txt_apellido.Text + "' + '%' AND docNum = '" + txt_dni.Text + "' AND c.username=u.username AND u.estado != 'Dado De Baja'");
                }
                
                if (chk_apellido.Checked & chk_email.Checked & chk_nombre.Checked)
                {
                    cma.llenarDataGridView(dataGridView1, "SELECT nombre, apellido, docTipo, docNum, mail, c.username FROM DATEROS.clientes c, DATEROS.usuario u WHERE nombre LIKE '" + txt_nombre.Text + "' + '%' AND apellido LIKE '" + txt_apellido.Text + "' + '%' AND mail LIKE '" + txt_email.Text + "' + '%' AND c.username=u.username AND u.estado != 'Dado De Baja'");
                }         

                if (chk_dni.Checked & chk_email.Checked & chk_nombre.Checked)
                {
                    cma.llenarDataGridView(dataGridView1, "SELECT nombre, apellido, docTipo, docNum, mail, c.username FROM DATEROS.clientes c, DATEROS.usuario u WHERE nombre LIKE '" + txt_nombre.Text + "' + '%' AND mail LIKE '" + txt_email.Text + "' + '%' AND docNum = '" + txt_dni.Text + "' AND c.username=u.username AND u.estado != 'Dado De Baja'");
                }

                if (chk_apellido.Checked & !chk_dni.Checked & !chk_email.Checked & chk_nombre.Checked)
                {
                    cma.llenarDataGridView(dataGridView1, "SELECT nombre, apellido, docTipo, docNum, mail, c.username FROM DATEROS.clientes c, DATEROS.usuario u WHERE nombre LIKE '" + txt_nombre.Text + "' + '%' AND apellido LIKE '" + txt_apellido.Text + "' + '%' AND c.username=u.username AND u.estado != 'Dado De Baja'");
                }

                if (!chk_apellido.Checked & !chk_dni.Checked & chk_email.Checked & chk_nombre.Checked)
                {
                    cma.llenarDataGridView(dataGridView1, "SELECT nombre, apellido, docTipo, docNum, mail, c.username FROM DATEROS.clientes c, DATEROS.usuario u WHERE nombre LIKE '" + txt_nombre.Text + "' + '%' AND mail LIKE '" + txt_email.Text + "' + '%' AND c.username=u.username AND u.estado != 'Dado De Baja'");
                }

                if (!chk_apellido.Checked & chk_dni.Checked & !chk_email.Checked & chk_nombre.Checked)
                {
                    cma.llenarDataGridView(dataGridView1, "SELECT nombre, apellido, docTipo, docNum, mail, c.username FROM DATEROS.clientes c, DATEROS.usuario u WHERE nombre LIKE '" + txt_nombre.Text + "' + '%' AND docNum = '" + txt_dni.Text + "' AND c.username=u.username AND u.estado != 'Dado De Baja'");
                }

                if (chk_apellido.Checked & !chk_dni.Checked & chk_email.Checked & !chk_nombre.Checked)
                {
                    cma.llenarDataGridView(dataGridView1, "SELECT nombre, apellido, docTipo, docNum, mail, c.username FROM DATEROS.clientes c, DATEROS.usuario u WHERE apellido LIKE '" + txt_apellido.Text + "' + '%' AND mail LIKE '" + txt_email.Text + "' + '%' AND c.username=u.username AND u.estado != 'Dado De Baja'");
                }

                if (chk_apellido.Checked & chk_dni.Checked & !chk_email.Checked & !chk_nombre.Checked)
                {
                    cma.llenarDataGridView(dataGridView1, "SELECT nombre, apellido, docTipo, docNum, mail, c.username FROM DATEROS.clientes c, DATEROS.usuario u WHERE apellido LIKE '" + txt_apellido.Text + "' + '%' AND docNum = '" + txt_dni.Text + "' AND c.username=u.username AND u.estado != 'Dado De Baja'");
                }

                if (!chk_apellido.Checked & chk_dni.Checked & chk_email.Checked & !chk_nombre.Checked)
                {
                    cma.llenarDataGridView(dataGridView1, "SELECT nombre, apellido, docTipo, docNum, mail, c.username FROM DATEROS.clientes c, DATEROS.usuario u WHERE mail LIKE '" + txt_email.Text + "' + '%' AND docNum = '" + txt_dni.Text + "' AND c.username=u.username AND u.estado != 'Dado De Baja'");
                }

                if (chk_apellido.Checked & !chk_dni.Checked & !chk_email.Checked & !chk_nombre.Checked)
                {
                    cma.llenarDataGridView(dataGridView1, "SELECT nombre, apellido, docTipo, docNum, mail, c.username FROM DATEROS.clientes c, DATEROS.usuario u WHERE apellido LIKE '" + txt_apellido.Text + "' + '%' AND c.username=u.username AND u.estado != 'Dado De Baja'");
                }

                if (!chk_apellido.Checked & chk_dni.Checked & !chk_email.Checked & !chk_nombre.Checked)
                {
                    cma.llenarDataGridView(dataGridView1, "SELECT nombre, apellido, docTipo, docNum, mail, c.username FROM DATEROS.clientes c, DATEROS.usuario u WHERE docNum = '" + txt_dni.Text + "' AND c.username=u.username AND u.estado != 'Dado De Baja'");
                }

                if (!chk_apellido.Checked & !chk_dni.Checked & chk_email.Checked & !chk_nombre.Checked)
                {
                    cma.llenarDataGridView(dataGridView1, "SELECT nombre, apellido, docTipo, docNum, mail, c.username FROM DATEROS.clientes c, DATEROS.usuario u WHERE mail LIKE '" + txt_email.Text + "' + '%' AND c.username=u.username AND u.estado != 'Dado De Baja'");
                }

                if (!chk_apellido.Checked & !chk_dni.Checked & !chk_email.Checked & chk_nombre.Checked)
                {
                    cma.llenarDataGridView(dataGridView1, "SELECT nombre, apellido, docTipo, docNum, mail, c.username FROM DATEROS.clientes c, DATEROS.usuario u WHERE nombre LIKE '" + txt_nombre.Text + "' + '%' AND c.username=u.username AND u.estado != 'Dado De Baja'");
                }

                if (!chk_apellido.Checked & !chk_dni.Checked & !chk_email.Checked & !chk_nombre.Checked)
                {
                    cma.llenarDataGridView(dataGridView1, "SELECT nombre, apellido, docTipo, docNum, mail, c.username FROM DATEROS.clientes c, DATEROS.usuario u WHERE c.username=u.username AND u.estado != 'Dado De Baja'");
                }
            }
        }

        private bool bajaCliente()
        {
            try
            {
                string cmd = string.Format("EXEC DATEROS.bajaUsuario '{0}'", dataGridView1.CurrentRow.Cells[5].Value.ToString());
                libreria.Utilidades.ejecutar(cmd);

                MessageBox.Show("Se ha dado de baja el usuario");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_baja_Click(object sender, EventArgs e)
        {
            this.bajaCliente();
        }

        private void btn_habilitar_Click(object sender, EventArgs e)
        {
            Abm_Cliente.Clientes_Deshabilitados cd = new Abm_Cliente.Clientes_Deshabilitados();
            cd.Show();
        }

        private void btn_modificar_Click(object sender, EventArgs e)
        {
            Abm_Cliente.Modificacion mc = new Abm_Cliente.Modificacion(dataGridView1.CurrentRow.Cells[2].Value.ToString(), dataGridView1.CurrentRow.Cells[3].Value.ToString());
            mc.Show();
        }
    }
}
