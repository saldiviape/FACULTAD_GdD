﻿namespace PalcoNet.Abm_Cliente
{
    partial class Clientes_Deshabilitados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_habilitar = new System.Windows.Forms.Button();
            this.btn_empresasInhabilitadas = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_habilitar
            // 
            this.btn_habilitar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.btn_habilitar.Location = new System.Drawing.Point(170, 377);
            this.btn_habilitar.Name = "btn_habilitar";
            this.btn_habilitar.Size = new System.Drawing.Size(426, 46);
            this.btn_habilitar.TabIndex = 109;
            this.btn_habilitar.Text = "Habilitar";
            this.btn_habilitar.UseVisualStyleBackColor = true;
            this.btn_habilitar.Click += new System.EventHandler(this.btn_habilitar_Click);
            // 
            // btn_empresasInhabilitadas
            // 
            this.btn_empresasInhabilitadas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.btn_empresasInhabilitadas.Location = new System.Drawing.Point(170, 22);
            this.btn_empresasInhabilitadas.Name = "btn_empresasInhabilitadas";
            this.btn_empresasInhabilitadas.Size = new System.Drawing.Size(426, 46);
            this.btn_empresasInhabilitadas.TabIndex = 108;
            this.btn_empresasInhabilitadas.Text = "Click aqui para ver clientes dados de baja";
            this.btn_empresasInhabilitadas.UseVisualStyleBackColor = true;
            this.btn_empresasInhabilitadas.Click += new System.EventHandler(this.btn_empresasInhabilitadas_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(21, 108);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(707, 247);
            this.dataGridView1.TabIndex = 107;
            // 
            // Clientes_Deshabilitados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(752, 448);
            this.Controls.Add(this.btn_habilitar);
            this.Controls.Add(this.btn_empresasInhabilitadas);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Clientes_Deshabilitados";
            this.Text = "Clientes Deshabilitados";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_habilitar;
        private System.Windows.Forms.Button btn_empresasInhabilitadas;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}