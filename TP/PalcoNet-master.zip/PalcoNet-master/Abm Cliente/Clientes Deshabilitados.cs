﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Abm_Cliente
{
    public partial class Clientes_Deshabilitados : Form
    {
        comandos cma = new comandos();

        public Clientes_Deshabilitados()
        {
            InitializeComponent();
        }

        private void btn_empresasInhabilitadas_Click(object sender, EventArgs e)
        {
            try
            {
                cma.llenarDataGridView(dataGridView1, "SELECT nombre, apellido, docNum, c.username FROM DATEROS.clientes c, DATEROS.usuario u WHERE c.username=u.username AND u.estado = 'Dado De Baja'");
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
            }
        }

        private bool habilitarCliente()
        {
            try
            {
                string cmd = string.Format("EXEC DATEROS.habilitarUsuario '{0}'", dataGridView1.CurrentRow.Cells[3].Value.ToString());
                libreria.Utilidades.ejecutar(cmd);

                MessageBox.Show("Se ha habilitado el cliente");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_habilitar_Click(object sender, EventArgs e)
        {
            this.habilitarCliente();
            this.Hide();
        }
    }
}
