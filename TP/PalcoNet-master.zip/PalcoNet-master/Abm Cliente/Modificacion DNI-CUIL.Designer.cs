﻿namespace PalcoNet.Abm_Cliente
{
    partial class Modificacion_DNI_CUIL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_guardarCUIL = new System.Windows.Forms.Button();
            this.txt_CUIL = new System.Windows.Forms.TextBox();
            this.lab_CUIL = new System.Windows.Forms.Label();
            this.txt_documento = new System.Windows.Forms.TextBox();
            this.lab_documento = new System.Windows.Forms.Label();
            this.btn_guardarDocumento = new System.Windows.Forms.Button();
            this.cmb_tipoDoc = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btn_guardarCUIL
            // 
            this.btn_guardarCUIL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_guardarCUIL.Location = new System.Drawing.Point(738, 67);
            this.btn_guardarCUIL.Margin = new System.Windows.Forms.Padding(4);
            this.btn_guardarCUIL.Name = "btn_guardarCUIL";
            this.btn_guardarCUIL.Size = new System.Drawing.Size(249, 26);
            this.btn_guardarCUIL.TabIndex = 95;
            this.btn_guardarCUIL.Text = "Guardar nuevo CUIL";
            this.btn_guardarCUIL.UseVisualStyleBackColor = true;
            this.btn_guardarCUIL.Click += new System.EventHandler(this.btn_guardarCUIL_Click);
            // 
            // txt_CUIL
            // 
            this.txt_CUIL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CUIL.Location = new System.Drawing.Point(412, 67);
            this.txt_CUIL.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CUIL.Name = "txt_CUIL";
            this.txt_CUIL.Size = new System.Drawing.Size(302, 26);
            this.txt_CUIL.TabIndex = 93;
            // 
            // lab_CUIL
            // 
            this.lab_CUIL.AutoSize = true;
            this.lab_CUIL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_CUIL.Location = new System.Drawing.Point(198, 70);
            this.lab_CUIL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_CUIL.Name = "lab_CUIL";
            this.lab_CUIL.Size = new System.Drawing.Size(179, 20);
            this.lab_CUIL.TabIndex = 94;
            this.lab_CUIL.Text = "Ingrese el nuevo CUIL:";
            this.lab_CUIL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_documento
            // 
            this.txt_documento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_documento.Location = new System.Drawing.Point(494, 18);
            this.txt_documento.Margin = new System.Windows.Forms.Padding(4);
            this.txt_documento.Name = "txt_documento";
            this.txt_documento.Size = new System.Drawing.Size(220, 26);
            this.txt_documento.TabIndex = 92;
            // 
            // lab_documento
            // 
            this.lab_documento.AutoSize = true;
            this.lab_documento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_documento.Location = new System.Drawing.Point(13, 23);
            this.lab_documento.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_documento.Name = "lab_documento";
            this.lab_documento.Size = new System.Drawing.Size(364, 20);
            this.lab_documento.TabIndex = 91;
            this.lab_documento.Text = "Ingrese el nuevo Tipo y Numero de Documento:";
            this.lab_documento.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_guardarDocumento
            // 
            this.btn_guardarDocumento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_guardarDocumento.Location = new System.Drawing.Point(738, 18);
            this.btn_guardarDocumento.Margin = new System.Windows.Forms.Padding(4);
            this.btn_guardarDocumento.Name = "btn_guardarDocumento";
            this.btn_guardarDocumento.Size = new System.Drawing.Size(249, 26);
            this.btn_guardarDocumento.TabIndex = 90;
            this.btn_guardarDocumento.Text = "Guardar nuevo Documento";
            this.btn_guardarDocumento.UseVisualStyleBackColor = true;
            this.btn_guardarDocumento.Click += new System.EventHandler(this.btn_guardarDocumento_Click);
            // 
            // cmb_tipoDoc
            // 
            this.cmb_tipoDoc.FormattingEnabled = true;
            this.cmb_tipoDoc.Items.AddRange(new object[] {
            "DNI",
            "LC",
            "LE"});
            this.cmb_tipoDoc.Location = new System.Drawing.Point(412, 20);
            this.cmb_tipoDoc.Name = "cmb_tipoDoc";
            this.cmb_tipoDoc.Size = new System.Drawing.Size(75, 24);
            this.cmb_tipoDoc.TabIndex = 97;
            // 
            // Modificacion_DNI_CUIL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1044, 124);
            this.Controls.Add(this.cmb_tipoDoc);
            this.Controls.Add(this.btn_guardarCUIL);
            this.Controls.Add(this.txt_CUIL);
            this.Controls.Add(this.lab_CUIL);
            this.Controls.Add(this.txt_documento);
            this.Controls.Add(this.lab_documento);
            this.Controls.Add(this.btn_guardarDocumento);
            this.Name = "Modificacion_DNI_CUIL";
            this.Text = "Modificacion de DNI y/o CUIL";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_guardarCUIL;
        private System.Windows.Forms.TextBox txt_CUIL;
        private System.Windows.Forms.Label lab_CUIL;
        private System.Windows.Forms.TextBox txt_documento;
        private System.Windows.Forms.Label lab_documento;
        private System.Windows.Forms.Button btn_guardarDocumento;
        private System.Windows.Forms.ComboBox cmb_tipoDoc;
    }
}