﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Abm_Cliente
{
    public partial class Modificacion_DNI_CUIL : Form
    {
        string documentoActual;
        string tipoDocumentoActual;
        comandos cma = new comandos();

        public Modificacion_DNI_CUIL(string tipoDocAct, string docAct)
        {
            this.documentoActual = docAct;
            this.tipoDocumentoActual = tipoDocAct;
            InitializeComponent();
        }

        private bool modifDocCliente()
        {
            try
            {
                string modifCCliente = string.Format("EXEC DATEROS.modifDocumentoCliente '{0}', '{1}', '{2}', '{3}'", documentoActual.Trim(), tipoDocumentoActual.Trim(), txt_documento.Text.Trim(), cmb_tipoDoc.Text.Trim());
                libreria.Utilidades.ejecutar(modifCCliente);

                MessageBox.Show("Se ha modificado el documento correctamente");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private bool modifCuilCliente()
        {
            try
            {
                string modifCUILCliente = string.Format("EXEC DATEROS.modifCuilCliente '{0}', '{1}', '{2}'", documentoActual.ToString().Trim(), tipoDocumentoActual.ToString().Trim(), txt_CUIL.Text.Trim());
                libreria.Utilidades.ejecutar(modifCUILCliente);

                MessageBox.Show("Se ha modificado el CUIL correctamente");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_guardarDocumento_Click(object sender, EventArgs e)
        {
            this.modifDocCliente();
            this.Hide();
        }

        private void btn_guardarCUIL_Click(object sender, EventArgs e)
        {
            this.modifCuilCliente();
            this.Hide();
        }
    }
}