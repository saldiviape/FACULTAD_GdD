﻿namespace PalcoNet.Abm_Cliente
{
    partial class Modificacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_modif_CUIL_Documento = new System.Windows.Forms.Button();
            this.txt_depto = new System.Windows.Forms.TextBox();
            this.lab_codigoPostal = new System.Windows.Forms.Label();
            this.btn_Guardar = new System.Windows.Forms.Button();
            this.txt_localidad = new System.Windows.Forms.TextBox();
            this.lbl_localidad = new System.Windows.Forms.Label();
            this.txt_piso = new System.Windows.Forms.TextBox();
            this.lbl_piso = new System.Windows.Forms.Label();
            this.txt_direccion = new System.Windows.Forms.TextBox();
            this.lbl_direccion = new System.Windows.Forms.Label();
            this.txt_telefono = new System.Windows.Forms.TextBox();
            this.lbl_telefono = new System.Windows.Forms.Label();
            this.txt_mail = new System.Windows.Forms.TextBox();
            this.lbl_mail = new System.Windows.Forms.Label();
            this.txt_apellido = new System.Windows.Forms.TextBox();
            this.lbl_apellido = new System.Windows.Forms.Label();
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.lbl_nombre = new System.Windows.Forms.Label();
            this.txt_codigoPostal = new System.Windows.Forms.TextBox();
            this.lbl_codigoPostal = new System.Windows.Forms.Label();
            this.dtp_fechaVtoTarjeta = new System.Windows.Forms.DateTimePicker();
            this.dtp_fechaCreacion = new System.Windows.Forms.DateTimePicker();
            this.lab_fechaCreacion = new System.Windows.Forms.Label();
            this.txt_cvv = new System.Windows.Forms.TextBox();
            this.lab_cvv = new System.Windows.Forms.Label();
            this.txt_marca = new System.Windows.Forms.TextBox();
            this.lab_marca = new System.Windows.Forms.Label();
            this.txt_banco = new System.Windows.Forms.TextBox();
            this.lab_banco = new System.Windows.Forms.Label();
            this.lab_fechaVto = new System.Windows.Forms.Label();
            this.txt_nomTarjeta = new System.Windows.Forms.TextBox();
            this.lab_nombreTarjeta = new System.Windows.Forms.Label();
            this.txt_nroTarjeta = new System.Windows.Forms.TextBox();
            this.lab_nroTarjeta = new System.Windows.Forms.Label();
            this.dtp_fechaNac = new System.Windows.Forms.DateTimePicker();
            this.lbl_fechaNac = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_modif_CUIL_Documento
            // 
            this.btn_modif_CUIL_Documento.Location = new System.Drawing.Point(60, 578);
            this.btn_modif_CUIL_Documento.Name = "btn_modif_CUIL_Documento";
            this.btn_modif_CUIL_Documento.Size = new System.Drawing.Size(235, 50);
            this.btn_modif_CUIL_Documento.TabIndex = 102;
            this.btn_modif_CUIL_Documento.Text = "Modificar CUIL y/o Documento";
            this.btn_modif_CUIL_Documento.UseVisualStyleBackColor = true;
            this.btn_modif_CUIL_Documento.Click += new System.EventHandler(this.btn_modif_CUIL_Documento_Click);
            // 
            // txt_depto
            // 
            this.txt_depto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_depto.Location = new System.Drawing.Point(409, 188);
            this.txt_depto.Margin = new System.Windows.Forms.Padding(4);
            this.txt_depto.Name = "txt_depto";
            this.txt_depto.Size = new System.Drawing.Size(159, 26);
            this.txt_depto.TabIndex = 92;
            // 
            // lab_codigoPostal
            // 
            this.lab_codigoPostal.AutoSize = true;
            this.lab_codigoPostal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_codigoPostal.Location = new System.Drawing.Point(343, 191);
            this.lab_codigoPostal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_codigoPostal.Name = "lab_codigoPostal";
            this.lab_codigoPostal.Size = new System.Drawing.Size(58, 20);
            this.lab_codigoPostal.TabIndex = 100;
            this.lab_codigoPostal.Text = "Depto.";
            this.lab_codigoPostal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_Guardar
            // 
            this.btn_Guardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Guardar.Location = new System.Drawing.Point(323, 577);
            this.btn_Guardar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Guardar.Name = "btn_Guardar";
            this.btn_Guardar.Size = new System.Drawing.Size(235, 50);
            this.btn_Guardar.TabIndex = 101;
            this.btn_Guardar.Text = "Guardar Modificaciones";
            this.btn_Guardar.UseVisualStyleBackColor = true;
            this.btn_Guardar.Click += new System.EventHandler(this.btn_Guardar_Click);
            // 
            // txt_localidad
            // 
            this.txt_localidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_localidad.Location = new System.Drawing.Point(217, 222);
            this.txt_localidad.Margin = new System.Windows.Forms.Padding(4);
            this.txt_localidad.Name = "txt_localidad";
            this.txt_localidad.Size = new System.Drawing.Size(351, 26);
            this.txt_localidad.TabIndex = 94;
            // 
            // lbl_localidad
            // 
            this.lbl_localidad.AutoSize = true;
            this.lbl_localidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_localidad.Location = new System.Drawing.Point(120, 225);
            this.lbl_localidad.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_localidad.Name = "lbl_localidad";
            this.lbl_localidad.Size = new System.Drawing.Size(81, 20);
            this.lbl_localidad.TabIndex = 99;
            this.lbl_localidad.Text = "Localidad";
            this.lbl_localidad.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_piso
            // 
            this.txt_piso.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_piso.Location = new System.Drawing.Point(217, 188);
            this.txt_piso.Margin = new System.Windows.Forms.Padding(4);
            this.txt_piso.Name = "txt_piso";
            this.txt_piso.Size = new System.Drawing.Size(88, 26);
            this.txt_piso.TabIndex = 91;
            // 
            // lbl_piso
            // 
            this.lbl_piso.AutoSize = true;
            this.lbl_piso.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_piso.Location = new System.Drawing.Point(159, 194);
            this.lbl_piso.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_piso.Name = "lbl_piso";
            this.lbl_piso.Size = new System.Drawing.Size(42, 20);
            this.lbl_piso.TabIndex = 98;
            this.lbl_piso.Text = "Piso";
            this.lbl_piso.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_direccion
            // 
            this.txt_direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_direccion.Location = new System.Drawing.Point(217, 154);
            this.txt_direccion.Margin = new System.Windows.Forms.Padding(4);
            this.txt_direccion.Name = "txt_direccion";
            this.txt_direccion.Size = new System.Drawing.Size(351, 26);
            this.txt_direccion.TabIndex = 90;
            // 
            // lbl_direccion
            // 
            this.lbl_direccion.AutoSize = true;
            this.lbl_direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_direccion.Location = new System.Drawing.Point(120, 157);
            this.lbl_direccion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_direccion.Name = "lbl_direccion";
            this.lbl_direccion.Size = new System.Drawing.Size(81, 20);
            this.lbl_direccion.TabIndex = 97;
            this.lbl_direccion.Text = "Direccion";
            this.lbl_direccion.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_telefono
            // 
            this.txt_telefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_telefono.Location = new System.Drawing.Point(217, 120);
            this.txt_telefono.Margin = new System.Windows.Forms.Padding(4);
            this.txt_telefono.Name = "txt_telefono";
            this.txt_telefono.Size = new System.Drawing.Size(351, 26);
            this.txt_telefono.TabIndex = 89;
            // 
            // lbl_telefono
            // 
            this.lbl_telefono.AutoSize = true;
            this.lbl_telefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_telefono.Location = new System.Drawing.Point(133, 123);
            this.lbl_telefono.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_telefono.Name = "lbl_telefono";
            this.lbl_telefono.Size = new System.Drawing.Size(73, 20);
            this.lbl_telefono.TabIndex = 96;
            this.lbl_telefono.Text = "Telefono";
            this.lbl_telefono.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_mail
            // 
            this.txt_mail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_mail.Location = new System.Drawing.Point(217, 86);
            this.txt_mail.Margin = new System.Windows.Forms.Padding(4);
            this.txt_mail.Name = "txt_mail";
            this.txt_mail.Size = new System.Drawing.Size(351, 26);
            this.txt_mail.TabIndex = 88;
            // 
            // lbl_mail
            // 
            this.lbl_mail.AutoSize = true;
            this.lbl_mail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mail.Location = new System.Drawing.Point(161, 89);
            this.lbl_mail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_mail.Name = "lbl_mail";
            this.lbl_mail.Size = new System.Drawing.Size(40, 20);
            this.lbl_mail.TabIndex = 95;
            this.lbl_mail.Text = "Mail";
            this.lbl_mail.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_apellido
            // 
            this.txt_apellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_apellido.Location = new System.Drawing.Point(217, 52);
            this.txt_apellido.Margin = new System.Windows.Forms.Padding(4);
            this.txt_apellido.Name = "txt_apellido";
            this.txt_apellido.Size = new System.Drawing.Size(351, 26);
            this.txt_apellido.TabIndex = 87;
            // 
            // lbl_apellido
            // 
            this.lbl_apellido.AutoSize = true;
            this.lbl_apellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_apellido.Location = new System.Drawing.Point(133, 55);
            this.lbl_apellido.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_apellido.Name = "lbl_apellido";
            this.lbl_apellido.Size = new System.Drawing.Size(68, 20);
            this.lbl_apellido.TabIndex = 93;
            this.lbl_apellido.Text = "Apellido";
            this.lbl_apellido.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_nombre
            // 
            this.txt_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nombre.Location = new System.Drawing.Point(217, 20);
            this.txt_nombre.Margin = new System.Windows.Forms.Padding(4);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(351, 26);
            this.txt_nombre.TabIndex = 86;
            // 
            // lbl_nombre
            // 
            this.lbl_nombre.AutoSize = true;
            this.lbl_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nombre.Location = new System.Drawing.Point(133, 23);
            this.lbl_nombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_nombre.Name = "lbl_nombre";
            this.lbl_nombre.Size = new System.Drawing.Size(68, 20);
            this.lbl_nombre.TabIndex = 85;
            this.lbl_nombre.Text = "Nombre";
            this.lbl_nombre.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_codigoPostal
            // 
            this.txt_codigoPostal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_codigoPostal.Location = new System.Drawing.Point(217, 256);
            this.txt_codigoPostal.Margin = new System.Windows.Forms.Padding(4);
            this.txt_codigoPostal.Name = "txt_codigoPostal";
            this.txt_codigoPostal.Size = new System.Drawing.Size(351, 26);
            this.txt_codigoPostal.TabIndex = 103;
            // 
            // lbl_codigoPostal
            // 
            this.lbl_codigoPostal.AutoSize = true;
            this.lbl_codigoPostal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_codigoPostal.Location = new System.Drawing.Point(93, 259);
            this.lbl_codigoPostal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_codigoPostal.Name = "lbl_codigoPostal";
            this.lbl_codigoPostal.Size = new System.Drawing.Size(113, 20);
            this.lbl_codigoPostal.TabIndex = 104;
            this.lbl_codigoPostal.Text = "Codigo Postal";
            this.lbl_codigoPostal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dtp_fechaVtoTarjeta
            // 
            this.dtp_fechaVtoTarjeta.CustomFormat = "yyyy/MM/dd HH:mm:ss";
            this.dtp_fechaVtoTarjeta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_fechaVtoTarjeta.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_fechaVtoTarjeta.Location = new System.Drawing.Point(217, 426);
            this.dtp_fechaVtoTarjeta.Margin = new System.Windows.Forms.Padding(4);
            this.dtp_fechaVtoTarjeta.Name = "dtp_fechaVtoTarjeta";
            this.dtp_fechaVtoTarjeta.Size = new System.Drawing.Size(351, 26);
            this.dtp_fechaVtoTarjeta.TabIndex = 122;
            // 
            // dtp_fechaCreacion
            // 
            this.dtp_fechaCreacion.CustomFormat = "yyyy/MM/dd HH:mm:ss";
            this.dtp_fechaCreacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_fechaCreacion.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_fechaCreacion.Location = new System.Drawing.Point(217, 324);
            this.dtp_fechaCreacion.Margin = new System.Windows.Forms.Padding(4);
            this.dtp_fechaCreacion.Name = "dtp_fechaCreacion";
            this.dtp_fechaCreacion.Size = new System.Drawing.Size(351, 26);
            this.dtp_fechaCreacion.TabIndex = 120;
            // 
            // lab_fechaCreacion
            // 
            this.lab_fechaCreacion.AutoSize = true;
            this.lab_fechaCreacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_fechaCreacion.Location = new System.Drawing.Point(51, 329);
            this.lab_fechaCreacion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_fechaCreacion.Name = "lab_fechaCreacion";
            this.lab_fechaCreacion.Size = new System.Drawing.Size(150, 20);
            this.lab_fechaCreacion.TabIndex = 121;
            this.lab_fechaCreacion.Text = "Fecha de Creacion";
            this.lab_fechaCreacion.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_cvv
            // 
            this.txt_cvv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_cvv.Location = new System.Drawing.Point(217, 528);
            this.txt_cvv.Margin = new System.Windows.Forms.Padding(4);
            this.txt_cvv.Name = "txt_cvv";
            this.txt_cvv.Size = new System.Drawing.Size(351, 26);
            this.txt_cvv.TabIndex = 118;
            // 
            // lab_cvv
            // 
            this.lab_cvv.AutoSize = true;
            this.lab_cvv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_cvv.Location = new System.Drawing.Point(158, 531);
            this.lab_cvv.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_cvv.Name = "lab_cvv";
            this.lab_cvv.Size = new System.Drawing.Size(43, 20);
            this.lab_cvv.TabIndex = 119;
            this.lab_cvv.Text = "CVV";
            this.lab_cvv.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_marca
            // 
            this.txt_marca.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_marca.Location = new System.Drawing.Point(217, 494);
            this.txt_marca.Margin = new System.Windows.Forms.Padding(4);
            this.txt_marca.Name = "txt_marca";
            this.txt_marca.Size = new System.Drawing.Size(351, 26);
            this.txt_marca.TabIndex = 116;
            // 
            // lab_marca
            // 
            this.lab_marca.AutoSize = true;
            this.lab_marca.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_marca.Location = new System.Drawing.Point(150, 497);
            this.lab_marca.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_marca.Name = "lab_marca";
            this.lab_marca.Size = new System.Drawing.Size(56, 20);
            this.lab_marca.TabIndex = 117;
            this.lab_marca.Text = "Marca";
            this.lab_marca.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_banco
            // 
            this.txt_banco.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_banco.Location = new System.Drawing.Point(217, 460);
            this.txt_banco.Margin = new System.Windows.Forms.Padding(4);
            this.txt_banco.Name = "txt_banco";
            this.txt_banco.Size = new System.Drawing.Size(351, 26);
            this.txt_banco.TabIndex = 114;
            // 
            // lab_banco
            // 
            this.lab_banco.AutoSize = true;
            this.lab_banco.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_banco.Location = new System.Drawing.Point(144, 463);
            this.lab_banco.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_banco.Name = "lab_banco";
            this.lab_banco.Size = new System.Drawing.Size(57, 20);
            this.lab_banco.TabIndex = 115;
            this.lab_banco.Text = "Banco";
            this.lab_banco.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lab_fechaVto
            // 
            this.lab_fechaVto.AutoSize = true;
            this.lab_fechaVto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_fechaVto.Location = new System.Drawing.Point(26, 431);
            this.lab_fechaVto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_fechaVto.Name = "lab_fechaVto";
            this.lab_fechaVto.Size = new System.Drawing.Size(175, 20);
            this.lab_fechaVto.TabIndex = 113;
            this.lab_fechaVto.Text = "Fecha de Vencimiento";
            this.lab_fechaVto.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_nomTarjeta
            // 
            this.txt_nomTarjeta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nomTarjeta.Location = new System.Drawing.Point(217, 392);
            this.txt_nomTarjeta.Margin = new System.Windows.Forms.Padding(4);
            this.txt_nomTarjeta.Name = "txt_nomTarjeta";
            this.txt_nomTarjeta.Size = new System.Drawing.Size(351, 26);
            this.txt_nomTarjeta.TabIndex = 111;
            // 
            // lab_nombreTarjeta
            // 
            this.lab_nombreTarjeta.AutoSize = true;
            this.lab_nombreTarjeta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_nombreTarjeta.Location = new System.Drawing.Point(76, 395);
            this.lab_nombreTarjeta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_nombreTarjeta.Name = "lab_nombreTarjeta";
            this.lab_nombreTarjeta.Size = new System.Drawing.Size(125, 20);
            this.lab_nombreTarjeta.TabIndex = 112;
            this.lab_nombreTarjeta.Text = "Nombre Tarjeta";
            this.lab_nombreTarjeta.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_nroTarjeta
            // 
            this.txt_nroTarjeta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nroTarjeta.Location = new System.Drawing.Point(217, 358);
            this.txt_nroTarjeta.Margin = new System.Windows.Forms.Padding(4);
            this.txt_nroTarjeta.Name = "txt_nroTarjeta";
            this.txt_nroTarjeta.Size = new System.Drawing.Size(351, 26);
            this.txt_nroTarjeta.TabIndex = 109;
            // 
            // lab_nroTarjeta
            // 
            this.lab_nroTarjeta.AutoSize = true;
            this.lab_nroTarjeta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_nroTarjeta.Location = new System.Drawing.Point(104, 361);
            this.lab_nroTarjeta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_nroTarjeta.Name = "lab_nroTarjeta";
            this.lab_nroTarjeta.Size = new System.Drawing.Size(97, 20);
            this.lab_nroTarjeta.TabIndex = 110;
            this.lab_nroTarjeta.Text = "Nro. Tarjeta";
            this.lab_nroTarjeta.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dtp_fechaNac
            // 
            this.dtp_fechaNac.CustomFormat = "yyyy/MM/dd HH:mm:ss";
            this.dtp_fechaNac.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_fechaNac.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_fechaNac.Location = new System.Drawing.Point(217, 290);
            this.dtp_fechaNac.Margin = new System.Windows.Forms.Padding(4);
            this.dtp_fechaNac.Name = "dtp_fechaNac";
            this.dtp_fechaNac.Size = new System.Drawing.Size(351, 26);
            this.dtp_fechaNac.TabIndex = 107;
            // 
            // lbl_fechaNac
            // 
            this.lbl_fechaNac.AutoSize = true;
            this.lbl_fechaNac.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fechaNac.Location = new System.Drawing.Point(84, 295);
            this.lbl_fechaNac.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_fechaNac.Name = "lbl_fechaNac";
            this.lbl_fechaNac.Size = new System.Drawing.Size(117, 20);
            this.lbl_fechaNac.TabIndex = 108;
            this.lbl_fechaNac.Text = "Fecha de Nac.";
            this.lbl_fechaNac.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Modificacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(678, 651);
            this.Controls.Add(this.dtp_fechaVtoTarjeta);
            this.Controls.Add(this.dtp_fechaCreacion);
            this.Controls.Add(this.lab_fechaCreacion);
            this.Controls.Add(this.txt_cvv);
            this.Controls.Add(this.lab_cvv);
            this.Controls.Add(this.txt_marca);
            this.Controls.Add(this.lab_marca);
            this.Controls.Add(this.txt_banco);
            this.Controls.Add(this.lab_banco);
            this.Controls.Add(this.lab_fechaVto);
            this.Controls.Add(this.txt_nomTarjeta);
            this.Controls.Add(this.lab_nombreTarjeta);
            this.Controls.Add(this.txt_nroTarjeta);
            this.Controls.Add(this.lab_nroTarjeta);
            this.Controls.Add(this.dtp_fechaNac);
            this.Controls.Add(this.lbl_fechaNac);
            this.Controls.Add(this.txt_codigoPostal);
            this.Controls.Add(this.lbl_codigoPostal);
            this.Controls.Add(this.btn_modif_CUIL_Documento);
            this.Controls.Add(this.txt_depto);
            this.Controls.Add(this.lab_codigoPostal);
            this.Controls.Add(this.btn_Guardar);
            this.Controls.Add(this.txt_localidad);
            this.Controls.Add(this.lbl_localidad);
            this.Controls.Add(this.txt_piso);
            this.Controls.Add(this.lbl_piso);
            this.Controls.Add(this.txt_direccion);
            this.Controls.Add(this.lbl_direccion);
            this.Controls.Add(this.txt_telefono);
            this.Controls.Add(this.lbl_telefono);
            this.Controls.Add(this.txt_mail);
            this.Controls.Add(this.lbl_mail);
            this.Controls.Add(this.txt_apellido);
            this.Controls.Add(this.lbl_apellido);
            this.Controls.Add(this.txt_nombre);
            this.Controls.Add(this.lbl_nombre);
            this.Name = "Modificacion";
            this.Text = "Modificacion de Clientes";
            this.Load += new System.EventHandler(this.Modificacion_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_modif_CUIL_Documento;
        private System.Windows.Forms.TextBox txt_depto;
        private System.Windows.Forms.Label lab_codigoPostal;
        private System.Windows.Forms.Button btn_Guardar;
        private System.Windows.Forms.TextBox txt_localidad;
        private System.Windows.Forms.Label lbl_localidad;
        private System.Windows.Forms.TextBox txt_piso;
        private System.Windows.Forms.Label lbl_piso;
        private System.Windows.Forms.TextBox txt_direccion;
        private System.Windows.Forms.Label lbl_direccion;
        private System.Windows.Forms.TextBox txt_telefono;
        private System.Windows.Forms.Label lbl_telefono;
        private System.Windows.Forms.TextBox txt_mail;
        private System.Windows.Forms.Label lbl_mail;
        private System.Windows.Forms.TextBox txt_apellido;
        private System.Windows.Forms.Label lbl_apellido;
        private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.Label lbl_nombre;
        private System.Windows.Forms.TextBox txt_codigoPostal;
        private System.Windows.Forms.Label lbl_codigoPostal;
        private System.Windows.Forms.DateTimePicker dtp_fechaVtoTarjeta;
        private System.Windows.Forms.DateTimePicker dtp_fechaCreacion;
        private System.Windows.Forms.Label lab_fechaCreacion;
        private System.Windows.Forms.TextBox txt_cvv;
        private System.Windows.Forms.Label lab_cvv;
        private System.Windows.Forms.TextBox txt_marca;
        private System.Windows.Forms.Label lab_marca;
        private System.Windows.Forms.TextBox txt_banco;
        private System.Windows.Forms.Label lab_banco;
        private System.Windows.Forms.Label lab_fechaVto;
        private System.Windows.Forms.TextBox txt_nomTarjeta;
        private System.Windows.Forms.Label lab_nombreTarjeta;
        private System.Windows.Forms.TextBox txt_nroTarjeta;
        private System.Windows.Forms.Label lab_nroTarjeta;
        private System.Windows.Forms.DateTimePicker dtp_fechaNac;
        private System.Windows.Forms.Label lbl_fechaNac;
    }
}