﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Abm_Cliente
{
    public partial class Modificacion : Form
    {
        string tipoDocumentoActual;
        string documentoActual;
        comandos cma = new comandos();

        public Modificacion(string tipoDocAct, string docAct)
        {
            InitializeComponent();
            this.tipoDocumentoActual = tipoDocAct;
            this.documentoActual = docAct;
        }

        private void Modificacion_Load(object sender, EventArgs e)
        {
            cma.llenarTextBoxCliente(txt_nombre, "nombre", tipoDocumentoActual, documentoActual);
            cma.llenarTextBoxCliente(txt_apellido, "apellido", tipoDocumentoActual, documentoActual);
            cma.llenarTextBoxCliente(txt_mail, "mail", tipoDocumentoActual, documentoActual);
            cma.llenarTextBoxCliente(txt_telefono, "telefono", tipoDocumentoActual, documentoActual);
            cma.llenarTextBoxCliente(txt_direccion, "direccion", tipoDocumentoActual, documentoActual);
            cma.llenarTextBoxCliente(txt_piso, "nroPiso", tipoDocumentoActual, documentoActual);
            cma.llenarTextBoxCliente(txt_depto, "depto", tipoDocumentoActual, documentoActual);
            cma.llenarTextBoxCliente(txt_codigoPostal, "codPostal", tipoDocumentoActual, documentoActual);
            cma.llenarDTPCliente(dtp_fechaNac, "fechaNac", tipoDocumentoActual, documentoActual);
            cma.llenarDTPCliente(dtp_fechaCreacion, "fechaCreacion", tipoDocumentoActual, documentoActual);
            cma.llenarTextBoxCliente(txt_localidad, "localidad", tipoDocumentoActual, documentoActual);
            cma.llenarTextBoxTarjeta(txt_nroTarjeta, "nroTarjeta", tipoDocumentoActual, documentoActual);
            cma.llenarTextBoxTarjeta(txt_nomTarjeta, "nombre", tipoDocumentoActual, documentoActual);
            cma.llenarDTPTarjeta(dtp_fechaVtoTarjeta, "fechaVencimiento", tipoDocumentoActual, documentoActual);
            cma.llenarTextBoxTarjeta(txt_banco, "banco", tipoDocumentoActual, documentoActual);
            cma.llenarTextBoxTarjeta(txt_marca, "marca", tipoDocumentoActual, documentoActual);
            cma.llenarTextBoxTarjeta(txt_cvv, "cvv", tipoDocumentoActual, documentoActual);
        }

        private bool modificarCliente()
        {
            if ((Convert.ToDateTime(dtp_fechaNac.Value) < Properties.Settings.Default.FechaDelSistema) & (Convert.ToDateTime(dtp_fechaCreacion.Value) < Properties.Settings.Default.FechaDelSistema) & (Convert.ToDateTime(dtp_fechaVtoTarjeta.Value) > Properties.Settings.Default.FechaDelSistema))
                try
                {
                    string modifCliente = string.Format("EXEC DATEROS.modificacionCliente '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', '{14}', '{15}', '{16}', '{17}', '{18}'", tipoDocumentoActual.Trim(), documentoActual.Trim(), txt_nombre.Text.Trim(), txt_apellido.Text.Trim(), txt_mail.Text.Trim(), txt_telefono.Text.Trim(), txt_direccion.Text.Trim(), txt_piso.Text.Trim(), txt_depto.Text.Trim(), txt_localidad.Text.Trim(), txt_codigoPostal.Text.Trim(), Convert.ToDateTime(dtp_fechaNac.Value.ToString()), Convert.ToDateTime(dtp_fechaCreacion.Value.ToString()), txt_nroTarjeta.Text.Trim(), txt_nomTarjeta.Text.Trim(), Convert.ToDateTime(dtp_fechaVtoTarjeta.Value.ToString()), txt_banco.Text.Trim(), txt_marca.Text.Trim(), txt_cvv.Text.Trim());
                    libreria.Utilidades.ejecutar(modifCliente);

                    MessageBox.Show("Se han realizado todas las modificaciones");
                    return true;
                }
                catch (Exception error)
                {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
                }
            else
                MessageBox.Show("Por favor verifique las fechas");
                return false;
        }

        private void btn_modif_CUIL_Documento_Click(object sender, EventArgs e)
        {
            Abm_Cliente.Modificacion_DNI_CUIL mdc = new Abm_Cliente.Modificacion_DNI_CUIL(tipoDocumentoActual, documentoActual);
            mdc.Show();
        }

        private void btn_Guardar_Click(object sender, EventArgs e)
        {
            this.modificarCliente();
            this.Hide();
        }
    }
}
