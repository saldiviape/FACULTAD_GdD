﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Abm_Empresa_Espectaculo
{
    public partial class frm_abmEmpresa : Form
    {
        string rol;
        string usuario;

        public frm_abmEmpresa(string user, string r)
        {
            this.usuario = user;
            this.rol = r;
            InitializeComponent();
        }

        private void btn_alta_Click(object sender, EventArgs e)
        {
            Abm_Empresa_Espectaculo.Alta alt = new Abm_Empresa_Espectaculo.Alta(usuario, rol);
            alt.Show();
        }

        private void btn_baja_Click(object sender, EventArgs e)
        {
            Abm_Empresa_Espectaculo.Baja_Modificacion_de_Empresas baja = new Abm_Empresa_Espectaculo.Baja_Modificacion_de_Empresas();
            baja.Show();
        }

        private void frm_abmEmpresa_Load(object sender, EventArgs e)
        {

        }
    }
}