﻿namespace PalcoNet.Abm_Empresa_Espectaculo
{
    partial class Alta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Limpiar = new System.Windows.Forms.Button();
            this.btn_Guardar = new System.Windows.Forms.Button();
            this.txt_ciudad = new System.Windows.Forms.TextBox();
            this.lab_ciudad = new System.Windows.Forms.Label();
            this.txt_localidad = new System.Windows.Forms.TextBox();
            this.lab_localidad = new System.Windows.Forms.Label();
            this.txt_depto = new System.Windows.Forms.TextBox();
            this.lab_depto = new System.Windows.Forms.Label();
            this.txt_piso = new System.Windows.Forms.TextBox();
            this.lab_piso = new System.Windows.Forms.Label();
            this.txt_direccion = new System.Windows.Forms.TextBox();
            this.lab_direccion = new System.Windows.Forms.Label();
            this.txt_telefono = new System.Windows.Forms.TextBox();
            this.lab_telefono = new System.Windows.Forms.Label();
            this.txt_razonSocial = new System.Windows.Forms.TextBox();
            this.lab_razonSocial = new System.Windows.Forms.Label();
            this.txt_mail = new System.Windows.Forms.TextBox();
            this.lab_mail = new System.Windows.Forms.Label();
            this.txt_CUIT = new System.Windows.Forms.TextBox();
            this.lab_CUIT = new System.Windows.Forms.Label();
            this.txt_codigoPostal = new System.Windows.Forms.TextBox();
            this.lab_codigoPostal = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Limpiar
            // 
            this.btn_Limpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Limpiar.Location = new System.Drawing.Point(67, 359);
            this.btn_Limpiar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Limpiar.Name = "btn_Limpiar";
            this.btn_Limpiar.Size = new System.Drawing.Size(235, 50);
            this.btn_Limpiar.TabIndex = 60;
            this.btn_Limpiar.Text = "Limpiar";
            this.btn_Limpiar.UseVisualStyleBackColor = true;
            this.btn_Limpiar.Click += new System.EventHandler(this.btn_Limpiar_Click);
            // 
            // btn_Guardar
            // 
            this.btn_Guardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Guardar.Location = new System.Drawing.Point(359, 359);
            this.btn_Guardar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Guardar.Name = "btn_Guardar";
            this.btn_Guardar.Size = new System.Drawing.Size(235, 50);
            this.btn_Guardar.TabIndex = 61;
            this.btn_Guardar.Text = "Guardar";
            this.btn_Guardar.UseVisualStyleBackColor = true;
            this.btn_Guardar.Click += new System.EventHandler(this.btn_Guardar_Click);
            // 
            // txt_ciudad
            // 
            this.txt_ciudad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ciudad.Location = new System.Drawing.Point(214, 263);
            this.txt_ciudad.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ciudad.Name = "txt_ciudad";
            this.txt_ciudad.Size = new System.Drawing.Size(351, 26);
            this.txt_ciudad.TabIndex = 50;
            // 
            // lab_ciudad
            // 
            this.lab_ciudad.AutoSize = true;
            this.lab_ciudad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_ciudad.Location = new System.Drawing.Point(137, 266);
            this.lab_ciudad.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_ciudad.Name = "lab_ciudad";
            this.lab_ciudad.Size = new System.Drawing.Size(61, 20);
            this.lab_ciudad.TabIndex = 55;
            this.lab_ciudad.Text = "Ciudad";
            this.lab_ciudad.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_localidad
            // 
            this.txt_localidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_localidad.Location = new System.Drawing.Point(214, 195);
            this.txt_localidad.Margin = new System.Windows.Forms.Padding(4);
            this.txt_localidad.Name = "txt_localidad";
            this.txt_localidad.Size = new System.Drawing.Size(351, 26);
            this.txt_localidad.TabIndex = 44;
            // 
            // lab_localidad
            // 
            this.lab_localidad.AutoSize = true;
            this.lab_localidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_localidad.Location = new System.Drawing.Point(117, 198);
            this.lab_localidad.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_localidad.Name = "lab_localidad";
            this.lab_localidad.Size = new System.Drawing.Size(81, 20);
            this.lab_localidad.TabIndex = 54;
            this.lab_localidad.Text = "Localidad";
            this.lab_localidad.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_depto
            // 
            this.txt_depto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_depto.Location = new System.Drawing.Point(406, 161);
            this.txt_depto.Margin = new System.Windows.Forms.Padding(4);
            this.txt_depto.Name = "txt_depto";
            this.txt_depto.Size = new System.Drawing.Size(159, 26);
            this.txt_depto.TabIndex = 43;
            // 
            // lab_depto
            // 
            this.lab_depto.AutoSize = true;
            this.lab_depto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_depto.Location = new System.Drawing.Point(334, 165);
            this.lab_depto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_depto.Name = "lab_depto";
            this.lab_depto.Size = new System.Drawing.Size(58, 20);
            this.lab_depto.TabIndex = 53;
            this.lab_depto.Text = "Depto.";
            this.lab_depto.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_piso
            // 
            this.txt_piso.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_piso.Location = new System.Drawing.Point(214, 161);
            this.txt_piso.Margin = new System.Windows.Forms.Padding(4);
            this.txt_piso.Name = "txt_piso";
            this.txt_piso.Size = new System.Drawing.Size(88, 26);
            this.txt_piso.TabIndex = 41;
            // 
            // lab_piso
            // 
            this.lab_piso.AutoSize = true;
            this.lab_piso.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_piso.Location = new System.Drawing.Point(160, 165);
            this.lab_piso.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_piso.Name = "lab_piso";
            this.lab_piso.Size = new System.Drawing.Size(42, 20);
            this.lab_piso.TabIndex = 52;
            this.lab_piso.Text = "Piso";
            this.lab_piso.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_direccion
            // 
            this.txt_direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_direccion.Location = new System.Drawing.Point(214, 127);
            this.txt_direccion.Margin = new System.Windows.Forms.Padding(4);
            this.txt_direccion.Name = "txt_direccion";
            this.txt_direccion.Size = new System.Drawing.Size(351, 26);
            this.txt_direccion.TabIndex = 40;
            // 
            // lab_direccion
            // 
            this.lab_direccion.AutoSize = true;
            this.lab_direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_direccion.Location = new System.Drawing.Point(121, 130);
            this.lab_direccion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_direccion.Name = "lab_direccion";
            this.lab_direccion.Size = new System.Drawing.Size(81, 20);
            this.lab_direccion.TabIndex = 51;
            this.lab_direccion.Text = "Direccion";
            this.lab_direccion.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_telefono
            // 
            this.txt_telefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_telefono.Location = new System.Drawing.Point(214, 92);
            this.txt_telefono.Margin = new System.Windows.Forms.Padding(4);
            this.txt_telefono.Name = "txt_telefono";
            this.txt_telefono.Size = new System.Drawing.Size(351, 26);
            this.txt_telefono.TabIndex = 38;
            // 
            // lab_telefono
            // 
            this.lab_telefono.AutoSize = true;
            this.lab_telefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_telefono.Location = new System.Drawing.Point(125, 96);
            this.lab_telefono.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_telefono.Name = "lab_telefono";
            this.lab_telefono.Size = new System.Drawing.Size(73, 20);
            this.lab_telefono.TabIndex = 48;
            this.lab_telefono.Text = "Teléfono";
            this.lab_telefono.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_razonSocial
            // 
            this.txt_razonSocial.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_razonSocial.Location = new System.Drawing.Point(214, 24);
            this.txt_razonSocial.Margin = new System.Windows.Forms.Padding(4);
            this.txt_razonSocial.Name = "txt_razonSocial";
            this.txt_razonSocial.Size = new System.Drawing.Size(351, 26);
            this.txt_razonSocial.TabIndex = 30;
            // 
            // lab_razonSocial
            // 
            this.lab_razonSocial.AutoSize = true;
            this.lab_razonSocial.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_razonSocial.Location = new System.Drawing.Point(90, 27);
            this.lab_razonSocial.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_razonSocial.Name = "lab_razonSocial";
            this.lab_razonSocial.Size = new System.Drawing.Size(108, 20);
            this.lab_razonSocial.TabIndex = 39;
            this.lab_razonSocial.Text = "Razon Social";
            this.lab_razonSocial.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_mail
            // 
            this.txt_mail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_mail.Location = new System.Drawing.Point(214, 58);
            this.txt_mail.Margin = new System.Windows.Forms.Padding(4);
            this.txt_mail.Name = "txt_mail";
            this.txt_mail.Size = new System.Drawing.Size(351, 26);
            this.txt_mail.TabIndex = 34;
            // 
            // lab_mail
            // 
            this.lab_mail.AutoSize = true;
            this.lab_mail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_mail.Location = new System.Drawing.Point(156, 64);
            this.lab_mail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_mail.Name = "lab_mail";
            this.lab_mail.Size = new System.Drawing.Size(40, 20);
            this.lab_mail.TabIndex = 32;
            this.lab_mail.Text = "Mail";
            this.lab_mail.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_CUIT
            // 
            this.txt_CUIT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CUIT.Location = new System.Drawing.Point(214, 297);
            this.txt_CUIT.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CUIT.Name = "txt_CUIT";
            this.txt_CUIT.Size = new System.Drawing.Size(351, 26);
            this.txt_CUIT.TabIndex = 51;
            // 
            // lab_CUIT
            // 
            this.lab_CUIT.AutoSize = true;
            this.lab_CUIT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_CUIT.Location = new System.Drawing.Point(147, 300);
            this.lab_CUIT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_CUIT.Name = "lab_CUIT";
            this.lab_CUIT.Size = new System.Drawing.Size(47, 20);
            this.lab_CUIT.TabIndex = 29;
            this.lab_CUIT.Text = "CUIT";
            this.lab_CUIT.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_codigoPostal
            // 
            this.txt_codigoPostal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_codigoPostal.Location = new System.Drawing.Point(214, 229);
            this.txt_codigoPostal.Margin = new System.Windows.Forms.Padding(4);
            this.txt_codigoPostal.Name = "txt_codigoPostal";
            this.txt_codigoPostal.Size = new System.Drawing.Size(351, 26);
            this.txt_codigoPostal.TabIndex = 46;
            // 
            // lab_codigoPostal
            // 
            this.lab_codigoPostal.AutoSize = true;
            this.lab_codigoPostal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_codigoPostal.Location = new System.Drawing.Point(85, 232);
            this.lab_codigoPostal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_codigoPostal.Name = "lab_codigoPostal";
            this.lab_codigoPostal.Size = new System.Drawing.Size(113, 20);
            this.lab_codigoPostal.TabIndex = 58;
            this.lab_codigoPostal.Text = "Codigo Postal";
            this.lab_codigoPostal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Alta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(649, 446);
            this.Controls.Add(this.txt_codigoPostal);
            this.Controls.Add(this.lab_codigoPostal);
            this.Controls.Add(this.btn_Limpiar);
            this.Controls.Add(this.btn_Guardar);
            this.Controls.Add(this.txt_ciudad);
            this.Controls.Add(this.lab_ciudad);
            this.Controls.Add(this.txt_localidad);
            this.Controls.Add(this.lab_localidad);
            this.Controls.Add(this.txt_depto);
            this.Controls.Add(this.lab_depto);
            this.Controls.Add(this.txt_piso);
            this.Controls.Add(this.lab_piso);
            this.Controls.Add(this.txt_direccion);
            this.Controls.Add(this.lab_direccion);
            this.Controls.Add(this.txt_telefono);
            this.Controls.Add(this.lab_telefono);
            this.Controls.Add(this.txt_razonSocial);
            this.Controls.Add(this.lab_razonSocial);
            this.Controls.Add(this.txt_mail);
            this.Controls.Add(this.lab_mail);
            this.Controls.Add(this.txt_CUIT);
            this.Controls.Add(this.lab_CUIT);
            this.Name = "Alta";
            this.Text = "Alta De Empresa";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Limpiar;
        private System.Windows.Forms.Button btn_Guardar;
        private System.Windows.Forms.TextBox txt_ciudad;
        private System.Windows.Forms.Label lab_ciudad;
        private System.Windows.Forms.TextBox txt_localidad;
        private System.Windows.Forms.Label lab_localidad;
        private System.Windows.Forms.TextBox txt_depto;
        private System.Windows.Forms.Label lab_depto;
        private System.Windows.Forms.TextBox txt_piso;
        private System.Windows.Forms.Label lab_piso;
        private System.Windows.Forms.TextBox txt_direccion;
        private System.Windows.Forms.Label lab_direccion;
        private System.Windows.Forms.TextBox txt_telefono;
        private System.Windows.Forms.Label lab_telefono;
        private System.Windows.Forms.TextBox txt_razonSocial;
        private System.Windows.Forms.Label lab_razonSocial;
        private System.Windows.Forms.TextBox txt_mail;
        private System.Windows.Forms.Label lab_mail;
        private System.Windows.Forms.TextBox txt_CUIT;
        private System.Windows.Forms.Label lab_CUIT;
        private System.Windows.Forms.TextBox txt_codigoPostal;
        private System.Windows.Forms.Label lab_codigoPostal;
    }
}