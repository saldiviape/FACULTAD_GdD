﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using PalcoNet.libreria;

namespace PalcoNet.Abm_Empresa_Espectaculo
{
    public partial class Alta : Form
    {
        string usuario;
        string rol;

        public Alta(string user, string r)
        {
            this.usuario = user;
            this.rol = r;
            InitializeComponent();
        }

        private void btn_Limpiar_Click(object sender, EventArgs e)
        {
            Limpiar limpiar = new Limpiar();
            limpiar.limpiarCampos(this);
        }

        private bool altaEmpresa()
        {
            string consultaIdRol = string.Format("SELECT idRol FROM DATEROS.rol WHERE nombre = '" + rol + "'");
            DataSet dscr = Utilidades.ejecutar(consultaIdRol);
            string idRol = dscr.Tables[0].Rows[0]["idRol"].ToString();

            if (rol == "Administrativo")
            {
                try
                {
                    string altaEmpresa = string.Format("EXEC DATEROS.altaEmpresaAdmin '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}'",
                        txt_razonSocial.Text.Trim(), txt_mail.Text.Trim(), txt_telefono.Text.Trim(), txt_direccion.Text.Trim(), txt_piso.Text.Trim(),
                        txt_depto.Text.Trim(), txt_localidad.Text.Trim(), txt_codigoPostal.Text.Trim(), txt_ciudad.Text.Trim(), txt_CUIT.Text.Trim(), Properties.Settings.Default.FechaDelSistema);
                    libreria.Utilidades.ejecutar(altaEmpresa);

                    MessageBox.Show("Se ha creado correctamente la nueva empresa");
                    this.Hide();
                    return true;
                }
                catch (Exception error)
                {
                    MessageBox.Show("Ha ocurrido un error: " + error.Message);
                    return false;
                }
            }
            else
            {
                try
                {
                    string altaEmpresa = string.Format("EXEC DATEROS.altaEmpresa '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}'",
                        txt_razonSocial.Text.Trim(), txt_mail.Text.Trim(), txt_telefono.Text.Trim(), txt_direccion.Text.Trim(), txt_piso.Text.Trim(),
                        txt_depto.Text.Trim(), txt_localidad.Text.Trim(), txt_codigoPostal.Text.Trim(), txt_ciudad.Text.Trim(), txt_CUIT.Text.Trim(), Properties.Settings.Default.FechaDelSistema, usuario, idRol);
                    libreria.Utilidades.ejecutar(altaEmpresa);

                    MessageBox.Show("Se ha creado correctamente la nueva empresa");
                    this.Hide();
                    return true;
                }
                catch (Exception error)
                {
                    MessageBox.Show("Ha ocurrido un error: " + error.Message);
                    return false;
                }
            }
        }

        private void btn_Guardar_Click(object sender, EventArgs e)
        {
           this.altaEmpresa();         
        }
    }
}
