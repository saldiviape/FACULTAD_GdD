﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Abm_Empresa_Espectaculo
{
    public partial class Baja_Modificacion_de_Empresas : Form
    {
        comandos cma = new comandos();

        public Baja_Modificacion_de_Empresas()
        {
            InitializeComponent();
        }

        private void btn_Limpiar_Click(object sender, EventArgs e)
        {
            Limpiar limpiar = new Limpiar();
            limpiar.limpiarCampos(this);
        }

        private void btn_Buscar_Click(object sender, EventArgs e)
        {
            if (chk_razonSocial.Checked & chk_cuit.Checked & chk_email.Checked)
            {
                cma.llenarDataGridView(dataGridView1, "SELECT razonSocial, e.username FROM DATEROS.empresas e, DATEROS.usuario u WHERE razonSocial LIKE '" + txt_razonSocial.Text + "' + '%' AND mail LIKE '" + txt_email.Text + "' + '%' AND cuit = '" + txt_cuit.Text + "' AND e.username=u.username AND u.estado != 'Dado De Baja'");
            }
            else
            {  
                if (chk_razonSocial.Checked & chk_cuit.Checked)
               {
                    cma.llenarDataGridView(dataGridView1, "SELECT razonSocial, e.username FROM DATEROS.empresas e, DATEROS.usuario u WHERE razonSocial LIKE '" + txt_razonSocial.Text + "' + '%' AND cuit = '" + txt_cuit.Text + "' AND e.username=u.username AND u.estado != 'Dado De Baja'");
               }

               if (chk_razonSocial.Checked & chk_email.Checked)
               {                
               cma.llenarDataGridView(dataGridView1, "SELECT razonSocial, e.username FROM DATEROS.empresas e, DATEROS.usuario u WHERE razonSocial LIKE '" + txt_razonSocial.Text + "' + '%' AND mail LIKE '" + txt_email.Text + "' + '%' AND e.username=u.username AND u.estado != 'Dado De Baja'");
               }

               if (chk_email.Checked & chk_cuit.Checked)
               {
                   cma.llenarDataGridView(dataGridView1, "SELECT razonSocial, e.username FROM DATEROS.empresas e, DATEROS.usuario u WHERE mail LIKE '" + txt_email.Text + "' + '%' AND cuit = '" + txt_cuit.Text + "' AND e.username=u.username AND u.estado != 'Dado De Baja'");
               }

               if (chk_cuit.Checked & !chk_email.Checked & !chk_razonSocial.Checked)
               {
                   cma.llenarDataGridView(dataGridView1, "SELECT razonSocial, e.username FROM DATEROS.empresas e, DATEROS.usuario u WHERE cuit = '" + txt_cuit.Text + "' AND e.username=u.username AND u.estado != 'Dado De Baja'");
               }

               if (!chk_cuit.Checked & chk_email.Checked & !chk_razonSocial.Checked)
               {
                   cma.llenarDataGridView(dataGridView1, "SELECT razonSocial, e.username FROM DATEROS.empresas e, DATEROS.usuario u WHERE mail LIKE '" + txt_email.Text + "' + '%' AND e.username=u.username AND u.estado != 'Dado De Baja'");
               }

               if (!chk_cuit.Checked & !chk_email.Checked & chk_razonSocial.Checked)
               {
                   cma.llenarDataGridView(dataGridView1, "SELECT razonSocial, e.username FROM DATEROS.empresas e, DATEROS.usuario u WHERE razonSocial LIKE '" + txt_razonSocial.Text + "' + '%' AND e.username=u.username AND u.estado != 'Dado De Baja'");
               }

               if (!chk_razonSocial.Checked & !chk_cuit.Checked & !chk_email.Checked)
               {
                   cma.llenarDataGridView(dataGridView1, "SELECT razonSocial, e.username FROM DATEROS.empresas e, DATEROS.usuario u WHERE e.username=u.username AND u.estado != 'Dado De Baja'");
               }
            }     
        }

        private bool bajaEmpresa()
        {
            try
            {
                string cmd = string.Format("EXEC DATEROS.bajaUsuario '{0}'", dataGridView1.CurrentRow.Cells[1].Value.ToString());
                libreria.Utilidades.ejecutar(cmd);

                MessageBox.Show("Se ha dado de baja la empresa");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_baja_Click(object sender, EventArgs e)
        {
            this.bajaEmpresa();
        }

        private void btn_habilitar_Click(object sender, EventArgs e)
        {
            Abm_Empresa_Espectaculo.Empresas_Deshabilitadas ed = new Abm_Empresa_Espectaculo.Empresas_Deshabilitadas();
            ed.Show();
        }

        private void btn_modificar_Click(object sender, EventArgs e)
        {
            Abm_Empresa_Espectaculo.Modificacion mod = new Abm_Empresa_Espectaculo.Modificacion(dataGridView1.CurrentRow.Cells[0].Value.ToString());
            mod.Show();
        }
    }
}
