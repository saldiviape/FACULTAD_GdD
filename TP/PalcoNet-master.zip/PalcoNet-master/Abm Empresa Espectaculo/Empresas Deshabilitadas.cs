﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Abm_Empresa_Espectaculo
{
    public partial class Empresas_Deshabilitadas : Form
    {
        comandos cma = new comandos();

        public Empresas_Deshabilitadas()
        {
            InitializeComponent();
        }

        private void btn_empresasInhabilitadas_Click(object sender, EventArgs e)
        {
            try
            {
                cma.llenarDataGridView(dataGridView1, "SELECT razonSocial, e.username FROM DATEROS.empresas e, DATEROS.usuario u WHERE e.username=u.username AND u.estado = 'Dado De Baja'");
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
            }
        }

        private bool habilitarEmpresa()
        {
            try
            {
                string cmd = string.Format("EXEC DATEROS.habilitarUsuario '{0}'", dataGridView1.CurrentRow.Cells[1].Value.ToString());
                libreria.Utilidades.ejecutar(cmd);

                MessageBox.Show("Se ha habilitado la empresa");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_habilitar_Click(object sender, EventArgs e)
        {
            this.habilitarEmpresa();
            this.Hide();
        }
    }
}
