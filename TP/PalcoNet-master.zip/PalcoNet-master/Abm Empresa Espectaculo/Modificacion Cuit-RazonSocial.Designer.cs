﻿namespace PalcoNet.Abm_Empresa_Espectaculo
{
    partial class Modificacion_Cuit_RazonSocial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_guardarRazonSocial = new System.Windows.Forms.Button();
            this.txt_CUIT = new System.Windows.Forms.TextBox();
            this.lab_CUIT = new System.Windows.Forms.Label();
            this.txt_razonSocial = new System.Windows.Forms.TextBox();
            this.lab_razonSocial = new System.Windows.Forms.Label();
            this.btn_guardarCUIT = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_guardarRazonSocial
            // 
            this.btn_guardarRazonSocial.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_guardarRazonSocial.Location = new System.Drawing.Point(670, 34);
            this.btn_guardarRazonSocial.Margin = new System.Windows.Forms.Padding(4);
            this.btn_guardarRazonSocial.Name = "btn_guardarRazonSocial";
            this.btn_guardarRazonSocial.Size = new System.Drawing.Size(249, 26);
            this.btn_guardarRazonSocial.TabIndex = 84;
            this.btn_guardarRazonSocial.Text = "Guardar nueva Razon Social";
            this.btn_guardarRazonSocial.UseVisualStyleBackColor = true;
            this.btn_guardarRazonSocial.Click += new System.EventHandler(this.btn_guardarRazonSocial_Click);
            // 
            // txt_CUIT
            // 
            this.txt_CUIT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CUIT.Location = new System.Drawing.Point(289, 90);
            this.txt_CUIT.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CUIT.Name = "txt_CUIT";
            this.txt_CUIT.Size = new System.Drawing.Size(351, 26);
            this.txt_CUIT.TabIndex = 87;
            // 
            // lab_CUIT
            // 
            this.lab_CUIT.AutoSize = true;
            this.lab_CUIT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_CUIT.Location = new System.Drawing.Point(102, 93);
            this.lab_CUIT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_CUIT.Name = "lab_CUIT";
            this.lab_CUIT.Size = new System.Drawing.Size(179, 20);
            this.lab_CUIT.TabIndex = 88;
            this.lab_CUIT.Text = "Ingrese el nuevo CUIT:";
            this.lab_CUIT.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_razonSocial
            // 
            this.txt_razonSocial.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_razonSocial.Location = new System.Drawing.Point(289, 34);
            this.txt_razonSocial.Margin = new System.Windows.Forms.Padding(4);
            this.txt_razonSocial.Name = "txt_razonSocial";
            this.txt_razonSocial.Size = new System.Drawing.Size(351, 26);
            this.txt_razonSocial.TabIndex = 86;
            // 
            // lab_razonSocial
            // 
            this.lab_razonSocial.AutoSize = true;
            this.lab_razonSocial.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_razonSocial.Location = new System.Drawing.Point(41, 37);
            this.lab_razonSocial.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_razonSocial.Name = "lab_razonSocial";
            this.lab_razonSocial.Size = new System.Drawing.Size(240, 20);
            this.lab_razonSocial.TabIndex = 85;
            this.lab_razonSocial.Text = "Ingrese la nueva Razon Social:";
            this.lab_razonSocial.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_guardarCUIT
            // 
            this.btn_guardarCUIT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_guardarCUIT.Location = new System.Drawing.Point(670, 90);
            this.btn_guardarCUIT.Margin = new System.Windows.Forms.Padding(4);
            this.btn_guardarCUIT.Name = "btn_guardarCUIT";
            this.btn_guardarCUIT.Size = new System.Drawing.Size(249, 26);
            this.btn_guardarCUIT.TabIndex = 89;
            this.btn_guardarCUIT.Text = "Guardar nuevo CUIT";
            this.btn_guardarCUIT.UseVisualStyleBackColor = true;
            this.btn_guardarCUIT.Click += new System.EventHandler(this.btn_guardarCUIT_Click);
            // 
            // Modificacion_Cuit_RazonSocial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(949, 156);
            this.Controls.Add(this.btn_guardarCUIT);
            this.Controls.Add(this.txt_CUIT);
            this.Controls.Add(this.lab_CUIT);
            this.Controls.Add(this.txt_razonSocial);
            this.Controls.Add(this.lab_razonSocial);
            this.Controls.Add(this.btn_guardarRazonSocial);
            this.Name = "Modificacion_Cuit_RazonSocial";
            this.Text = "Modificacion de CUIT y/o Razon Social";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_guardarRazonSocial;
        private System.Windows.Forms.TextBox txt_CUIT;
        private System.Windows.Forms.Label lab_CUIT;
        private System.Windows.Forms.TextBox txt_razonSocial;
        private System.Windows.Forms.Label lab_razonSocial;
        private System.Windows.Forms.Button btn_guardarCUIT;
    }
}