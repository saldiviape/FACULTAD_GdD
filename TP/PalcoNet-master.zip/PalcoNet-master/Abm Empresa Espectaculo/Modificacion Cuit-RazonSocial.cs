﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Abm_Empresa_Espectaculo
{
    public partial class Modificacion_Cuit_RazonSocial : Form
    {
        string empresaActual;
        comandos cma = new comandos();

        public Modificacion_Cuit_RazonSocial(string empresa)
        {
            this.empresaActual = empresa;
            InitializeComponent();
        }

        private bool modifRazonSocialEmpresa()
        {
            try
            {
                string modifRZEmpresa = string.Format("EXEC DATEROS.modifRazonSocialEmpresa '{0}', '{1}'", empresaActual.Trim(), txt_razonSocial.Text.Trim());
                libreria.Utilidades.ejecutar(modifRZEmpresa);

                MessageBox.Show("Se ha modificado la Razon Social correctamente");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private bool modifCuitEmpresa()
        {
            try
            {
                string modifCUITEmpresa = string.Format("EXEC DATEROS.modifCuitEmpresa '{0}', '{1}'", empresaActual.Trim(), txt_CUIT.Text.Trim());
                libreria.Utilidades.ejecutar(modifCUITEmpresa);

                MessageBox.Show("Se ha modificado el CUIT correctamente");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_guardarRazonSocial_Click(object sender, EventArgs e)
        {
            this.modifRazonSocialEmpresa();
            this.Hide();
        }

        private void btn_guardarCUIT_Click(object sender, EventArgs e)
        {
            this.modifCuitEmpresa();
            this.Hide();
        }
    }
}
