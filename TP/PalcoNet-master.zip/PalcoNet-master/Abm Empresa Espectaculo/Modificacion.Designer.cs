﻿namespace PalcoNet.Abm_Empresa_Espectaculo
{
    partial class Modificacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_codigoPostal = new System.Windows.Forms.TextBox();
            this.lab_codigoPostal = new System.Windows.Forms.Label();
            this.btn_Guardar = new System.Windows.Forms.Button();
            this.txt_ciudad = new System.Windows.Forms.TextBox();
            this.lab_ciudad = new System.Windows.Forms.Label();
            this.txt_localidad = new System.Windows.Forms.TextBox();
            this.lab_localidad = new System.Windows.Forms.Label();
            this.txt_depto = new System.Windows.Forms.TextBox();
            this.lab_depto = new System.Windows.Forms.Label();
            this.txt_piso = new System.Windows.Forms.TextBox();
            this.lab_piso = new System.Windows.Forms.Label();
            this.txt_direccion = new System.Windows.Forms.TextBox();
            this.lab_direccion = new System.Windows.Forms.Label();
            this.txt_telefono = new System.Windows.Forms.TextBox();
            this.lab_telefono = new System.Windows.Forms.Label();
            this.txt_mail = new System.Windows.Forms.TextBox();
            this.lab_mail = new System.Windows.Forms.Label();
            this.btn_modif_CUIT_RazonSocial = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_codigoPostal
            // 
            this.txt_codigoPostal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_codigoPostal.Location = new System.Drawing.Point(165, 198);
            this.txt_codigoPostal.Margin = new System.Windows.Forms.Padding(4);
            this.txt_codigoPostal.Name = "txt_codigoPostal";
            this.txt_codigoPostal.Size = new System.Drawing.Size(351, 26);
            this.txt_codigoPostal.TabIndex = 72;
            // 
            // lab_codigoPostal
            // 
            this.lab_codigoPostal.AutoSize = true;
            this.lab_codigoPostal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_codigoPostal.Location = new System.Drawing.Point(36, 201);
            this.lab_codigoPostal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_codigoPostal.Name = "lab_codigoPostal";
            this.lab_codigoPostal.Size = new System.Drawing.Size(113, 20);
            this.lab_codigoPostal.TabIndex = 81;
            this.lab_codigoPostal.Text = "Codigo Postal";
            this.lab_codigoPostal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_Guardar
            // 
            this.btn_Guardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Guardar.Location = new System.Drawing.Point(281, 282);
            this.btn_Guardar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Guardar.Name = "btn_Guardar";
            this.btn_Guardar.Size = new System.Drawing.Size(235, 50);
            this.btn_Guardar.TabIndex = 83;
            this.btn_Guardar.Text = "Guardar Modificaciones";
            this.btn_Guardar.UseVisualStyleBackColor = true;
            this.btn_Guardar.Click += new System.EventHandler(this.btn_Guardar_Click);
            // 
            // txt_ciudad
            // 
            this.txt_ciudad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ciudad.Location = new System.Drawing.Point(165, 232);
            this.txt_ciudad.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ciudad.Name = "txt_ciudad";
            this.txt_ciudad.Size = new System.Drawing.Size(351, 26);
            this.txt_ciudad.TabIndex = 74;
            // 
            // lab_ciudad
            // 
            this.lab_ciudad.AutoSize = true;
            this.lab_ciudad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_ciudad.Location = new System.Drawing.Point(88, 235);
            this.lab_ciudad.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_ciudad.Name = "lab_ciudad";
            this.lab_ciudad.Size = new System.Drawing.Size(61, 20);
            this.lab_ciudad.TabIndex = 80;
            this.lab_ciudad.Text = "Ciudad";
            this.lab_ciudad.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_localidad
            // 
            this.txt_localidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_localidad.Location = new System.Drawing.Point(165, 164);
            this.txt_localidad.Margin = new System.Windows.Forms.Padding(4);
            this.txt_localidad.Name = "txt_localidad";
            this.txt_localidad.Size = new System.Drawing.Size(351, 26);
            this.txt_localidad.TabIndex = 71;
            // 
            // lab_localidad
            // 
            this.lab_localidad.AutoSize = true;
            this.lab_localidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_localidad.Location = new System.Drawing.Point(68, 167);
            this.lab_localidad.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_localidad.Name = "lab_localidad";
            this.lab_localidad.Size = new System.Drawing.Size(81, 20);
            this.lab_localidad.TabIndex = 79;
            this.lab_localidad.Text = "Localidad";
            this.lab_localidad.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_depto
            // 
            this.txt_depto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_depto.Location = new System.Drawing.Point(357, 130);
            this.txt_depto.Margin = new System.Windows.Forms.Padding(4);
            this.txt_depto.Name = "txt_depto";
            this.txt_depto.Size = new System.Drawing.Size(159, 26);
            this.txt_depto.TabIndex = 70;
            // 
            // lab_depto
            // 
            this.lab_depto.AutoSize = true;
            this.lab_depto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_depto.Location = new System.Drawing.Point(285, 134);
            this.lab_depto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_depto.Name = "lab_depto";
            this.lab_depto.Size = new System.Drawing.Size(58, 20);
            this.lab_depto.TabIndex = 78;
            this.lab_depto.Text = "Depto.";
            this.lab_depto.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_piso
            // 
            this.txt_piso.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_piso.Location = new System.Drawing.Point(165, 130);
            this.txt_piso.Margin = new System.Windows.Forms.Padding(4);
            this.txt_piso.Name = "txt_piso";
            this.txt_piso.Size = new System.Drawing.Size(88, 26);
            this.txt_piso.TabIndex = 69;
            // 
            // lab_piso
            // 
            this.lab_piso.AutoSize = true;
            this.lab_piso.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_piso.Location = new System.Drawing.Point(111, 134);
            this.lab_piso.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_piso.Name = "lab_piso";
            this.lab_piso.Size = new System.Drawing.Size(42, 20);
            this.lab_piso.TabIndex = 77;
            this.lab_piso.Text = "Piso";
            this.lab_piso.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_direccion
            // 
            this.txt_direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_direccion.Location = new System.Drawing.Point(165, 96);
            this.txt_direccion.Margin = new System.Windows.Forms.Padding(4);
            this.txt_direccion.Name = "txt_direccion";
            this.txt_direccion.Size = new System.Drawing.Size(351, 26);
            this.txt_direccion.TabIndex = 68;
            // 
            // lab_direccion
            // 
            this.lab_direccion.AutoSize = true;
            this.lab_direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_direccion.Location = new System.Drawing.Point(72, 99);
            this.lab_direccion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_direccion.Name = "lab_direccion";
            this.lab_direccion.Size = new System.Drawing.Size(81, 20);
            this.lab_direccion.TabIndex = 76;
            this.lab_direccion.Text = "Direccion";
            this.lab_direccion.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_telefono
            // 
            this.txt_telefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_telefono.Location = new System.Drawing.Point(165, 61);
            this.txt_telefono.Margin = new System.Windows.Forms.Padding(4);
            this.txt_telefono.Name = "txt_telefono";
            this.txt_telefono.Size = new System.Drawing.Size(351, 26);
            this.txt_telefono.TabIndex = 66;
            // 
            // lab_telefono
            // 
            this.lab_telefono.AutoSize = true;
            this.lab_telefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_telefono.Location = new System.Drawing.Point(76, 65);
            this.lab_telefono.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_telefono.Name = "lab_telefono";
            this.lab_telefono.Size = new System.Drawing.Size(73, 20);
            this.lab_telefono.TabIndex = 73;
            this.lab_telefono.Text = "Teléfono";
            this.lab_telefono.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_mail
            // 
            this.txt_mail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_mail.Location = new System.Drawing.Point(165, 27);
            this.txt_mail.Margin = new System.Windows.Forms.Padding(4);
            this.txt_mail.Name = "txt_mail";
            this.txt_mail.Size = new System.Drawing.Size(351, 26);
            this.txt_mail.TabIndex = 65;
            // 
            // lab_mail
            // 
            this.lab_mail.AutoSize = true;
            this.lab_mail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_mail.Location = new System.Drawing.Point(107, 33);
            this.lab_mail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_mail.Name = "lab_mail";
            this.lab_mail.Size = new System.Drawing.Size(40, 20);
            this.lab_mail.TabIndex = 64;
            this.lab_mail.Text = "Mail";
            this.lab_mail.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_modif_CUIT_RazonSocial
            // 
            this.btn_modif_CUIT_RazonSocial.Location = new System.Drawing.Point(18, 283);
            this.btn_modif_CUIT_RazonSocial.Name = "btn_modif_CUIT_RazonSocial";
            this.btn_modif_CUIT_RazonSocial.Size = new System.Drawing.Size(235, 50);
            this.btn_modif_CUIT_RazonSocial.TabIndex = 84;
            this.btn_modif_CUIT_RazonSocial.Text = "Modificar CUIT y/o Razon Social";
            this.btn_modif_CUIT_RazonSocial.UseVisualStyleBackColor = true;
            this.btn_modif_CUIT_RazonSocial.Click += new System.EventHandler(this.btn_modif_CUIT_RazonSocial_Click);
            // 
            // Modificacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(561, 361);
            this.Controls.Add(this.btn_modif_CUIT_RazonSocial);
            this.Controls.Add(this.txt_codigoPostal);
            this.Controls.Add(this.lab_codigoPostal);
            this.Controls.Add(this.btn_Guardar);
            this.Controls.Add(this.txt_ciudad);
            this.Controls.Add(this.lab_ciudad);
            this.Controls.Add(this.txt_localidad);
            this.Controls.Add(this.lab_localidad);
            this.Controls.Add(this.txt_depto);
            this.Controls.Add(this.lab_depto);
            this.Controls.Add(this.txt_piso);
            this.Controls.Add(this.lab_piso);
            this.Controls.Add(this.txt_direccion);
            this.Controls.Add(this.lab_direccion);
            this.Controls.Add(this.txt_telefono);
            this.Controls.Add(this.lab_telefono);
            this.Controls.Add(this.txt_mail);
            this.Controls.Add(this.lab_mail);
            this.Name = "Modificacion";
            this.Text = "Modificacion";
            this.Load += new System.EventHandler(this.Modificacion_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_codigoPostal;
        private System.Windows.Forms.Label lab_codigoPostal;
        private System.Windows.Forms.Button btn_Guardar;
        private System.Windows.Forms.TextBox txt_ciudad;
        private System.Windows.Forms.Label lab_ciudad;
        private System.Windows.Forms.TextBox txt_localidad;
        private System.Windows.Forms.Label lab_localidad;
        private System.Windows.Forms.TextBox txt_depto;
        private System.Windows.Forms.Label lab_depto;
        private System.Windows.Forms.TextBox txt_piso;
        private System.Windows.Forms.Label lab_piso;
        private System.Windows.Forms.TextBox txt_direccion;
        private System.Windows.Forms.Label lab_direccion;
        private System.Windows.Forms.TextBox txt_telefono;
        private System.Windows.Forms.Label lab_telefono;
        private System.Windows.Forms.TextBox txt_mail;
        private System.Windows.Forms.Label lab_mail;
        private System.Windows.Forms.Button btn_modif_CUIT_RazonSocial;
    }
}