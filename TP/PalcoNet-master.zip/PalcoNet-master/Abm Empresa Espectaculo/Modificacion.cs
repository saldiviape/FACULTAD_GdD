﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Abm_Empresa_Espectaculo
{
    public partial class Modificacion : Form
    {
        string empresaActual;
        comandos cma = new comandos();

        public Modificacion(string empresa)
        {
            this.empresaActual = empresa;
            InitializeComponent();
        }

        private void Modificacion_Load(object sender, EventArgs e)
        {
            cma.llenarTextBoxEmpresa(txt_mail, "mail", empresaActual);
            cma.llenarTextBoxEmpresa(txt_telefono, "telefono", empresaActual);
            cma.llenarTextBoxEmpresa(txt_direccion, "direccion", empresaActual);
            cma.llenarTextBoxEmpresa(txt_piso, "nroPiso", empresaActual);
            cma.llenarTextBoxEmpresa(txt_depto, "depto", empresaActual);
            cma.llenarTextBoxEmpresa(txt_localidad, "localidad", empresaActual);
            cma.llenarTextBoxEmpresa(txt_codigoPostal, "codPostal", empresaActual);
            cma.llenarTextBoxEmpresa(txt_ciudad, "ciudad", empresaActual);
        }

        private bool modificarEmpresa()
        {
            try
            {
                string modifEmpresa = string.Format("EXEC DATEROS.modificacionEmpresa '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}'", 
                    empresaActual.Trim(), txt_mail.Text.Trim(), txt_telefono.Text.Trim(), txt_direccion.Text.Trim(), 
                    txt_piso.Text.Trim(), txt_depto.Text.Trim(), txt_localidad.Text.Trim(), txt_codigoPostal.Text.Trim(), 
                    txt_ciudad.Text.Trim());
                libreria.Utilidades.ejecutar(modifEmpresa);

                MessageBox.Show("Se han realizado todas las modificaciones");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_Guardar_Click(object sender, EventArgs e)
        {
            this.modificarEmpresa();
            this.Hide();
        }

        private void btn_modif_CUIT_RazonSocial_Click(object sender, EventArgs e)
        {
            Abm_Empresa_Espectaculo.Modificacion_Cuit_RazonSocial mcr = new Abm_Empresa_Espectaculo.Modificacion_Cuit_RazonSocial(empresaActual);
            mcr.Show();
        }
    }
}