﻿namespace PalcoNet.Abm_Grado
{
    partial class frm_abmGradoDePublicacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_modificarComision = new System.Windows.Forms.Button();
            this.btn_alta = new System.Windows.Forms.Button();
            this.btn_baja = new System.Windows.Forms.Button();
            this.btn_habilitarGrado = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_modificarComision
            // 
            this.btn_modificarComision.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_modificarComision.Location = new System.Drawing.Point(78, 101);
            this.btn_modificarComision.Name = "btn_modificarComision";
            this.btn_modificarComision.Size = new System.Drawing.Size(233, 56);
            this.btn_modificarComision.TabIndex = 5;
            this.btn_modificarComision.Text = "Modificar Comision";
            this.btn_modificarComision.UseVisualStyleBackColor = true;
            this.btn_modificarComision.Click += new System.EventHandler(this.btn_modificarComision_Click);
            // 
            // btn_alta
            // 
            this.btn_alta.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_alta.Location = new System.Drawing.Point(78, 28);
            this.btn_alta.Name = "btn_alta";
            this.btn_alta.Size = new System.Drawing.Size(233, 56);
            this.btn_alta.TabIndex = 4;
            this.btn_alta.Text = "Agregar Nuevo Grado";
            this.btn_alta.UseVisualStyleBackColor = true;
            this.btn_alta.Click += new System.EventHandler(this.btn_alta_Click);
            // 
            // btn_baja
            // 
            this.btn_baja.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_baja.Location = new System.Drawing.Point(78, 172);
            this.btn_baja.Name = "btn_baja";
            this.btn_baja.Size = new System.Drawing.Size(233, 56);
            this.btn_baja.TabIndex = 6;
            this.btn_baja.Text = "Baja Grado";
            this.btn_baja.UseVisualStyleBackColor = true;
            this.btn_baja.Click += new System.EventHandler(this.btn_baja_Click);
            // 
            // btn_habilitarGrado
            // 
            this.btn_habilitarGrado.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_habilitarGrado.Location = new System.Drawing.Point(78, 244);
            this.btn_habilitarGrado.Name = "btn_habilitarGrado";
            this.btn_habilitarGrado.Size = new System.Drawing.Size(233, 56);
            this.btn_habilitarGrado.TabIndex = 7;
            this.btn_habilitarGrado.Text = "Habilitacion Grado";
            this.btn_habilitarGrado.UseVisualStyleBackColor = true;
            this.btn_habilitarGrado.Click += new System.EventHandler(this.btn_habilitarGrado_Click);
            // 
            // frm_abmGradoDePublicacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(379, 328);
            this.Controls.Add(this.btn_habilitarGrado);
            this.Controls.Add(this.btn_baja);
            this.Controls.Add(this.btn_modificarComision);
            this.Controls.Add(this.btn_alta);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frm_abmGradoDePublicacion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ABM de Grado de Publicación";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_modificarComision;
        private System.Windows.Forms.Button btn_alta;
        private System.Windows.Forms.Button btn_baja;
        private System.Windows.Forms.Button btn_habilitarGrado;
    }
}