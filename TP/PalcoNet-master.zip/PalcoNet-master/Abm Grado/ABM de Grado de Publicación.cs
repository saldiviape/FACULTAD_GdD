﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Abm_Grado
{
    public partial class frm_abmGradoDePublicacion : Form
    {
        public frm_abmGradoDePublicacion()
        {
            InitializeComponent();
        }

        private void btn_modificarComision_Click(object sender, EventArgs e)
        {
            Abm_Grado.Modificar_Comision mc = new Abm_Grado.Modificar_Comision();
            mc.Show();
        }

        private void btn_alta_Click(object sender, EventArgs e)
        {
            Abm_Grado.Alta ag = new Abm_Grado.Alta();
            ag.Show();
        }

        private void btn_baja_Click(object sender, EventArgs e)
        {
            Abm_Grado.Baja bg = new Abm_Grado.Baja();
            bg.Show();
        }

        private void btn_habilitarGrado_Click(object sender, EventArgs e)
        {
            Abm_Grado.Habilitacion hg = new Abm_Grado.Habilitacion();
            hg.Show();
        }
    }
}
