﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Abm_Grado
{
    public partial class Alta : Form
    {
        public Alta()
        {
            InitializeComponent();
        }

        private void btn_Limpiar_Click(object sender, EventArgs e)
        {
            Limpiar limpiar = new Limpiar();
            limpiar.limpiarCampos(this);
        }

        private bool altaGrado()
        {
            try
            {
                string altaGrado = string.Format("EXEC DATEROS.altaGrado '{0}', '{1}'", txt_prioridad.Text.Trim(), txt_porcentaje.Text.Trim());
                libreria.Utilidades.ejecutar(altaGrado);

                MessageBox.Show("Se ha creado correctamente el nuevo grado");
                this.Hide();
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_Guardar_Click(object sender, EventArgs e)
        {
            this.altaGrado();         
        }
    }
}
