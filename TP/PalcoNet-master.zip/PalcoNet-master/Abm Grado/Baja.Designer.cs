﻿namespace PalcoNet.Abm_Grado
{
    partial class Baja
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_grado = new System.Windows.Forms.Label();
            this.btn_baja = new System.Windows.Forms.Button();
            this.cmb_grado = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lbl_grado
            // 
            this.lbl_grado.AutoSize = true;
            this.lbl_grado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_grado.Location = new System.Drawing.Point(23, 26);
            this.lbl_grado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_grado.Name = "lbl_grado";
            this.lbl_grado.Size = new System.Drawing.Size(170, 20);
            this.lbl_grado.TabIndex = 81;
            this.lbl_grado.Text = "Seleccione un Grado:";
            this.lbl_grado.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_baja
            // 
            this.btn_baja.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_baja.Location = new System.Drawing.Point(138, 66);
            this.btn_baja.Margin = new System.Windows.Forms.Padding(4);
            this.btn_baja.Name = "btn_baja";
            this.btn_baja.Size = new System.Drawing.Size(235, 50);
            this.btn_baja.TabIndex = 80;
            this.btn_baja.Text = "Dar de Baja";
            this.btn_baja.UseVisualStyleBackColor = true;
            this.btn_baja.Click += new System.EventHandler(this.btn_baja_Click);
            // 
            // cmb_grado
            // 
            this.cmb_grado.FormattingEnabled = true;
            this.cmb_grado.Location = new System.Drawing.Point(254, 26);
            this.cmb_grado.Name = "cmb_grado";
            this.cmb_grado.Size = new System.Drawing.Size(235, 24);
            this.cmb_grado.TabIndex = 79;
            // 
            // Baja
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(510, 135);
            this.Controls.Add(this.lbl_grado);
            this.Controls.Add(this.btn_baja);
            this.Controls.Add(this.cmb_grado);
            this.Name = "Baja";
            this.Text = "Baja";
            this.Load += new System.EventHandler(this.Baja_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_grado;
        private System.Windows.Forms.Button btn_baja;
        private System.Windows.Forms.ComboBox cmb_grado;
    }
}