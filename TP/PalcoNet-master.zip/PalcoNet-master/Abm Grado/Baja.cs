﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Abm_Grado
{
    public partial class Baja : Form
    {
        comandos cma = new comandos();

        public Baja()
        {
            InitializeComponent();
        }

        private bool bajaGrado()
        {
            try
            {
                string bajaGrado = string.Format("EXEC DATEROS.bajaGrado '{0}'", cmb_grado.SelectedValue.ToString());
                libreria.Utilidades.ejecutar(bajaGrado);

                MessageBox.Show("Se ha dado de baja el grado");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_baja_Click(object sender, EventArgs e)
        {
            this.bajaGrado();
            this.Hide();
        }

        private void Baja_Load(object sender, EventArgs e)
        {
            cma.cargarGrados(cmb_grado);
            cmb_grado.DropDownStyle = ComboBoxStyle.DropDownList;
        }
    }
}
