﻿namespace PalcoNet.Abm_Grado
{
    partial class Habilitacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_grado = new System.Windows.Forms.Label();
            this.btn_habilitar = new System.Windows.Forms.Button();
            this.cmb_grado = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lbl_grado
            // 
            this.lbl_grado.AutoSize = true;
            this.lbl_grado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_grado.Location = new System.Drawing.Point(25, 20);
            this.lbl_grado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_grado.Name = "lbl_grado";
            this.lbl_grado.Size = new System.Drawing.Size(170, 20);
            this.lbl_grado.TabIndex = 84;
            this.lbl_grado.Text = "Seleccione un Grado:";
            this.lbl_grado.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_habilitar
            // 
            this.btn_habilitar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_habilitar.Location = new System.Drawing.Point(140, 60);
            this.btn_habilitar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_habilitar.Name = "btn_habilitar";
            this.btn_habilitar.Size = new System.Drawing.Size(235, 50);
            this.btn_habilitar.TabIndex = 83;
            this.btn_habilitar.Text = "Habilitar Grado";
            this.btn_habilitar.UseVisualStyleBackColor = true;
            this.btn_habilitar.Click += new System.EventHandler(this.btn_habilitar_Click);
            // 
            // cmb_grado
            // 
            this.cmb_grado.FormattingEnabled = true;
            this.cmb_grado.Location = new System.Drawing.Point(256, 20);
            this.cmb_grado.Name = "cmb_grado";
            this.cmb_grado.Size = new System.Drawing.Size(235, 24);
            this.cmb_grado.TabIndex = 82;
            // 
            // Habilitacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(525, 127);
            this.Controls.Add(this.lbl_grado);
            this.Controls.Add(this.btn_habilitar);
            this.Controls.Add(this.cmb_grado);
            this.Name = "Habilitacion";
            this.Text = "Habilitacion";
            this.Load += new System.EventHandler(this.Habilitacion_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_grado;
        private System.Windows.Forms.Button btn_habilitar;
        private System.Windows.Forms.ComboBox cmb_grado;
    }
}