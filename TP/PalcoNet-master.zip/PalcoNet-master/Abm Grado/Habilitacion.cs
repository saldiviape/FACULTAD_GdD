﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Abm_Grado
{
    public partial class Habilitacion : Form
    {
        comandos cma = new comandos();

        public Habilitacion()
        {
            InitializeComponent();
        }

        private bool habilitarGrado()
        {
            try
            {
                string habilitarGrado = string.Format("EXEC DATEROS.habilitarGrado '{0}'", cmb_grado.SelectedValue.ToString());
                libreria.Utilidades.ejecutar(habilitarGrado);

                MessageBox.Show("Se ha habilitado el grado");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_habilitar_Click(object sender, EventArgs e)
        {
            this.habilitarGrado();
            this.Hide();
        }

        private void Habilitacion_Load(object sender, EventArgs e)
        {
            cma.cargarGradosInhabilitados(cmb_grado);
            cmb_grado.DropDownStyle = ComboBoxStyle.DropDownList;
        }
    }
}