﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Abm_Grado
{
    public partial class Modificar_Comision : Form
    {
        comandos cma = new comandos();
     
        public Modificar_Comision()
        {
            InitializeComponent();
        }

        private bool modifGrado()
        {
            try
            {
                string modifGrado = string.Format("EXEC DATEROS.modifGrado '{0}', '{1}'", cmb_grado.SelectedValue.ToString(), txt_porcentaje.Text.Trim());
                libreria.Utilidades.ejecutar(modifGrado);

                MessageBox.Show("Se ha modificado la comision");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_Guardar_Click(object sender, EventArgs e)
        {
            this.modifGrado();
            this.Hide();
        }

        private void Modificar_Comision_Load(object sender, EventArgs e)
        {
            cma.cargarGrados(cmb_grado);
            cmb_grado.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void btn_Limpiar_Click(object sender, EventArgs e)
        {
            Limpiar limpiar = new Limpiar();
            limpiar.limpiarCampos(this);
        }
    }
}