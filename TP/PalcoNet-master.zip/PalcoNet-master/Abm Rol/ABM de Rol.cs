﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Abm_Rol
{
    public partial class frm_abmRol : Form
    {
        public frm_abmRol()
        {
            InitializeComponent();
        }

        private void btn_baja_Click(object sender, EventArgs e)
        {
            Abm_Rol.ListadoDeSeleccion_Rol lsr = new Abm_Rol.ListadoDeSeleccion_Rol();
            lsr.Show();
        }

        private void btn_alta_Click(object sender, EventArgs e)
        {
            Abm_Rol.Alta alt = new Abm_Rol.Alta();
            alt.Show();
        }

        private void frm_abmRol_Load(object sender, EventArgs e)
        {

        }
    }
}
