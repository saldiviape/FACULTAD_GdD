﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Abm_Rol
{
    public partial class Agregar_Funcionalidad : Form
    {

        comandos cma = new comandos();
        string rolSeleccionado;

        public Agregar_Funcionalidad(string rolSelec)
        {
            InitializeComponent();
            this.rolSeleccionado = rolSelec;
        }

        private bool agregarFuncionalidad()
        {
            try
            {
                string funcSeleccionada = cmb_agregar_func.SelectedValue.ToString();

                string cmd = string.Format("EXEC DATEROS.agregarFuncionalidad '{0}', '{1}'", funcSeleccionada, rolSeleccionado);
                libreria.Utilidades.ejecutar(cmd);

                MessageBox.Show("Se ha agregado la nueva funcionalidad");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_agregarFunc_Click(object sender, EventArgs e)
        {
            this.agregarFuncionalidad();
            this.Hide();
        }

        private void Agregar_Funcionalidad_Load(object sender, EventArgs e)
        {
            cma.mostrarTodasFuncionalidades(cmb_agregar_func);
            cmb_agregar_func.DropDownStyle = ComboBoxStyle.DropDownList;
        }
    }
}
