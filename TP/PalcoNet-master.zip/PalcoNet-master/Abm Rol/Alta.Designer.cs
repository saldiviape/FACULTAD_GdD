﻿namespace PalcoNet.Abm_Rol
{
    partial class Alta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.lab_seleccionFuncionalidades = new System.Windows.Forms.Label();
            this.chk_abmRol = new System.Windows.Forms.CheckBox();
            this.chk_listadoEstadistico = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.chk_abmCliente = new System.Windows.Forms.CheckBox();
            this.btn_Limpiar = new System.Windows.Forms.Button();
            this.chk_canjeAdminPuntos = new System.Windows.Forms.CheckBox();
            this.btn_Guardar = new System.Windows.Forms.Button();
            this.chk_abmEmpresa = new System.Windows.Forms.CheckBox();
            this.chk_historialCliente = new System.Windows.Forms.CheckBox();
            this.chk_regUsuario = new System.Windows.Forms.CheckBox();
            this.lab_nombre = new System.Windows.Forms.Label();
            this.chk_Comprar = new System.Windows.Forms.CheckBox();
            this.chk_generarPublicacion = new System.Windows.Forms.CheckBox();
            this.chk_abmRubro = new System.Windows.Forms.CheckBox();
            this.chk_abmGradoPubli = new System.Windows.Forms.CheckBox();
            this.chk_editarPubli = new System.Windows.Forms.CheckBox();
            this.chk_GenerarPagoComisiones = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // txt_nombre
            // 
            this.txt_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nombre.Location = new System.Drawing.Point(184, 24);
            this.txt_nombre.Margin = new System.Windows.Forms.Padding(4);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(389, 26);
            this.txt_nombre.TabIndex = 85;
            // 
            // lab_seleccionFuncionalidades
            // 
            this.lab_seleccionFuncionalidades.AutoSize = true;
            this.lab_seleccionFuncionalidades.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_seleccionFuncionalidades.Location = new System.Drawing.Point(37, 80);
            this.lab_seleccionFuncionalidades.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_seleccionFuncionalidades.Name = "lab_seleccionFuncionalidades";
            this.lab_seleccionFuncionalidades.Size = new System.Drawing.Size(236, 20);
            this.lab_seleccionFuncionalidades.TabIndex = 82;
            this.lab_seleccionFuncionalidades.Text = "Selección de Funcionalidades:";
            this.lab_seleccionFuncionalidades.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // chk_abmRol
            // 
            this.chk_abmRol.AutoSize = true;
            this.chk_abmRol.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_abmRol.Location = new System.Drawing.Point(305, 79);
            this.chk_abmRol.Margin = new System.Windows.Forms.Padding(4);
            this.chk_abmRol.Name = "chk_abmRol";
            this.chk_abmRol.Size = new System.Drawing.Size(121, 24);
            this.chk_abmRol.TabIndex = 66;
            this.chk_abmRol.Text = "ABM de Rol";
            this.chk_abmRol.UseVisualStyleBackColor = true;
            // 
            // chk_listadoEstadistico
            // 
            this.chk_listadoEstadistico.AutoSize = true;
            this.chk_listadoEstadistico.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_listadoEstadistico.Location = new System.Drawing.Point(305, 463);
            this.chk_listadoEstadistico.Margin = new System.Windows.Forms.Padding(4);
            this.chk_listadoEstadistico.Name = "chk_listadoEstadistico";
            this.chk_listadoEstadistico.Size = new System.Drawing.Size(174, 24);
            this.chk_listadoEstadistico.TabIndex = 77;
            this.chk_listadoEstadistico.Text = "Listado Estadístico";
            this.chk_listadoEstadistico.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(38, 502);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(380, 18);
            this.label3.TabIndex = 81;
            this.label3.Text = "El nombre y al menos una funcionalidad son obligatorios";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // chk_abmCliente
            // 
            this.chk_abmCliente.AutoSize = true;
            this.chk_abmCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_abmCliente.Location = new System.Drawing.Point(305, 111);
            this.chk_abmCliente.Margin = new System.Windows.Forms.Padding(4);
            this.chk_abmCliente.Name = "chk_abmCliente";
            this.chk_abmCliente.Size = new System.Drawing.Size(148, 24);
            this.chk_abmCliente.TabIndex = 67;
            this.chk_abmCliente.Text = "ABM de Cliente";
            this.chk_abmCliente.UseVisualStyleBackColor = true;
            // 
            // btn_Limpiar
            // 
            this.btn_Limpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Limpiar.Location = new System.Drawing.Point(41, 530);
            this.btn_Limpiar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Limpiar.Name = "btn_Limpiar";
            this.btn_Limpiar.Size = new System.Drawing.Size(261, 50);
            this.btn_Limpiar.TabIndex = 79;
            this.btn_Limpiar.Text = "Limpiar";
            this.btn_Limpiar.UseVisualStyleBackColor = true;
            this.btn_Limpiar.Click += new System.EventHandler(this.btn_Limpiar_Click);
            // 
            // chk_canjeAdminPuntos
            // 
            this.chk_canjeAdminPuntos.AutoSize = true;
            this.chk_canjeAdminPuntos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_canjeAdminPuntos.Location = new System.Drawing.Point(305, 399);
            this.chk_canjeAdminPuntos.Margin = new System.Windows.Forms.Padding(4);
            this.chk_canjeAdminPuntos.Name = "chk_canjeAdminPuntos";
            this.chk_canjeAdminPuntos.Size = new System.Drawing.Size(283, 24);
            this.chk_canjeAdminPuntos.TabIndex = 76;
            this.chk_canjeAdminPuntos.Text = "Canje y Administración de Puntos";
            this.chk_canjeAdminPuntos.UseVisualStyleBackColor = true;
            // 
            // btn_Guardar
            // 
            this.btn_Guardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Guardar.Location = new System.Drawing.Point(312, 530);
            this.btn_Guardar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Guardar.Name = "btn_Guardar";
            this.btn_Guardar.Size = new System.Drawing.Size(261, 50);
            this.btn_Guardar.TabIndex = 78;
            this.btn_Guardar.Text = "Guardar";
            this.btn_Guardar.UseVisualStyleBackColor = true;
            this.btn_Guardar.Click += new System.EventHandler(this.btn_Guardar_Click);
            // 
            // chk_abmEmpresa
            // 
            this.chk_abmEmpresa.AutoSize = true;
            this.chk_abmEmpresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_abmEmpresa.Location = new System.Drawing.Point(305, 143);
            this.chk_abmEmpresa.Margin = new System.Windows.Forms.Padding(4);
            this.chk_abmEmpresa.Name = "chk_abmEmpresa";
            this.chk_abmEmpresa.Size = new System.Drawing.Size(163, 24);
            this.chk_abmEmpresa.TabIndex = 68;
            this.chk_abmEmpresa.Text = "ABM de Empresa";
            this.chk_abmEmpresa.UseVisualStyleBackColor = true;
            // 
            // chk_historialCliente
            // 
            this.chk_historialCliente.AutoSize = true;
            this.chk_historialCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_historialCliente.Location = new System.Drawing.Point(305, 367);
            this.chk_historialCliente.Margin = new System.Windows.Forms.Padding(4);
            this.chk_historialCliente.Name = "chk_historialCliente";
            this.chk_historialCliente.Size = new System.Drawing.Size(178, 24);
            this.chk_historialCliente.TabIndex = 75;
            this.chk_historialCliente.Text = "Historial del Cliente";
            this.chk_historialCliente.UseVisualStyleBackColor = true;
            // 
            // chk_regUsuario
            // 
            this.chk_regUsuario.AutoSize = true;
            this.chk_regUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_regUsuario.Location = new System.Drawing.Point(305, 175);
            this.chk_regUsuario.Margin = new System.Windows.Forms.Padding(4);
            this.chk_regUsuario.Name = "chk_regUsuario";
            this.chk_regUsuario.Size = new System.Drawing.Size(180, 24);
            this.chk_regUsuario.TabIndex = 69;
            this.chk_regUsuario.Text = "Registro de Usuario";
            this.chk_regUsuario.UseVisualStyleBackColor = true;
            // 
            // lab_nombre
            // 
            this.lab_nombre.AutoSize = true;
            this.lab_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_nombre.Location = new System.Drawing.Point(37, 24);
            this.lab_nombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_nombre.Name = "lab_nombre";
            this.lab_nombre.Size = new System.Drawing.Size(125, 20);
            this.lab_nombre.TabIndex = 80;
            this.lab_nombre.Text = "Nombre del Rol";
            this.lab_nombre.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // chk_Comprar
            // 
            this.chk_Comprar.AutoSize = true;
            this.chk_Comprar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_Comprar.Location = new System.Drawing.Point(305, 335);
            this.chk_Comprar.Margin = new System.Windows.Forms.Padding(4);
            this.chk_Comprar.Name = "chk_Comprar";
            this.chk_Comprar.Size = new System.Drawing.Size(96, 24);
            this.chk_Comprar.TabIndex = 74;
            this.chk_Comprar.Text = "Comprar";
            this.chk_Comprar.UseVisualStyleBackColor = true;
            // 
            // chk_generarPublicacion
            // 
            this.chk_generarPublicacion.AutoSize = true;
            this.chk_generarPublicacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_generarPublicacion.Location = new System.Drawing.Point(305, 271);
            this.chk_generarPublicacion.Margin = new System.Windows.Forms.Padding(4);
            this.chk_generarPublicacion.Name = "chk_generarPublicacion";
            this.chk_generarPublicacion.Size = new System.Drawing.Size(183, 24);
            this.chk_generarPublicacion.TabIndex = 72;
            this.chk_generarPublicacion.Text = "Generar Publicación";
            this.chk_generarPublicacion.UseVisualStyleBackColor = true;
            // 
            // chk_abmRubro
            // 
            this.chk_abmRubro.AutoSize = true;
            this.chk_abmRubro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_abmRubro.Location = new System.Drawing.Point(305, 207);
            this.chk_abmRubro.Margin = new System.Windows.Forms.Padding(4);
            this.chk_abmRubro.Name = "chk_abmRubro";
            this.chk_abmRubro.Size = new System.Drawing.Size(141, 24);
            this.chk_abmRubro.TabIndex = 70;
            this.chk_abmRubro.Text = "ABM de Rubro";
            this.chk_abmRubro.UseVisualStyleBackColor = true;
            // 
            // chk_abmGradoPubli
            // 
            this.chk_abmGradoPubli.AutoSize = true;
            this.chk_abmGradoPubli.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_abmGradoPubli.Location = new System.Drawing.Point(305, 239);
            this.chk_abmGradoPubli.Margin = new System.Windows.Forms.Padding(4);
            this.chk_abmGradoPubli.Name = "chk_abmGradoPubli";
            this.chk_abmGradoPubli.Size = new System.Drawing.Size(256, 24);
            this.chk_abmGradoPubli.TabIndex = 71;
            this.chk_abmGradoPubli.Text = "ABM de Grado de Publicación";
            this.chk_abmGradoPubli.UseVisualStyleBackColor = true;
            // 
            // chk_editarPubli
            // 
            this.chk_editarPubli.AutoSize = true;
            this.chk_editarPubli.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_editarPubli.Location = new System.Drawing.Point(305, 303);
            this.chk_editarPubli.Margin = new System.Windows.Forms.Padding(4);
            this.chk_editarPubli.Name = "chk_editarPubli";
            this.chk_editarPubli.Size = new System.Drawing.Size(166, 24);
            this.chk_editarPubli.TabIndex = 73;
            this.chk_editarPubli.Text = "Editar Publicación";
            this.chk_editarPubli.UseVisualStyleBackColor = true;
            // 
            // chk_GenerarPagoComisiones
            // 
            this.chk_GenerarPagoComisiones.AutoSize = true;
            this.chk_GenerarPagoComisiones.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_GenerarPagoComisiones.Location = new System.Drawing.Point(305, 431);
            this.chk_GenerarPagoComisiones.Margin = new System.Windows.Forms.Padding(4);
            this.chk_GenerarPagoComisiones.Name = "chk_GenerarPagoComisiones";
            this.chk_GenerarPagoComisiones.Size = new System.Drawing.Size(251, 24);
            this.chk_GenerarPagoComisiones.TabIndex = 86;
            this.chk_GenerarPagoComisiones.Text = "Generar Pago de Comisiones";
            this.chk_GenerarPagoComisiones.UseVisualStyleBackColor = true;
            // 
            // Alta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(602, 598);
            this.Controls.Add(this.chk_GenerarPagoComisiones);
            this.Controls.Add(this.txt_nombre);
            this.Controls.Add(this.lab_seleccionFuncionalidades);
            this.Controls.Add(this.chk_abmRol);
            this.Controls.Add(this.chk_listadoEstadistico);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.chk_abmCliente);
            this.Controls.Add(this.btn_Limpiar);
            this.Controls.Add(this.chk_canjeAdminPuntos);
            this.Controls.Add(this.btn_Guardar);
            this.Controls.Add(this.chk_abmEmpresa);
            this.Controls.Add(this.chk_historialCliente);
            this.Controls.Add(this.chk_regUsuario);
            this.Controls.Add(this.lab_nombre);
            this.Controls.Add(this.chk_Comprar);
            this.Controls.Add(this.chk_generarPublicacion);
            this.Controls.Add(this.chk_abmRubro);
            this.Controls.Add(this.chk_abmGradoPubli);
            this.Controls.Add(this.chk_editarPubli);
            this.Name = "Alta";
            this.Text = "Alta de Rol";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.Label lab_seleccionFuncionalidades;
        private System.Windows.Forms.CheckBox chk_abmRol;
        private System.Windows.Forms.CheckBox chk_listadoEstadistico;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox chk_abmCliente;
        private System.Windows.Forms.Button btn_Limpiar;
        private System.Windows.Forms.CheckBox chk_canjeAdminPuntos;
        private System.Windows.Forms.Button btn_Guardar;
        private System.Windows.Forms.CheckBox chk_abmEmpresa;
        private System.Windows.Forms.CheckBox chk_historialCliente;
        private System.Windows.Forms.CheckBox chk_regUsuario;
        private System.Windows.Forms.Label lab_nombre;
        private System.Windows.Forms.CheckBox chk_Comprar;
        private System.Windows.Forms.CheckBox chk_generarPublicacion;
        private System.Windows.Forms.CheckBox chk_abmRubro;
        private System.Windows.Forms.CheckBox chk_abmGradoPubli;
        private System.Windows.Forms.CheckBox chk_editarPubli;
        private System.Windows.Forms.CheckBox chk_GenerarPagoComisiones;

    }
}