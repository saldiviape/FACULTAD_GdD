﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Abm_Rol
{
    public partial class Alta : Form
    {
        public Alta()
        {
            InitializeComponent();
        }

        private bool altaRol()
        {
            var CheckBoxList = this.Controls.OfType<CheckBox>().ToList();

            try
            {
                string altaRol = string.Format("EXEC DATEROS.altaRol '{0}'", txt_nombre.Text.Trim());
                libreria.Utilidades.ejecutar(altaRol);

                foreach (CheckBox chk in CheckBoxList)
                {
                    if (chk.Checked)
                    {
                        string asignoRol = string.Format("EXEC DATEROS.asignarFuncRol '{0}', '{1}'", txt_nombre.Text.Trim(), chk.Text);
                        libreria.Utilidades.ejecutar(asignoRol);
                    }
                }
                MessageBox.Show("Se ha creado correctamente el nuevo rol");
                this.Hide();
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_Limpiar_Click(object sender, EventArgs e)
        {
            Limpiar limpiar = new Limpiar();
            limpiar.limpiarCampos(this);
        }

        private void btn_Guardar_Click(object sender, EventArgs e)
        {
            this.altaRol();       
        }
    }
}
