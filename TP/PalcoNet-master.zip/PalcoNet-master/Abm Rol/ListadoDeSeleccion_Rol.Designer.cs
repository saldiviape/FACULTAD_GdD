﻿namespace PalcoNet.Abm_Rol
{
    partial class ListadoDeSeleccion_Rol
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_habilitar = new System.Windows.Forms.Button();
            this.btn_agregarFunc = new System.Windows.Forms.Button();
            this.btn_quitarFunc = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_Limpiar = new System.Windows.Forms.Button();
            this.btn_Buscar = new System.Windows.Forms.Button();
            this.chk_exacto_nom = new System.Windows.Forms.CheckBox();
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.lab_nombre = new System.Windows.Forms.Label();
            this.btn_deshabilitar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_habilitar
            // 
            this.btn_habilitar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_habilitar.Location = new System.Drawing.Point(130, 522);
            this.btn_habilitar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_habilitar.Name = "btn_habilitar";
            this.btn_habilitar.Size = new System.Drawing.Size(235, 50);
            this.btn_habilitar.TabIndex = 95;
            this.btn_habilitar.Text = "Habilitar Rol";
            this.btn_habilitar.UseVisualStyleBackColor = true;
            this.btn_habilitar.Click += new System.EventHandler(this.btn_habilitar_Click);
            // 
            // btn_agregarFunc
            // 
            this.btn_agregarFunc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_agregarFunc.Location = new System.Drawing.Point(130, 452);
            this.btn_agregarFunc.Margin = new System.Windows.Forms.Padding(4);
            this.btn_agregarFunc.Name = "btn_agregarFunc";
            this.btn_agregarFunc.Size = new System.Drawing.Size(235, 50);
            this.btn_agregarFunc.TabIndex = 94;
            this.btn_agregarFunc.Text = "Agregar Funcionalidades";
            this.btn_agregarFunc.UseVisualStyleBackColor = true;
            this.btn_agregarFunc.Click += new System.EventHandler(this.btn_agregarFunc_Click);
            // 
            // btn_quitarFunc
            // 
            this.btn_quitarFunc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_quitarFunc.Location = new System.Drawing.Point(390, 452);
            this.btn_quitarFunc.Margin = new System.Windows.Forms.Padding(4);
            this.btn_quitarFunc.Name = "btn_quitarFunc";
            this.btn_quitarFunc.Size = new System.Drawing.Size(235, 50);
            this.btn_quitarFunc.TabIndex = 93;
            this.btn_quitarFunc.Text = "Quitar Funcionalidades";
            this.btn_quitarFunc.UseVisualStyleBackColor = true;
            this.btn_quitarFunc.Click += new System.EventHandler(this.btn_quitarFunc_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(23, 179);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(707, 247);
            this.dataGridView1.TabIndex = 91;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(19, 22);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 24);
            this.label1.TabIndex = 90;
            this.label1.Text = "Filtros de Búsqueda";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btn_Limpiar
            // 
            this.btn_Limpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Limpiar.Location = new System.Drawing.Point(23, 113);
            this.btn_Limpiar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Limpiar.Name = "btn_Limpiar";
            this.btn_Limpiar.Size = new System.Drawing.Size(235, 50);
            this.btn_Limpiar.TabIndex = 89;
            this.btn_Limpiar.Text = "Limpiar";
            this.btn_Limpiar.UseVisualStyleBackColor = true;
            this.btn_Limpiar.Click += new System.EventHandler(this.btn_Limpiar_Click);
            // 
            // btn_Buscar
            // 
            this.btn_Buscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Buscar.Location = new System.Drawing.Point(495, 113);
            this.btn_Buscar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Buscar.Name = "btn_Buscar";
            this.btn_Buscar.Size = new System.Drawing.Size(235, 50);
            this.btn_Buscar.TabIndex = 88;
            this.btn_Buscar.Text = "Buscar";
            this.btn_Buscar.UseVisualStyleBackColor = true;
            this.btn_Buscar.Click += new System.EventHandler(this.btn_Buscar_Click);
            // 
            // chk_exacto_nom
            // 
            this.chk_exacto_nom.AutoSize = true;
            this.chk_exacto_nom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_exacto_nom.Location = new System.Drawing.Point(591, 60);
            this.chk_exacto_nom.Margin = new System.Windows.Forms.Padding(4);
            this.chk_exacto_nom.Name = "chk_exacto_nom";
            this.chk_exacto_nom.Size = new System.Drawing.Size(126, 24);
            this.chk_exacto_nom.TabIndex = 87;
            this.chk_exacto_nom.Text = "Texto exacto";
            this.chk_exacto_nom.UseVisualStyleBackColor = true;
            this.chk_exacto_nom.CheckedChanged += new System.EventHandler(this.chk_exacto_nom_CheckedChanged);
            // 
            // txt_nombre
            // 
            this.txt_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nombre.Location = new System.Drawing.Point(187, 58);
            this.txt_nombre.Margin = new System.Windows.Forms.Padding(4);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(389, 26);
            this.txt_nombre.TabIndex = 86;
            this.txt_nombre.TextChanged += new System.EventHandler(this.txt_nombre_TextChanged);
            // 
            // lab_nombre
            // 
            this.lab_nombre.AutoSize = true;
            this.lab_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_nombre.Location = new System.Drawing.Point(41, 58);
            this.lab_nombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_nombre.Name = "lab_nombre";
            this.lab_nombre.Size = new System.Drawing.Size(125, 20);
            this.lab_nombre.TabIndex = 85;
            this.lab_nombre.Text = "Nombre del Rol";
            this.lab_nombre.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_nombre.Click += new System.EventHandler(this.lab_nombre_Click);
            // 
            // btn_deshabilitar
            // 
            this.btn_deshabilitar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_deshabilitar.Location = new System.Drawing.Point(390, 522);
            this.btn_deshabilitar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_deshabilitar.Name = "btn_deshabilitar";
            this.btn_deshabilitar.Size = new System.Drawing.Size(235, 50);
            this.btn_deshabilitar.TabIndex = 96;
            this.btn_deshabilitar.Text = "Deshabilitar/Eliminar Rol";
            this.btn_deshabilitar.UseVisualStyleBackColor = true;
            this.btn_deshabilitar.Click += new System.EventHandler(this.btn_deshabilitar_Click);
            // 
            // ListadoDeSeleccion_Rol
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(749, 599);
            this.Controls.Add(this.btn_deshabilitar);
            this.Controls.Add(this.btn_habilitar);
            this.Controls.Add(this.btn_agregarFunc);
            this.Controls.Add(this.btn_quitarFunc);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Limpiar);
            this.Controls.Add(this.btn_Buscar);
            this.Controls.Add(this.chk_exacto_nom);
            this.Controls.Add(this.txt_nombre);
            this.Controls.Add(this.lab_nombre);
            this.Name = "ListadoDeSeleccion_Rol";
            this.Text = "ListadoDeSeleccion_Rol";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_habilitar;
        private System.Windows.Forms.Button btn_agregarFunc;
        private System.Windows.Forms.Button btn_quitarFunc;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Limpiar;
        private System.Windows.Forms.Button btn_Buscar;
        private System.Windows.Forms.CheckBox chk_exacto_nom;
        private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.Label lab_nombre;
        private System.Windows.Forms.Button btn_deshabilitar;
    }
}