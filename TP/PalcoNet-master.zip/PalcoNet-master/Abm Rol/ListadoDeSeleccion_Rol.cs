﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Abm_Rol
{
    public partial class ListadoDeSeleccion_Rol : Form
    {

         comandos cma = new comandos();

        public ListadoDeSeleccion_Rol()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_Buscar_Click(object sender, EventArgs e)
        {
            if (chk_exacto_nom.CheckState.ToString() == "Checked")
                try
                {
                    cma.llenarDataGridView(dataGridView1, "SELECT * FROM DATEROS.rol WHERE nombre='" + txt_nombre.Text + "'");
                }
                catch (Exception error)
                {
                    MessageBox.Show("Ha ocurrido un error: " + error.Message);
                }
            else
                try
                {
                    string nombre = txt_nombre.Text.ToString();
                    cma.llenarDataGridView(dataGridView1, "SELECT DISTINCT * FROM DATEROS.rol WHERE nombre LIKE '" + txt_nombre.Text + "' + '%'");
                }
                catch (Exception error)
                {
                    MessageBox.Show("Ha ocurrido un error: " + error.Message);
                } 
        }

        private void btn_agregarFunc_Click(object sender, EventArgs e)
        {
            Abm_Rol.Agregar_Funcionalidad af = new Agregar_Funcionalidad(dataGridView1.CurrentRow.Cells[0].Value.ToString());
            af.Show();
        }

        private void btn_Limpiar_Click(object sender, EventArgs e)
        {
            Limpiar limpiar = new Limpiar();
            limpiar.limpiarCampos(this);
        }

        private void btn_quitarFunc_Click(object sender, EventArgs e)
        {
            Abm_Rol.Quitar_Funcionalidad qf = new Quitar_Funcionalidad(dataGridView1.CurrentRow.Cells[0].Value.ToString());
            qf.Show();
        }

        private bool habilitarRol()
        {
            try
            {
                string cmd = string.Format("EXEC DATEROS.habilitarRol '{0}'", dataGridView1.CurrentRow.Cells[0].Value.ToString());
                libreria.Utilidades.ejecutar(cmd);

                MessageBox.Show("Se ha habilitado el rol");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private bool deshabilitarRol()
        {
            try
            {
                string cmd = string.Format("EXEC DATEROS.deshabilitarRol '{0}'", dataGridView1.CurrentRow.Cells[0].Value.ToString());
                libreria.Utilidades.ejecutar(cmd);

                MessageBox.Show("Se ha deshabilitado el rol");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_habilitar_Click(object sender, EventArgs e)
        {
            this.habilitarRol();
        }

        private void btn_deshabilitar_Click(object sender, EventArgs e)
        {
            this.deshabilitarRol();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void chk_exacto_nom_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void txt_nombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void lab_nombre_Click(object sender, EventArgs e)
        {

        }

    }
}
