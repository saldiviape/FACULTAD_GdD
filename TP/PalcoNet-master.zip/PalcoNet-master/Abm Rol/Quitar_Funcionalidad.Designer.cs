﻿namespace PalcoNet.Abm_Rol
{
    partial class Quitar_Funcionalidad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_quitarFunc = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.cmb_eliminar_func = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btn_quitarFunc
            // 
            this.btn_quitarFunc.Location = new System.Drawing.Point(240, 71);
            this.btn_quitarFunc.Name = "btn_quitarFunc";
            this.btn_quitarFunc.Size = new System.Drawing.Size(203, 40);
            this.btn_quitarFunc.TabIndex = 8;
            this.btn_quitarFunc.Text = "Quitar Funcionalidad";
            this.btn_quitarFunc.UseVisualStyleBackColor = true;
            this.btn_quitarFunc.Click += new System.EventHandler(this.btn_quitarFunc_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(308, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "Seleccione la funcionalidad que desee eliminar:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // cmb_eliminar_func
            // 
            this.cmb_eliminar_func.FormattingEnabled = true;
            this.cmb_eliminar_func.Location = new System.Drawing.Point(360, 21);
            this.cmb_eliminar_func.Name = "cmb_eliminar_func";
            this.cmb_eliminar_func.Size = new System.Drawing.Size(285, 24);
            this.cmb_eliminar_func.TabIndex = 6;
            this.cmb_eliminar_func.SelectedIndexChanged += new System.EventHandler(this.cmb_eliminar_func_SelectedIndexChanged);
            // 
            // Quitar_Funcionalidad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(687, 136);
            this.Controls.Add(this.btn_quitarFunc);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmb_eliminar_func);
            this.Name = "Quitar_Funcionalidad";
            this.Text = "Quitar_Funcionalidad";
            this.Load += new System.EventHandler(this.Quitar_Funcionalidad_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_quitarFunc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmb_eliminar_func;
    }
}