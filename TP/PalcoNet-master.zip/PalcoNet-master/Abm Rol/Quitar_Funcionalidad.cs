﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Abm_Rol
{
    public partial class Quitar_Funcionalidad : Form
    {
        comandos cma = new comandos();
        string rolSeleccionado;

        public Quitar_Funcionalidad(string rolSelec)
        {
            InitializeComponent();
            this.rolSeleccionado = rolSelec;
        }

        private bool quitarFuncionalidad()
        {
            try
            {
                string funcSeleccionada1 = cmb_eliminar_func.SelectedValue.ToString();

                string cmd = string.Format("EXEC DATEROS.quitarFuncionalidad '{0}', '{1}'", funcSeleccionada1, rolSeleccionado);
                libreria.Utilidades.ejecutar(cmd);

                MessageBox.Show("Se ha quitado la funcionalidad");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_quitarFunc_Click(object sender, EventArgs e)
        {
            this.quitarFuncionalidad();
            this.Hide();
        }

        private void Quitar_Funcionalidad_Load(object sender, EventArgs e)
        {
            cma.cargarFuncionalidadesRol(cmb_eliminar_func, rolSeleccionado);
            cmb_eliminar_func.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void cmb_eliminar_func_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
