﻿namespace PalcoNet.Canje_Puntos
{
    partial class frm_canjeYAdministracionDePuntos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lab_usuario = new System.Windows.Forms.Label();
            this.lab_puntosVencidos = new System.Windows.Forms.Label();
            this.txt_puntosVencidos = new System.Windows.Forms.TextBox();
            this.lab_puntosDisponibles = new System.Windows.Forms.Label();
            this.txt_puntosDisponibles = new System.Windows.Forms.TextBox();
            this.grp_canjeDePuntos = new System.Windows.Forms.GroupBox();
            this.btn_canjear = new System.Windows.Forms.Button();
            this.cmb_premiosDisponibles = new System.Windows.Forms.ComboBox();
            this.lab_premiosDisponibles = new System.Windows.Forms.Label();
            this.grp_consultaDePuntos = new System.Windows.Forms.GroupBox();
            this.txt_puntosConsultados = new System.Windows.Forms.TextBox();
            this.lab_puntosConsultados = new System.Windows.Forms.Label();
            this.btn_consultar = new System.Windows.Forms.Button();
            this.cmb_trimestre = new System.Windows.Forms.ComboBox();
            this.lab_trimestre = new System.Windows.Forms.Label();
            this.dtp_año = new System.Windows.Forms.DateTimePicker();
            this.lab_año = new System.Windows.Forms.Label();
            this.grp_historialDePremios = new System.Windows.Forms.GroupBox();
            this.dgv_historialDePremios = new System.Windows.Forms.DataGridView();
            this.btn_actualizar = new System.Windows.Forms.Button();
            this.lab_consigna = new System.Windows.Forms.Label();
            this.grp_canjeDePuntos.SuspendLayout();
            this.grp_consultaDePuntos.SuspendLayout();
            this.grp_historialDePremios.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_historialDePremios)).BeginInit();
            this.SuspendLayout();
            // 
            // lab_usuario
            // 
            this.lab_usuario.AutoSize = true;
            this.lab_usuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_usuario.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lab_usuario.Location = new System.Drawing.Point(26, 20);
            this.lab_usuario.Name = "lab_usuario";
            this.lab_usuario.Size = new System.Drawing.Size(92, 18);
            this.lab_usuario.TabIndex = 14;
            this.lab_usuario.Text = "Usuario: ___";
            // 
            // lab_puntosVencidos
            // 
            this.lab_puntosVencidos.AutoSize = true;
            this.lab_puntosVencidos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_puntosVencidos.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.lab_puntosVencidos.Location = new System.Drawing.Point(279, 20);
            this.lab_puntosVencidos.Name = "lab_puntosVencidos";
            this.lab_puntosVencidos.Size = new System.Drawing.Size(124, 18);
            this.lab_puntosVencidos.TabIndex = 16;
            this.lab_puntosVencidos.Text = "Puntos Vencidos:";
            this.lab_puntosVencidos.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_puntosVencidos
            // 
            this.txt_puntosVencidos.Enabled = false;
            this.txt_puntosVencidos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_puntosVencidos.Location = new System.Drawing.Point(405, 17);
            this.txt_puntosVencidos.Name = "txt_puntosVencidos";
            this.txt_puntosVencidos.Size = new System.Drawing.Size(215, 24);
            this.txt_puntosVencidos.TabIndex = 15;
            // 
            // lab_puntosDisponibles
            // 
            this.lab_puntosDisponibles.AutoSize = true;
            this.lab_puntosDisponibles.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_puntosDisponibles.Location = new System.Drawing.Point(263, 50);
            this.lab_puntosDisponibles.Name = "lab_puntosDisponibles";
            this.lab_puntosDisponibles.Size = new System.Drawing.Size(140, 18);
            this.lab_puntosDisponibles.TabIndex = 18;
            this.lab_puntosDisponibles.Text = "Puntos Disponibles:";
            this.lab_puntosDisponibles.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_puntosDisponibles
            // 
            this.txt_puntosDisponibles.Enabled = false;
            this.txt_puntosDisponibles.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_puntosDisponibles.Location = new System.Drawing.Point(405, 47);
            this.txt_puntosDisponibles.Name = "txt_puntosDisponibles";
            this.txt_puntosDisponibles.Size = new System.Drawing.Size(215, 24);
            this.txt_puntosDisponibles.TabIndex = 17;
            // 
            // grp_canjeDePuntos
            // 
            this.grp_canjeDePuntos.Controls.Add(this.btn_canjear);
            this.grp_canjeDePuntos.Controls.Add(this.cmb_premiosDisponibles);
            this.grp_canjeDePuntos.Controls.Add(this.lab_premiosDisponibles);
            this.grp_canjeDePuntos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grp_canjeDePuntos.Location = new System.Drawing.Point(29, 80);
            this.grp_canjeDePuntos.Name = "grp_canjeDePuntos";
            this.grp_canjeDePuntos.Size = new System.Drawing.Size(591, 71);
            this.grp_canjeDePuntos.TabIndex = 19;
            this.grp_canjeDePuntos.TabStop = false;
            this.grp_canjeDePuntos.Text = "Canje de Puntos";
            // 
            // btn_canjear
            // 
            this.btn_canjear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_canjear.Location = new System.Drawing.Point(448, 24);
            this.btn_canjear.Name = "btn_canjear";
            this.btn_canjear.Size = new System.Drawing.Size(126, 32);
            this.btn_canjear.TabIndex = 23;
            this.btn_canjear.Text = "Canjear";
            this.btn_canjear.UseVisualStyleBackColor = true;
            this.btn_canjear.Click += new System.EventHandler(this.btn_canjear_Click);
            // 
            // cmb_premiosDisponibles
            // 
            this.cmb_premiosDisponibles.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_premiosDisponibles.FormattingEnabled = true;
            this.cmb_premiosDisponibles.Location = new System.Drawing.Point(178, 29);
            this.cmb_premiosDisponibles.Name = "cmb_premiosDisponibles";
            this.cmb_premiosDisponibles.Size = new System.Drawing.Size(254, 26);
            this.cmb_premiosDisponibles.TabIndex = 22;
            this.cmb_premiosDisponibles.SelectedIndexChanged += new System.EventHandler(this.cmb_premiosDisponibles_SelectedIndexChanged);
            // 
            // lab_premiosDisponibles
            // 
            this.lab_premiosDisponibles.AutoSize = true;
            this.lab_premiosDisponibles.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_premiosDisponibles.Location = new System.Drawing.Point(27, 32);
            this.lab_premiosDisponibles.Name = "lab_premiosDisponibles";
            this.lab_premiosDisponibles.Size = new System.Drawing.Size(149, 18);
            this.lab_premiosDisponibles.TabIndex = 21;
            this.lab_premiosDisponibles.Text = "Premios Disponibles:";
            this.lab_premiosDisponibles.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // grp_consultaDePuntos
            // 
            this.grp_consultaDePuntos.Controls.Add(this.txt_puntosConsultados);
            this.grp_consultaDePuntos.Controls.Add(this.lab_puntosConsultados);
            this.grp_consultaDePuntos.Controls.Add(this.btn_consultar);
            this.grp_consultaDePuntos.Controls.Add(this.cmb_trimestre);
            this.grp_consultaDePuntos.Controls.Add(this.lab_trimestre);
            this.grp_consultaDePuntos.Controls.Add(this.dtp_año);
            this.grp_consultaDePuntos.Controls.Add(this.lab_año);
            this.grp_consultaDePuntos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grp_consultaDePuntos.Location = new System.Drawing.Point(29, 165);
            this.grp_consultaDePuntos.Name = "grp_consultaDePuntos";
            this.grp_consultaDePuntos.Size = new System.Drawing.Size(591, 76);
            this.grp_consultaDePuntos.TabIndex = 20;
            this.grp_consultaDePuntos.TabStop = false;
            this.grp_consultaDePuntos.Text = "Consulta de Puntos (por trimestre)";
            // 
            // txt_puntosConsultados
            // 
            this.txt_puntosConsultados.Enabled = false;
            this.txt_puntosConsultados.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_puntosConsultados.Location = new System.Drawing.Point(490, 35);
            this.txt_puntosConsultados.Name = "txt_puntosConsultados";
            this.txt_puntosConsultados.Size = new System.Drawing.Size(84, 24);
            this.txt_puntosConsultados.TabIndex = 21;
            // 
            // lab_puntosConsultados
            // 
            this.lab_puntosConsultados.AutoSize = true;
            this.lab_puntosConsultados.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_puntosConsultados.Location = new System.Drawing.Point(429, 38);
            this.lab_puntosConsultados.Name = "lab_puntosConsultados";
            this.lab_puntosConsultados.Size = new System.Drawing.Size(59, 18);
            this.lab_puntosConsultados.TabIndex = 26;
            this.lab_puntosConsultados.Text = "Puntos:";
            this.lab_puntosConsultados.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_consultar
            // 
            this.btn_consultar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_consultar.Location = new System.Drawing.Point(306, 33);
            this.btn_consultar.Name = "btn_consultar";
            this.btn_consultar.Size = new System.Drawing.Size(104, 27);
            this.btn_consultar.TabIndex = 24;
            this.btn_consultar.Text = "Consultar";
            this.btn_consultar.UseVisualStyleBackColor = true;
            this.btn_consultar.Click += new System.EventHandler(this.btn_consultar_Click);
            // 
            // cmb_trimestre
            // 
            this.cmb_trimestre.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_trimestre.FormattingEnabled = true;
            this.cmb_trimestre.Items.AddRange(new object[] {
            "1er",
            "2do",
            "3er",
            "4to"});
            this.cmb_trimestre.Location = new System.Drawing.Point(220, 33);
            this.cmb_trimestre.Name = "cmb_trimestre";
            this.cmb_trimestre.Size = new System.Drawing.Size(65, 26);
            this.cmb_trimestre.TabIndex = 24;
            this.cmb_trimestre.Text = "1er";
            // 
            // lab_trimestre
            // 
            this.lab_trimestre.AutoSize = true;
            this.lab_trimestre.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_trimestre.Location = new System.Drawing.Point(143, 38);
            this.lab_trimestre.Name = "lab_trimestre";
            this.lab_trimestre.Size = new System.Drawing.Size(75, 18);
            this.lab_trimestre.TabIndex = 25;
            this.lab_trimestre.Text = "Trimestre:";
            this.lab_trimestre.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dtp_año
            // 
            this.dtp_año.CustomFormat = "yyyy";
            this.dtp_año.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_año.Location = new System.Drawing.Point(56, 35);
            this.dtp_año.Name = "dtp_año";
            this.dtp_año.Size = new System.Drawing.Size(74, 24);
            this.dtp_año.TabIndex = 24;
            // 
            // lab_año
            // 
            this.lab_año.AutoSize = true;
            this.lab_año.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_año.Location = new System.Drawing.Point(16, 38);
            this.lab_año.Name = "lab_año";
            this.lab_año.Size = new System.Drawing.Size(38, 18);
            this.lab_año.TabIndex = 23;
            this.lab_año.Text = "Año:";
            this.lab_año.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // grp_historialDePremios
            // 
            this.grp_historialDePremios.Controls.Add(this.dgv_historialDePremios);
            this.grp_historialDePremios.Controls.Add(this.btn_actualizar);
            this.grp_historialDePremios.Controls.Add(this.lab_consigna);
            this.grp_historialDePremios.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grp_historialDePremios.Location = new System.Drawing.Point(29, 255);
            this.grp_historialDePremios.Name = "grp_historialDePremios";
            this.grp_historialDePremios.Size = new System.Drawing.Size(591, 293);
            this.grp_historialDePremios.TabIndex = 21;
            this.grp_historialDePremios.TabStop = false;
            this.grp_historialDePremios.Text = "Historial de Premios";
            // 
            // dgv_historialDePremios
            // 
            this.dgv_historialDePremios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_historialDePremios.Location = new System.Drawing.Point(19, 71);
            this.dgv_historialDePremios.Name = "dgv_historialDePremios";
            this.dgv_historialDePremios.Size = new System.Drawing.Size(555, 176);
            this.dgv_historialDePremios.TabIndex = 25;
            // 
            // btn_actualizar
            // 
            this.btn_actualizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_actualizar.Location = new System.Drawing.Point(470, 253);
            this.btn_actualizar.Name = "btn_actualizar";
            this.btn_actualizar.Size = new System.Drawing.Size(104, 27);
            this.btn_actualizar.TabIndex = 24;
            this.btn_actualizar.Text = "Actualizar";
            this.btn_actualizar.UseVisualStyleBackColor = true;
            this.btn_actualizar.Click += new System.EventHandler(this.btn_actualizar_Click);
            // 
            // lab_consigna
            // 
            this.lab_consigna.AutoSize = true;
            this.lab_consigna.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_consigna.Location = new System.Drawing.Point(16, 38);
            this.lab_consigna.Name = "lab_consigna";
            this.lab_consigna.Size = new System.Drawing.Size(400, 18);
            this.lab_consigna.TabIndex = 23;
            this.lab_consigna.Text = "A continuación, todos los premios obtenidos por el usuario:";
            this.lab_consigna.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // frm_canjeYAdministracionDePuntos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(650, 566);
            this.Controls.Add(this.grp_historialDePremios);
            this.Controls.Add(this.grp_consultaDePuntos);
            this.Controls.Add(this.grp_canjeDePuntos);
            this.Controls.Add(this.lab_puntosDisponibles);
            this.Controls.Add(this.lab_usuario);
            this.Controls.Add(this.txt_puntosVencidos);
            this.Controls.Add(this.txt_puntosDisponibles);
            this.Controls.Add(this.lab_puntosVencidos);
            this.MaximizeBox = false;
            this.Name = "frm_canjeYAdministracionDePuntos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Canje y Administración de Puntos";
            this.Load += new System.EventHandler(this.frm_canjeYAdministracionDePuntos_Load);
            this.grp_canjeDePuntos.ResumeLayout(false);
            this.grp_canjeDePuntos.PerformLayout();
            this.grp_consultaDePuntos.ResumeLayout(false);
            this.grp_consultaDePuntos.PerformLayout();
            this.grp_historialDePremios.ResumeLayout(false);
            this.grp_historialDePremios.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_historialDePremios)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lab_usuario;
        private System.Windows.Forms.Label lab_puntosVencidos;
        private System.Windows.Forms.TextBox txt_puntosVencidos;
        private System.Windows.Forms.Label lab_puntosDisponibles;
        private System.Windows.Forms.TextBox txt_puntosDisponibles;
        private System.Windows.Forms.GroupBox grp_canjeDePuntos;
        private System.Windows.Forms.Label lab_premiosDisponibles;
        private System.Windows.Forms.GroupBox grp_consultaDePuntos;
        private System.Windows.Forms.ComboBox cmb_premiosDisponibles;
        private System.Windows.Forms.Button btn_canjear;
        private System.Windows.Forms.DateTimePicker dtp_año;
        private System.Windows.Forms.Label lab_año;
        private System.Windows.Forms.TextBox txt_puntosConsultados;
        private System.Windows.Forms.Label lab_puntosConsultados;
        private System.Windows.Forms.Button btn_consultar;
        private System.Windows.Forms.ComboBox cmb_trimestre;
        private System.Windows.Forms.Label lab_trimestre;
        private System.Windows.Forms.GroupBox grp_historialDePremios;
        private System.Windows.Forms.Button btn_actualizar;
        private System.Windows.Forms.Label lab_consigna;
        private System.Windows.Forms.DataGridView dgv_historialDePremios;
    }
}