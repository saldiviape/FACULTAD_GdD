﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PalcoNet.libreria;

namespace PalcoNet.Canje_Puntos
{
    public partial class frm_canjeYAdministracionDePuntos : Form
    {
        string usuarioActual;
        string premioElegido;
        int anioElegido;
        int trimestreElegido;
        int puntosTotales;
        int puntosVencidos;
        int puntosDisponibles;
        int idPremio;
        int puntosNecesarios;

        DateTime fechaDelSistema = Properties.Settings.Default.FechaDelSistema;
        Int32 anioDelSistema;
        Int32 mesDelSistema;
        int trimestreDelSistema;

        Int32 idC;

        public frm_canjeYAdministracionDePuntos(string u)
        {
            InitializeComponent();
            this.usuarioActual = u;
        }

        comandos cs = new comandos();
        
        private void frm_canjeYAdministracionDePuntos_Load(object sender, EventArgs e)
        {
            lab_usuario.Text = "Usuario: " + usuarioActual;
            cmb_premiosDisponibles.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_trimestre.SelectedItem = 1;
            cmb_trimestre.DropDownStyle = ComboBoxStyle.DropDownList;

            try
            {
                // Se obtiene el idCliente del cliente ingresado y se lo guarda en idC
                obtenerIdCliente();
                
                // Se carga el dataGridView con todos los premios obtenidos
                cargarHistorialDePremios();

                // Se obtienen los puntos totales y los puntos disponibles
                cargarPuntosTotales();
                cargarPuntosDisponibles();

                // Se carga la lista de los premios que el cliente puede obtener con sus premios disponibles
                cargarListaDePremiosCanjeables();

                revisarBloqueoDeAccionCanjear();
            }
            catch (Exception error)
            {
                MessageBox.Show("El usuario " + usuarioActual + " no es cliente.");
            }

        }

        private void btn_canjear_Click(object sender, EventArgs e)
        {
            // Se obtiene el idPremio del premio elegido
            string consulta_idPremioElegido = string.Format("SELECT idPremio, puntosNecesarios FROM DATEROS.premios WHERE descripcion = '" + premioElegido + "'");
            DataSet ds_idPE = Utilidades.ejecutar(consulta_idPremioElegido);
            Int32 BD_idPremio = Convert.ToInt32(ds_idPE.Tables[0].Rows[0]["idPremio"]);
            idPremio = BD_idPremio;
            Int32 BD_puntosNecesarios = Convert.ToInt32(ds_idPE.Tables[0].Rows[0]["puntosNecesarios"]);
            puntosNecesarios = BD_puntosNecesarios;
            
            // En la tabla premios_cliente se insertan: idCliente-idPremio
            string insert_premiosCliente = string.Format("INSERT INTO DATEROS.premios_cliente VALUES ( " + idC + ", " + idPremio + ")");
            DataSet ds_ipC = Utilidades.ejecutar(insert_premiosCliente);

            // En la tabla puntosTrimestralesClientes se actualizan los [puntos] del cliente, en esos año y trimestre indicados
            int puntosActualizados = puntosDisponibles - puntosNecesarios;
            string update_puntosTrimestralesClientes = string.Format("UPDATE DATEROS.puntosTrimestralesClientes SET puntos = " + puntosActualizados + " WHERE idCliente = " + idC + " AND anio = " + anioDelSistema + " AND trimestre = " + trimestreDelSistema + "");
            DataSet ds_upTC = Utilidades.ejecutar(update_puntosTrimestralesClientes);
            
            //Se actualizan varios objetos del formulario...
            cargarPuntosTotales();
            cargarPuntosDisponibles();
            cargarListaDePremiosCanjeables();
            cargarHistorialDePremios();

            revisarBloqueoDeAccionCanjear();
        }

        public void revisarBloqueoDeAccionCanjear()
        {
            int cantPremiosCanjeables = cmb_premiosDisponibles.Items.Count;
            if (cantPremiosCanjeables == 0) {
                btn_canjear.Enabled = false;
                cmb_premiosDisponibles.Enabled = false;
            }
            else
            {
                btn_canjear.Enabled = true;
                cmb_premiosDisponibles.Enabled = true;
            }
        }

        public void obtenerIdCliente() {
            string consulta_idCliente = string.Format("SELECT idCliente FROM DATEROS.clientes WHERE username = '" + usuarioActual + "'");
            DataSet ds_idCliente = Utilidades.ejecutar(consulta_idCliente);
            Int32 BD_idCliente = Convert.ToInt32(ds_idCliente.Tables[0].Rows[0]["idCliente"]);
            idC = BD_idCliente;
        }

        public void cargarPuntosTotales() {
            string consulta_puntosTotales = string.Format("IF NOT EXISTS (SELECT SUM(puntos) FROM DATEROS.puntosTrimestralesClientes WHERE idCliente = " + idC + " GROUP BY idCliente) BEGIN SELECT 0 'puntos' END ELSE BEGIN SELECT SUM(puntos) 'puntos' FROM DATEROS.puntosTrimestralesClientes WHERE idCliente = " + idC + " GROUP BY idCliente END");
            DataSet ds_ptsTotales = Utilidades.ejecutar(consulta_puntosTotales);
            Int32 BD_puntosTotales = Convert.ToInt32(ds_ptsTotales.Tables[0].Rows[0]["puntos"]);
            puntosTotales = BD_puntosTotales;
        }
        
        public void cargarPuntosDisponibles() {
            anioDelSistema = fechaDelSistema.Year;
            mesDelSistema = fechaDelSistema.Month;
            switch (mesDelSistema)
            {
                case 1: case 2: case 3:
                    trimestreDelSistema = 1;
                    break;
                case 4: case 5: case 6:
                    trimestreDelSistema = 2;
                    break;
                case 7: case 8: case 9:
                    trimestreDelSistema = 3;
                    break;
                case 10: case 11: case 12:
                    trimestreDelSistema = 4;
                    break;
            }
            string consulta_puntosDisponibles = string.Format("IF NOT EXISTS (SELECT puntos FROM DATEROS.puntosTrimestralesClientes WHERE idCliente = " + idC + " AND anio = " + anioDelSistema + " AND trimestre = " + trimestreDelSistema + ") BEGIN SELECT 0 'puntos' END ELSE BEGIN SELECT puntos FROM DATEROS.puntosTrimestralesClientes WHERE idCliente = " + idC + " AND anio = " + anioDelSistema + " AND trimestre = " + trimestreDelSistema + " END");
            DataSet ds_ptsDisponibles = Utilidades.ejecutar(consulta_puntosDisponibles);
            Int32 BD_puntosDisponibles = Convert.ToInt32(ds_ptsDisponibles.Tables[0].Rows[0]["puntos"]);
            puntosDisponibles = BD_puntosDisponibles;
            puntosVencidos = puntosTotales - puntosDisponibles;
            txt_puntosVencidos.Text = puntosVencidos.ToString();
            txt_puntosDisponibles.Text = puntosDisponibles.ToString();
        }

        public void cargarHistorialDePremios() {
            cs.llenarDataGridView(dgv_historialDePremios, "SELECT p.descripcion FROM DATEROS.premios_cliente pc JOIN DATEROS.premios p ON (pc.idPremio = p.idPremio) WHERE pc.idCliente = CAST('" + idC + "' AS NUMERIC)");
        }

        public void cargarListaDePremiosCanjeables()
        {
            string consulta_premiosCanjeables = string.Format("SELECT descripcion FROM DATEROS.premios WHERE puntosNecesarios <= " + puntosDisponibles + "");
            DataSet ds_pC = Utilidades.ejecutar(consulta_premiosCanjeables);
            cs.cargarPremiosCanjeables(cmb_premiosDisponibles, puntosDisponibles);
        }

        private void btn_actualizar_Click(object sender, EventArgs e)
        {
            cargarHistorialDePremios();
        }

        private void btn_consultar_Click(object sender, EventArgs e)
        {
            switch (cmb_trimestre.SelectedItem.ToString())
            {
                case "1er":
                    trimestreElegido = 1;
                    break;
                case "2do":
                    trimestreElegido = 2;
                    break;
                case "3er":
                    trimestreElegido = 3;
                    break;
                case "4to":
                    trimestreElegido = 4;
                    break;
            }
            anioElegido = dtp_año.Value.Year;

            // Se obtiene la cantidad de puntos por cada año y trimestre elegido
            string consulta_puntosPorTrimestre = string.Format("IF NOT EXISTS (SELECT puntos FROM DATEROS.puntosTrimestralesClientes WHERE idCliente = " + idC + " AND anio = " + anioElegido + " AND trimestre = " + trimestreElegido + ") BEGIN SELECT 0 'puntos' END ELSE BEGIN (SELECT puntos FROM DATEROS.puntosTrimestralesClientes WHERE idCliente = " + idC + " AND anio = " + anioElegido + " AND trimestre = " + trimestreElegido + ") END");
            DataSet ds_ptsPorTrim = Utilidades.ejecutar(consulta_puntosPorTrimestre);
            Int32 BD_ptsPorTrim = Convert.ToInt32(ds_ptsPorTrim.Tables[0].Rows[0]["puntos"]);
            txt_puntosConsultados.Text = BD_ptsPorTrim.ToString();
        }

        private void cmb_premiosDisponibles_SelectedIndexChanged(object sender, EventArgs e)
        {
            premioElegido = cmb_premiosDisponibles.SelectedValue.ToString();
        }
    }
}
