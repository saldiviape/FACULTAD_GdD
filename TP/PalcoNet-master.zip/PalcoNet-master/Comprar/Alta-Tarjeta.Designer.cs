﻿namespace PalcoNet.Comprar
{
    partial class Alta_Tarjeta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtp_fechaVtoTarjeta = new System.Windows.Forms.DateTimePicker();
            this.txt_cvv = new System.Windows.Forms.TextBox();
            this.lab_cvv = new System.Windows.Forms.Label();
            this.txt_marca = new System.Windows.Forms.TextBox();
            this.lab_marca = new System.Windows.Forms.Label();
            this.txt_banco = new System.Windows.Forms.TextBox();
            this.lab_banco = new System.Windows.Forms.Label();
            this.lab_fechaVto = new System.Windows.Forms.Label();
            this.txt_nomTarjeta = new System.Windows.Forms.TextBox();
            this.lab_nombreTarjeta = new System.Windows.Forms.Label();
            this.txt_nroTarjeta = new System.Windows.Forms.TextBox();
            this.lab_nroTarjeta = new System.Windows.Forms.Label();
            this.btn_Limpiar = new System.Windows.Forms.Button();
            this.btn_Guardar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // dtp_fechaVtoTarjeta
            // 
            this.dtp_fechaVtoTarjeta.CustomFormat = "yyyy/MM/dd HH:mm:ss";
            this.dtp_fechaVtoTarjeta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_fechaVtoTarjeta.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_fechaVtoTarjeta.Location = new System.Drawing.Point(218, 87);
            this.dtp_fechaVtoTarjeta.Margin = new System.Windows.Forms.Padding(4);
            this.dtp_fechaVtoTarjeta.Name = "dtp_fechaVtoTarjeta";
            this.dtp_fechaVtoTarjeta.Size = new System.Drawing.Size(264, 26);
            this.dtp_fechaVtoTarjeta.TabIndex = 328;
            // 
            // txt_cvv
            // 
            this.txt_cvv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_cvv.Location = new System.Drawing.Point(218, 192);
            this.txt_cvv.Margin = new System.Windows.Forms.Padding(4);
            this.txt_cvv.Name = "txt_cvv";
            this.txt_cvv.Size = new System.Drawing.Size(264, 26);
            this.txt_cvv.TabIndex = 331;
            // 
            // lab_cvv
            // 
            this.lab_cvv.AutoSize = true;
            this.lab_cvv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_cvv.Location = new System.Drawing.Point(155, 195);
            this.lab_cvv.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_cvv.Name = "lab_cvv";
            this.lab_cvv.Size = new System.Drawing.Size(43, 20);
            this.lab_cvv.TabIndex = 325;
            this.lab_cvv.Text = "CVV";
            this.lab_cvv.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_marca
            // 
            this.txt_marca.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_marca.Location = new System.Drawing.Point(218, 158);
            this.txt_marca.Margin = new System.Windows.Forms.Padding(4);
            this.txt_marca.Name = "txt_marca";
            this.txt_marca.Size = new System.Drawing.Size(264, 26);
            this.txt_marca.TabIndex = 330;
            // 
            // lab_marca
            // 
            this.lab_marca.AutoSize = true;
            this.lab_marca.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_marca.Location = new System.Drawing.Point(142, 161);
            this.lab_marca.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_marca.Name = "lab_marca";
            this.lab_marca.Size = new System.Drawing.Size(56, 20);
            this.lab_marca.TabIndex = 324;
            this.lab_marca.Text = "Marca";
            this.lab_marca.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_banco
            // 
            this.txt_banco.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_banco.Location = new System.Drawing.Point(218, 124);
            this.txt_banco.Margin = new System.Windows.Forms.Padding(4);
            this.txt_banco.Name = "txt_banco";
            this.txt_banco.Size = new System.Drawing.Size(264, 26);
            this.txt_banco.TabIndex = 329;
            // 
            // lab_banco
            // 
            this.lab_banco.AutoSize = true;
            this.lab_banco.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_banco.Location = new System.Drawing.Point(141, 127);
            this.lab_banco.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_banco.Name = "lab_banco";
            this.lab_banco.Size = new System.Drawing.Size(57, 20);
            this.lab_banco.TabIndex = 323;
            this.lab_banco.Text = "Banco";
            this.lab_banco.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lab_fechaVto
            // 
            this.lab_fechaVto.AutoSize = true;
            this.lab_fechaVto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_fechaVto.Location = new System.Drawing.Point(23, 93);
            this.lab_fechaVto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_fechaVto.Name = "lab_fechaVto";
            this.lab_fechaVto.Size = new System.Drawing.Size(175, 20);
            this.lab_fechaVto.TabIndex = 322;
            this.lab_fechaVto.Text = "Fecha de Vencimiento";
            this.lab_fechaVto.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_nomTarjeta
            // 
            this.txt_nomTarjeta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nomTarjeta.Location = new System.Drawing.Point(218, 56);
            this.txt_nomTarjeta.Margin = new System.Windows.Forms.Padding(4);
            this.txt_nomTarjeta.Name = "txt_nomTarjeta";
            this.txt_nomTarjeta.Size = new System.Drawing.Size(264, 26);
            this.txt_nomTarjeta.TabIndex = 327;
            // 
            // lab_nombreTarjeta
            // 
            this.lab_nombreTarjeta.AutoSize = true;
            this.lab_nombreTarjeta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_nombreTarjeta.Location = new System.Drawing.Point(73, 59);
            this.lab_nombreTarjeta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_nombreTarjeta.Name = "lab_nombreTarjeta";
            this.lab_nombreTarjeta.Size = new System.Drawing.Size(125, 20);
            this.lab_nombreTarjeta.TabIndex = 321;
            this.lab_nombreTarjeta.Text = "Nombre Tarjeta";
            this.lab_nombreTarjeta.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_nroTarjeta
            // 
            this.txt_nroTarjeta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nroTarjeta.Location = new System.Drawing.Point(218, 22);
            this.txt_nroTarjeta.Margin = new System.Windows.Forms.Padding(4);
            this.txt_nroTarjeta.Name = "txt_nroTarjeta";
            this.txt_nroTarjeta.Size = new System.Drawing.Size(264, 26);
            this.txt_nroTarjeta.TabIndex = 326;
            // 
            // lab_nroTarjeta
            // 
            this.lab_nroTarjeta.AutoSize = true;
            this.lab_nroTarjeta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_nroTarjeta.Location = new System.Drawing.Point(101, 25);
            this.lab_nroTarjeta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_nroTarjeta.Name = "lab_nroTarjeta";
            this.lab_nroTarjeta.Size = new System.Drawing.Size(97, 20);
            this.lab_nroTarjeta.TabIndex = 320;
            this.lab_nroTarjeta.Text = "Nro. Tarjeta";
            this.lab_nroTarjeta.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_Limpiar
            // 
            this.btn_Limpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Limpiar.Location = new System.Drawing.Point(15, 238);
            this.btn_Limpiar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Limpiar.Name = "btn_Limpiar";
            this.btn_Limpiar.Size = new System.Drawing.Size(235, 50);
            this.btn_Limpiar.TabIndex = 332;
            this.btn_Limpiar.Text = "Limpiar";
            this.btn_Limpiar.UseVisualStyleBackColor = true;
            this.btn_Limpiar.Click += new System.EventHandler(this.btn_Limpiar_Click);
            // 
            // btn_Guardar
            // 
            this.btn_Guardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Guardar.Location = new System.Drawing.Point(274, 238);
            this.btn_Guardar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Guardar.Name = "btn_Guardar";
            this.btn_Guardar.Size = new System.Drawing.Size(235, 50);
            this.btn_Guardar.TabIndex = 333;
            this.btn_Guardar.Text = "Guardar";
            this.btn_Guardar.UseVisualStyleBackColor = true;
            this.btn_Guardar.Click += new System.EventHandler(this.btn_Guardar_Click);
            // 
            // Alta_Tarjeta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(526, 317);
            this.Controls.Add(this.btn_Limpiar);
            this.Controls.Add(this.btn_Guardar);
            this.Controls.Add(this.dtp_fechaVtoTarjeta);
            this.Controls.Add(this.txt_cvv);
            this.Controls.Add(this.lab_cvv);
            this.Controls.Add(this.txt_marca);
            this.Controls.Add(this.lab_marca);
            this.Controls.Add(this.txt_banco);
            this.Controls.Add(this.lab_banco);
            this.Controls.Add(this.lab_fechaVto);
            this.Controls.Add(this.txt_nomTarjeta);
            this.Controls.Add(this.lab_nombreTarjeta);
            this.Controls.Add(this.txt_nroTarjeta);
            this.Controls.Add(this.lab_nroTarjeta);
            this.Name = "Alta_Tarjeta";
            this.Text = "Alta Tarjeta";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtp_fechaVtoTarjeta;
        private System.Windows.Forms.TextBox txt_cvv;
        private System.Windows.Forms.Label lab_cvv;
        private System.Windows.Forms.TextBox txt_marca;
        private System.Windows.Forms.Label lab_marca;
        private System.Windows.Forms.TextBox txt_banco;
        private System.Windows.Forms.Label lab_banco;
        private System.Windows.Forms.Label lab_fechaVto;
        private System.Windows.Forms.TextBox txt_nomTarjeta;
        private System.Windows.Forms.Label lab_nombreTarjeta;
        private System.Windows.Forms.TextBox txt_nroTarjeta;
        private System.Windows.Forms.Label lab_nroTarjeta;
        private System.Windows.Forms.Button btn_Limpiar;
        private System.Windows.Forms.Button btn_Guardar;
    }
}