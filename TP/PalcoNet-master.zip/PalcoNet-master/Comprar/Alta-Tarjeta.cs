﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Comprar
{
    public partial class Alta_Tarjeta : Form
    {
        string usuario;

        public Alta_Tarjeta(string usu)
        {
            this.usuario = usu;
            InitializeComponent();
        }

        private void btn_Limpiar_Click(object sender, EventArgs e)
        {
            Limpiar limpiar = new Limpiar();
            limpiar.limpiarCampos(this);
        }

        private bool altaTarjeta()
        {
            if (Convert.ToDateTime(dtp_fechaVtoTarjeta.Value) > Properties.Settings.Default.FechaDelSistema)
                try
                {
                    string cmd = string.Format("EXEC DATEROS.altaTarjeta '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}'", usuario, txt_nroTarjeta.Text.Trim(), txt_nomTarjeta.Text.Trim(), Convert.ToDateTime(dtp_fechaVtoTarjeta.Value.ToString()), txt_banco.Text.Trim(), txt_marca.Text.Trim(), txt_cvv.Text.Trim());
                    libreria.Utilidades.ejecutar(cmd);
                    MessageBox.Show("Se ha asociado la tarjeta");
                    this.Hide();
                    return true;
                }
                catch (Exception error)
                {
                    MessageBox.Show("Ha ocurrido un error: " + error.Message);
                    return false;
                }
            else
                MessageBox.Show("La fecha de vencimiento de la tarjeta debe ser mayor a la fecha actual");
            return false;
        }

        private void btn_Guardar_Click(object sender, EventArgs e)
        {
            this.altaTarjeta(); 
        }
    }
}
