﻿namespace PalcoNet.Comprar
{
    partial class frm_comprar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grp_seleccionDePublicacion = new System.Windows.Forms.GroupBox();
            this.lbl_paginasTotales = new System.Windows.Forms.Label();
            this.lbl_separador = new System.Windows.Forms.Label();
            this.lbl_paginaActual = new System.Windows.Forms.Label();
            this.lab_requisitoFiltroRubro = new System.Windows.Forms.Label();
            this.chk_filtroPorFecha = new System.Windows.Forms.CheckBox();
            this.chk_filtroPorDescripcion = new System.Windows.Forms.CheckBox();
            this.chk_filtroPorRubro = new System.Windows.Forms.CheckBox();
            this.btn_ultima = new System.Windows.Forms.Button();
            this.btn_siguiente = new System.Windows.Forms.Button();
            this.btn_anterior = new System.Windows.Forms.Button();
            this.btn_primera = new System.Windows.Forms.Button();
            this.btn_filtrar = new System.Windows.Forms.Button();
            this.dgv_publicaciones = new System.Windows.Forms.DataGridView();
            this.lab_fechaHasta = new System.Windows.Forms.Label();
            this.lab_fechaDesde = new System.Windows.Forms.Label();
            this.chk_textoExacto = new System.Windows.Forms.CheckBox();
            this.txt_descripcion = new System.Windows.Forms.TextBox();
            this.dtp_fechaHasta = new System.Windows.Forms.DateTimePicker();
            this.dtp_fechaDesde = new System.Windows.Forms.DateTimePicker();
            this.chk_deportes = new System.Windows.Forms.CheckBox();
            this.chk_danza = new System.Windows.Forms.CheckBox();
            this.chk_cineTV = new System.Windows.Forms.CheckBox();
            this.chk_musicalConcierto = new System.Windows.Forms.CheckBox();
            this.chk_teatro = new System.Windows.Forms.CheckBox();
            this.chk_sinRubro = new System.Windows.Forms.CheckBox();
            this.btn_seleccionUbicaciones = new System.Windows.Forms.Button();
            this.grp_seleccionDePublicacion.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_publicaciones)).BeginInit();
            this.SuspendLayout();
            // 
            // grp_seleccionDePublicacion
            // 
            this.grp_seleccionDePublicacion.Controls.Add(this.lbl_paginasTotales);
            this.grp_seleccionDePublicacion.Controls.Add(this.lbl_separador);
            this.grp_seleccionDePublicacion.Controls.Add(this.lbl_paginaActual);
            this.grp_seleccionDePublicacion.Controls.Add(this.lab_requisitoFiltroRubro);
            this.grp_seleccionDePublicacion.Controls.Add(this.chk_filtroPorFecha);
            this.grp_seleccionDePublicacion.Controls.Add(this.chk_filtroPorDescripcion);
            this.grp_seleccionDePublicacion.Controls.Add(this.chk_filtroPorRubro);
            this.grp_seleccionDePublicacion.Controls.Add(this.btn_ultima);
            this.grp_seleccionDePublicacion.Controls.Add(this.btn_siguiente);
            this.grp_seleccionDePublicacion.Controls.Add(this.btn_anterior);
            this.grp_seleccionDePublicacion.Controls.Add(this.btn_primera);
            this.grp_seleccionDePublicacion.Controls.Add(this.btn_filtrar);
            this.grp_seleccionDePublicacion.Controls.Add(this.dgv_publicaciones);
            this.grp_seleccionDePublicacion.Controls.Add(this.lab_fechaHasta);
            this.grp_seleccionDePublicacion.Controls.Add(this.lab_fechaDesde);
            this.grp_seleccionDePublicacion.Controls.Add(this.chk_textoExacto);
            this.grp_seleccionDePublicacion.Controls.Add(this.txt_descripcion);
            this.grp_seleccionDePublicacion.Controls.Add(this.dtp_fechaHasta);
            this.grp_seleccionDePublicacion.Controls.Add(this.dtp_fechaDesde);
            this.grp_seleccionDePublicacion.Controls.Add(this.chk_deportes);
            this.grp_seleccionDePublicacion.Controls.Add(this.chk_danza);
            this.grp_seleccionDePublicacion.Controls.Add(this.chk_cineTV);
            this.grp_seleccionDePublicacion.Controls.Add(this.chk_musicalConcierto);
            this.grp_seleccionDePublicacion.Controls.Add(this.chk_teatro);
            this.grp_seleccionDePublicacion.Controls.Add(this.chk_sinRubro);
            this.grp_seleccionDePublicacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grp_seleccionDePublicacion.Location = new System.Drawing.Point(24, 22);
            this.grp_seleccionDePublicacion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grp_seleccionDePublicacion.Name = "grp_seleccionDePublicacion";
            this.grp_seleccionDePublicacion.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grp_seleccionDePublicacion.Size = new System.Drawing.Size(1404, 465);
            this.grp_seleccionDePublicacion.TabIndex = 0;
            this.grp_seleccionDePublicacion.TabStop = false;
            this.grp_seleccionDePublicacion.Text = "Selección de Publicación";
            // 
            // lbl_paginasTotales
            // 
            this.lbl_paginasTotales.AutoSize = true;
            this.lbl_paginasTotales.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_paginasTotales.Location = new System.Drawing.Point(945, 421);
            this.lbl_paginasTotales.Name = "lbl_paginasTotales";
            this.lbl_paginasTotales.Size = new System.Drawing.Size(16, 18);
            this.lbl_paginasTotales.TabIndex = 22;
            this.lbl_paginasTotales.Text = "1";
            // 
            // lbl_separador
            // 
            this.lbl_separador.AutoSize = true;
            this.lbl_separador.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_separador.Location = new System.Drawing.Point(935, 421);
            this.lbl_separador.Name = "lbl_separador";
            this.lbl_separador.Size = new System.Drawing.Size(12, 18);
            this.lbl_separador.TabIndex = 21;
            this.lbl_separador.Text = "/";
            // 
            // lbl_paginaActual
            // 
            this.lbl_paginaActual.AutoSize = true;
            this.lbl_paginaActual.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_paginaActual.Location = new System.Drawing.Point(891, 421);
            this.lbl_paginaActual.Name = "lbl_paginaActual";
            this.lbl_paginaActual.Size = new System.Drawing.Size(16, 18);
            this.lbl_paginaActual.TabIndex = 20;
            this.lbl_paginaActual.Text = "1";
            // 
            // lab_requisitoFiltroRubro
            // 
            this.lab_requisitoFiltroRubro.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_requisitoFiltroRubro.Location = new System.Drawing.Point(69, 174);
            this.lab_requisitoFiltroRubro.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_requisitoFiltroRubro.Name = "lab_requisitoFiltroRubro";
            this.lab_requisitoFiltroRubro.Size = new System.Drawing.Size(121, 57);
            this.lab_requisitoFiltroRubro.TabIndex = 19;
            this.lab_requisitoFiltroRubro.Text = "Debe estar seleccionado al menos un rubro";
            this.lab_requisitoFiltroRubro.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // chk_filtroPorFecha
            // 
            this.chk_filtroPorFecha.AutoSize = true;
            this.chk_filtroPorFecha.Location = new System.Drawing.Point(32, 330);
            this.chk_filtroPorFecha.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chk_filtroPorFecha.Name = "chk_filtroPorFecha";
            this.chk_filtroPorFecha.Size = new System.Drawing.Size(170, 28);
            this.chk_filtroPorFecha.TabIndex = 11;
            this.chk_filtroPorFecha.Text = "Filtro por Fecha:";
            this.chk_filtroPorFecha.UseVisualStyleBackColor = true;
            this.chk_filtroPorFecha.CheckedChanged += new System.EventHandler(this.chk_filtroPorFecha_CheckedChanged);
            // 
            // chk_filtroPorDescripcion
            // 
            this.chk_filtroPorDescripcion.AutoSize = true;
            this.chk_filtroPorDescripcion.Location = new System.Drawing.Point(32, 246);
            this.chk_filtroPorDescripcion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chk_filtroPorDescripcion.Name = "chk_filtroPorDescripcion";
            this.chk_filtroPorDescripcion.Size = new System.Drawing.Size(216, 28);
            this.chk_filtroPorDescripcion.TabIndex = 8;
            this.chk_filtroPorDescripcion.Text = "Filtro por Descripción:";
            this.chk_filtroPorDescripcion.UseVisualStyleBackColor = true;
            this.chk_filtroPorDescripcion.CheckedChanged += new System.EventHandler(this.chk_filtroPorDescripcion_CheckedChanged);
            // 
            // chk_filtroPorRubro
            // 
            this.chk_filtroPorRubro.AutoSize = true;
            this.chk_filtroPorRubro.Location = new System.Drawing.Point(32, 43);
            this.chk_filtroPorRubro.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chk_filtroPorRubro.Name = "chk_filtroPorRubro";
            this.chk_filtroPorRubro.Size = new System.Drawing.Size(168, 28);
            this.chk_filtroPorRubro.TabIndex = 1;
            this.chk_filtroPorRubro.Text = "Filtro por Rubro:";
            this.chk_filtroPorRubro.UseVisualStyleBackColor = true;
            this.chk_filtroPorRubro.CheckedChanged += new System.EventHandler(this.chk_filtroPorRubro_CheckedChanged);
            // 
            // btn_ultima
            // 
            this.btn_ultima.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ultima.Location = new System.Drawing.Point(1251, 412);
            this.btn_ultima.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_ultima.Name = "btn_ultima";
            this.btn_ultima.Size = new System.Drawing.Size(133, 37);
            this.btn_ultima.TabIndex = 18;
            this.btn_ultima.Text = "Última";
            this.btn_ultima.UseVisualStyleBackColor = true;
            this.btn_ultima.Click += new System.EventHandler(this.btn_ultima_Click);
            // 
            // btn_siguiente
            // 
            this.btn_siguiente.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_siguiente.Location = new System.Drawing.Point(1092, 412);
            this.btn_siguiente.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_siguiente.Name = "btn_siguiente";
            this.btn_siguiente.Size = new System.Drawing.Size(133, 37);
            this.btn_siguiente.TabIndex = 17;
            this.btn_siguiente.Text = "Siguiente";
            this.btn_siguiente.UseVisualStyleBackColor = true;
            this.btn_siguiente.Click += new System.EventHandler(this.btn_siguiente_Click);
            // 
            // btn_anterior
            // 
            this.btn_anterior.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_anterior.Location = new System.Drawing.Point(655, 412);
            this.btn_anterior.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_anterior.Name = "btn_anterior";
            this.btn_anterior.Size = new System.Drawing.Size(133, 37);
            this.btn_anterior.TabIndex = 16;
            this.btn_anterior.Text = "Anterior";
            this.btn_anterior.UseVisualStyleBackColor = true;
            this.btn_anterior.Click += new System.EventHandler(this.btn_anterior_Click);
            // 
            // btn_primera
            // 
            this.btn_primera.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_primera.Location = new System.Drawing.Point(492, 412);
            this.btn_primera.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_primera.Name = "btn_primera";
            this.btn_primera.Size = new System.Drawing.Size(133, 37);
            this.btn_primera.TabIndex = 15;
            this.btn_primera.Text = "Primera";
            this.btn_primera.UseVisualStyleBackColor = true;
            this.btn_primera.Click += new System.EventHandler(this.btn_primera_Click);
            // 
            // btn_filtrar
            // 
            this.btn_filtrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_filtrar.Location = new System.Drawing.Point(183, 412);
            this.btn_filtrar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_filtrar.Name = "btn_filtrar";
            this.btn_filtrar.Size = new System.Drawing.Size(168, 37);
            this.btn_filtrar.TabIndex = 14;
            this.btn_filtrar.Text = "Filtrar";
            this.btn_filtrar.UseVisualStyleBackColor = true;
            this.btn_filtrar.Click += new System.EventHandler(this.btn_filtrar_Click);
            // 
            // dgv_publicaciones
            // 
            this.dgv_publicaciones.AllowUserToAddRows = false;
            this.dgv_publicaciones.AllowUserToDeleteRows = false;
            this.dgv_publicaciones.AllowUserToOrderColumns = true;
            this.dgv_publicaciones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_publicaciones.Location = new System.Drawing.Point(493, 28);
            this.dgv_publicaciones.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgv_publicaciones.Name = "dgv_publicaciones";
            this.dgv_publicaciones.ReadOnly = true;
            this.dgv_publicaciones.Size = new System.Drawing.Size(891, 377);
            this.dgv_publicaciones.TabIndex = 15;
            this.dgv_publicaciones.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_publicaciones_CellContentClick);
            // 
            // lab_fechaHasta
            // 
            this.lab_fechaHasta.AutoSize = true;
            this.lab_fechaHasta.Enabled = false;
            this.lab_fechaHasta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_fechaHasta.Location = new System.Drawing.Point(269, 368);
            this.lab_fechaHasta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_fechaHasta.Name = "lab_fechaHasta";
            this.lab_fechaHasta.Size = new System.Drawing.Size(54, 20);
            this.lab_fechaHasta.TabIndex = 14;
            this.lab_fechaHasta.Text = "Hasta";
            // 
            // lab_fechaDesde
            // 
            this.lab_fechaDesde.AutoSize = true;
            this.lab_fechaDesde.Enabled = false;
            this.lab_fechaDesde.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_fechaDesde.Location = new System.Drawing.Point(40, 368);
            this.lab_fechaDesde.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_fechaDesde.Name = "lab_fechaDesde";
            this.lab_fechaDesde.Size = new System.Drawing.Size(58, 20);
            this.lab_fechaDesde.TabIndex = 13;
            this.lab_fechaDesde.Text = "Desde";
            // 
            // chk_textoExacto
            // 
            this.chk_textoExacto.AutoSize = true;
            this.chk_textoExacto.Enabled = false;
            this.chk_textoExacto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_textoExacto.Location = new System.Drawing.Point(327, 313);
            this.chk_textoExacto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chk_textoExacto.Name = "chk_textoExacto";
            this.chk_textoExacto.Size = new System.Drawing.Size(126, 24);
            this.chk_textoExacto.TabIndex = 10;
            this.chk_textoExacto.Text = "Texto exacto";
            this.chk_textoExacto.UseVisualStyleBackColor = true;
            // 
            // txt_descripcion
            // 
            this.txt_descripcion.Enabled = false;
            this.txt_descripcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_descripcion.Location = new System.Drawing.Point(37, 281);
            this.txt_descripcion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_descripcion.Name = "txt_descripcion";
            this.txt_descripcion.Size = new System.Drawing.Size(431, 29);
            this.txt_descripcion.TabIndex = 9;
            // 
            // dtp_fechaHasta
            // 
            this.dtp_fechaHasta.CustomFormat = "";
            this.dtp_fechaHasta.Enabled = false;
            this.dtp_fechaHasta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_fechaHasta.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_fechaHasta.Location = new System.Drawing.Point(331, 364);
            this.dtp_fechaHasta.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtp_fechaHasta.Name = "dtp_fechaHasta";
            this.dtp_fechaHasta.Size = new System.Drawing.Size(137, 26);
            this.dtp_fechaHasta.TabIndex = 13;
            this.dtp_fechaHasta.ValueChanged += new System.EventHandler(this.dtp_fechaHasta_ValueChanged);
            // 
            // dtp_fechaDesde
            // 
            this.dtp_fechaDesde.CustomFormat = "";
            this.dtp_fechaDesde.Enabled = false;
            this.dtp_fechaDesde.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_fechaDesde.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_fechaDesde.Location = new System.Drawing.Point(108, 364);
            this.dtp_fechaDesde.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtp_fechaDesde.Name = "dtp_fechaDesde";
            this.dtp_fechaDesde.Size = new System.Drawing.Size(137, 26);
            this.dtp_fechaDesde.TabIndex = 12;
            this.dtp_fechaDesde.ValueChanged += new System.EventHandler(this.dtp_fechaDesde_ValueChanged);
            // 
            // chk_deportes
            // 
            this.chk_deportes.AutoSize = true;
            this.chk_deportes.Enabled = false;
            this.chk_deportes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_deportes.Location = new System.Drawing.Point(220, 206);
            this.chk_deportes.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chk_deportes.Name = "chk_deportes";
            this.chk_deportes.Size = new System.Drawing.Size(100, 24);
            this.chk_deportes.TabIndex = 7;
            this.chk_deportes.Text = "Deportes";
            this.chk_deportes.UseVisualStyleBackColor = true;
            // 
            // chk_danza
            // 
            this.chk_danza.AutoSize = true;
            this.chk_danza.Enabled = false;
            this.chk_danza.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_danza.Location = new System.Drawing.Point(220, 174);
            this.chk_danza.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chk_danza.Name = "chk_danza";
            this.chk_danza.Size = new System.Drawing.Size(80, 24);
            this.chk_danza.TabIndex = 6;
            this.chk_danza.Text = "Danza";
            this.chk_danza.UseVisualStyleBackColor = true;
            // 
            // chk_cineTV
            // 
            this.chk_cineTV.AutoSize = true;
            this.chk_cineTV.Enabled = false;
            this.chk_cineTV.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_cineTV.Location = new System.Drawing.Point(220, 142);
            this.chk_cineTV.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chk_cineTV.Name = "chk_cineTV";
            this.chk_cineTV.Size = new System.Drawing.Size(102, 24);
            this.chk_cineTV.TabIndex = 5;
            this.chk_cineTV.Text = "Cine - TV";
            this.chk_cineTV.UseVisualStyleBackColor = true;
            // 
            // chk_musicalConcierto
            // 
            this.chk_musicalConcierto.AutoSize = true;
            this.chk_musicalConcierto.Enabled = false;
            this.chk_musicalConcierto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_musicalConcierto.Location = new System.Drawing.Point(220, 110);
            this.chk_musicalConcierto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chk_musicalConcierto.Name = "chk_musicalConcierto";
            this.chk_musicalConcierto.Size = new System.Drawing.Size(177, 24);
            this.chk_musicalConcierto.TabIndex = 4;
            this.chk_musicalConcierto.Text = "Musical - Concierto";
            this.chk_musicalConcierto.UseVisualStyleBackColor = true;
            // 
            // chk_teatro
            // 
            this.chk_teatro.AutoSize = true;
            this.chk_teatro.Enabled = false;
            this.chk_teatro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_teatro.Location = new System.Drawing.Point(220, 78);
            this.chk_teatro.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chk_teatro.Name = "chk_teatro";
            this.chk_teatro.Size = new System.Drawing.Size(79, 24);
            this.chk_teatro.TabIndex = 3;
            this.chk_teatro.Text = "Teatro";
            this.chk_teatro.UseVisualStyleBackColor = true;
            // 
            // chk_sinRubro
            // 
            this.chk_sinRubro.AutoSize = true;
            this.chk_sinRubro.Enabled = false;
            this.chk_sinRubro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_sinRubro.Location = new System.Drawing.Point(220, 46);
            this.chk_sinRubro.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chk_sinRubro.Name = "chk_sinRubro";
            this.chk_sinRubro.Size = new System.Drawing.Size(109, 24);
            this.chk_sinRubro.TabIndex = 2;
            this.chk_sinRubro.Text = "(sin rubro)";
            this.chk_sinRubro.UseVisualStyleBackColor = true;
            // 
            // btn_seleccionUbicaciones
            // 
            this.btn_seleccionUbicaciones.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_seleccionUbicaciones.Location = new System.Drawing.Point(589, 532);
            this.btn_seleccionUbicaciones.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_seleccionUbicaciones.Name = "btn_seleccionUbicaciones";
            this.btn_seleccionUbicaciones.Size = new System.Drawing.Size(277, 43);
            this.btn_seleccionUbicaciones.TabIndex = 26;
            this.btn_seleccionUbicaciones.Text = "Seleccionar Ubicaciones";
            this.btn_seleccionUbicaciones.UseVisualStyleBackColor = true;
            this.btn_seleccionUbicaciones.Click += new System.EventHandler(this.btn_seleccionUbicaciones_Click);
            // 
            // frm_comprar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1456, 597);
            this.Controls.Add(this.grp_seleccionDePublicacion);
            this.Controls.Add(this.btn_seleccionUbicaciones);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "frm_comprar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Comprar";
            this.Load += new System.EventHandler(this.frm_comprar_Load);
            this.grp_seleccionDePublicacion.ResumeLayout(false);
            this.grp_seleccionDePublicacion.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_publicaciones)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grp_seleccionDePublicacion;
        private System.Windows.Forms.CheckBox chk_deportes;
        private System.Windows.Forms.CheckBox chk_danza;
        private System.Windows.Forms.CheckBox chk_cineTV;
        private System.Windows.Forms.CheckBox chk_musicalConcierto;
        private System.Windows.Forms.CheckBox chk_teatro;
        private System.Windows.Forms.CheckBox chk_sinRubro;
        private System.Windows.Forms.Label lab_fechaHasta;
        private System.Windows.Forms.Label lab_fechaDesde;
        private System.Windows.Forms.CheckBox chk_textoExacto;
        private System.Windows.Forms.TextBox txt_descripcion;
        private System.Windows.Forms.DateTimePicker dtp_fechaHasta;
        private System.Windows.Forms.DateTimePicker dtp_fechaDesde;
        private System.Windows.Forms.DataGridView dgv_publicaciones;
        private System.Windows.Forms.Button btn_filtrar;
        private System.Windows.Forms.Button btn_ultima;
        private System.Windows.Forms.Button btn_siguiente;
        private System.Windows.Forms.Button btn_anterior;
        private System.Windows.Forms.Button btn_primera;
        private System.Windows.Forms.Button btn_seleccionUbicaciones;
        private System.Windows.Forms.CheckBox chk_filtroPorFecha;
        private System.Windows.Forms.CheckBox chk_filtroPorDescripcion;
        private System.Windows.Forms.CheckBox chk_filtroPorRubro;
        private System.Windows.Forms.Label lab_requisitoFiltroRubro;
        private System.Windows.Forms.Label lbl_paginasTotales;
        private System.Windows.Forms.Label lbl_separador;
        private System.Windows.Forms.Label lbl_paginaActual;
    }
}