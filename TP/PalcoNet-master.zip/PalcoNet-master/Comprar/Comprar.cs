﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PalcoNet.libreria;

namespace PalcoNet.Comprar
{
    public partial class frm_comprar : Form
    {
        comandos c = new comandos();
        int total_filas = 0;
        int total_paginas = 0;
        int max_filas_por_pagina = 20;
        int nro_pagina = 0;
        DataTable resultado_query;
        string usuario;
        string rol;

        public frm_comprar(string usu, string r)
        {
            this.usuario = usu;
            this.rol = r;
            InitializeComponent();
        }

        private void btn_filtrar_Click(object sender, EventArgs e)
        {
            string where = "";
            int cantFiltros = 0;
            string filtro = "";
            string whereRubro = "";
            string whereDescripcion = "";
            string whereFecha = "";

            if (chk_filtroPorRubro.Checked)
            {
                cantFiltros++;
                filtro += "R";
                string rubro = "";
                int cantFiltrosEnRubro = 0;
                if (chk_sinRubro.Checked) { cantFiltrosEnRubro++; rubro += "1"; }
                if (chk_teatro.Checked) { cantFiltrosEnRubro++; rubro += "2"; }
                if (chk_musicalConcierto.Checked) { cantFiltrosEnRubro++; rubro += "3"; }
                if (chk_cineTV.Checked) { cantFiltrosEnRubro++; rubro += "4"; }
                if (chk_danza.Checked) { cantFiltrosEnRubro++; rubro += "5"; }
                if (chk_deportes.Checked) { cantFiltrosEnRubro++; rubro += "6"; }
                switch (cantFiltrosEnRubro)
                {
                    case 1:
                        whereRubro = "r.idRubro = " + rubro[0];
                        break;
                    case 2:
                        whereRubro = "r.idRubro IN (" + rubro[0] + ", " + rubro[1] + ")";
                        break;
                    case 3:
                        whereRubro = "r.idRubro IN (" + rubro[0] + ", " + rubro[1] + ", " + rubro[2] + ")";
                        break;
                    case 4:
                        whereRubro = "r.idRubro IN (" + rubro[0] + ", " + rubro[1] + ", " + rubro[2] + ", " + rubro[3] + ")";
                        break;
                    case 5:
                        whereRubro = "r.idRubro IN (" + rubro[0] + ", " + rubro[1] + ", " + rubro[2] + ", " + rubro[3] + ", " + rubro[4] + ")";
                        break;
                    case 6:
                        whereRubro = "r.idRubro IN (" + rubro[0] + ", " + rubro[1] + ", " + rubro[2] + ", " + rubro[3] + ", " + rubro[4] + ", " + rubro[5] + ")";
                        break;
                }
            }

            if (chk_filtroPorDescripcion.Checked)
            {
                cantFiltros++;
                filtro += "D";
                if (chk_textoExacto.Checked)
                {
                    whereDescripcion = "p.descripcion = '" + txt_descripcion.Text + "'";
                }
                else
                {
                    whereDescripcion = "p.descripcion LIKE '%" + txt_descripcion.Text + "%'";
                }
            }

            if (chk_filtroPorFecha.Checked)
            {
                cantFiltros++;
                filtro += "F";

                string fechaDesde = "'" + dtp_fechaDesde.Value.Year + "-" + dtp_fechaDesde.Value.Month + "-" + dtp_fechaDesde.Value.Day + "'";
                string fechaHasta = "'" + dtp_fechaHasta.Value.Year + "-" + dtp_fechaHasta.Value.Month + "-" + dtp_fechaHasta.Value.Day + "'";
                whereFecha = "fechaCreacion BETWEEN CONVERT(DateTime," + fechaDesde + ",111) AND DATEADD(MINUTE, 1439, CONVERT(DateTime," + fechaHasta + ",111))"; 
            }

            switch (cantFiltros)
            {
                case 0:
                    where = "WHERE 0=0 ";
                    break;
                case 1:
                    switch (filtro[0])
                    {
                        case 'R':
                            where = "WHERE " + whereRubro + " ";
                            break;
                        case 'D':
                            where = "WHERE " + whereDescripcion + " ";
                            break;
                        case 'F':
                            where = "WHERE " + whereFecha + " ";
                            break;
                    }
                    break;
                case 2:
                    if (filtro == "RD" | filtro == "DR") where = "WHERE " + whereRubro + " AND " + whereDescripcion + " ";
                    if (filtro == "DF" | filtro == "FD") where = "WHERE " + whereDescripcion + " AND " + whereFecha + " ";
                    if (filtro == "FR" | filtro == "RF") where = "WHERE " + whereFecha + " AND " + whereRubro + " ";
                    break;
                case 3:
                    where = "WHERE " + whereRubro + " AND " + whereDescripcion + " AND " + whereFecha + " ";
                    break;
            }

            string consultaMaestra = "SELECT p.idPublicacion, p.descripcion as Descripcion, p.direccion as Direccion, r.descripcion as Rubro FROM DATEROS.publicacion p, DATEROS.estados e, DATEROS.grado g, DATEROS.rubro r " + where + "AND r.idRubro = p.idRubro AND p.idEstado=e.idEstado AND e.estado='Publicada' AND p.idGrado=g.idGrado ORDER BY porcentaje DESC";
            
            resultado_query = c.llenarDataGridView(dgv_publicaciones, consultaMaestra);
            total_filas = resultado_query.Rows.Count;
            total_paginas = total_filas / max_filas_por_pagina + ((total_filas % max_filas_por_pagina > 0) ? 1 : 0);
            lbl_paginasTotales.Text = total_paginas.ToString();
            btn_anterior.Enabled = false;
            dgv_publicaciones.DataSource = llenar_pagina();
        }

        private void chk_filtroPorRubro_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_filtroPorRubro.Checked)
            {
                chk_sinRubro.Enabled = true;
                chk_teatro.Enabled = true;
                chk_musicalConcierto.Enabled = true;
                chk_cineTV.Enabled = true;
                chk_danza.Enabled = true;
                chk_deportes.Enabled = true;
                chk_sinRubro.Checked = true;
                lab_requisitoFiltroRubro.Visible = true;
            }
            else
            {
                chk_sinRubro.Enabled = false;
                chk_teatro.Enabled = false;
                chk_musicalConcierto.Enabled = false;
                chk_cineTV.Enabled = false;
                chk_danza.Enabled = false;
                chk_deportes.Enabled = false;
                lab_requisitoFiltroRubro.Visible = false;
            }
        }

        private void chk_filtroPorDescripcion_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_filtroPorDescripcion.Checked)
            {
                txt_descripcion.Enabled = true;
                chk_textoExacto.Enabled = true;
            }
            else
            {
                txt_descripcion.Enabled = false;
                chk_textoExacto.Enabled = false;
            }
        }

        private void chk_filtroPorFecha_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_filtroPorFecha.Checked)
            {
                lab_fechaDesde.Enabled = true;
                lab_fechaHasta.Enabled = true;
                dtp_fechaDesde.Enabled = true;
                dtp_fechaHasta.Enabled = true;
            }
            else
            {
                lab_fechaDesde.Enabled = false;
                lab_fechaHasta.Enabled = false;
                dtp_fechaDesde.Enabled = false;
                dtp_fechaHasta.Enabled = false;
            }
        }

        private void frm_comprar_Load(object sender, EventArgs e)
        {
            lab_requisitoFiltroRubro.Visible = false;
        }

        private void dtp_fechaDesde_ValueChanged(object sender, EventArgs e)
        {
            if (dtp_fechaDesde.Value > dtp_fechaHasta.Value)
            {
                dtp_fechaHasta.Value = dtp_fechaDesde.Value;
            }
        }

        private void dtp_fechaHasta_ValueChanged(object sender, EventArgs e)
        {
            if (dtp_fechaHasta.Value < dtp_fechaDesde.Value)
            {
                dtp_fechaDesde.Value = dtp_fechaHasta.Value;
            }
        }

        private void btn_ultima_Click(object sender, EventArgs e)
        {
            nro_pagina = total_paginas - 1;
            dgv_publicaciones.DataSource = llenar_pagina();
            btn_anterior.Enabled = true;
            btn_siguiente.Enabled = false;
        }

        private void btn_siguiente_Click(object sender, EventArgs e)
        {
            nro_pagina += 1;
            dgv_publicaciones.DataSource = llenar_pagina();
            if (nro_pagina == (total_paginas - 1))
            {
                btn_siguiente.Enabled = false;
            }
            else
            {
                btn_siguiente.Enabled = true;
            }
            btn_anterior.Enabled = true;
        }

        private void btn_anterior_Click(object sender, EventArgs e)
        {
            nro_pagina -= 1;
            dgv_publicaciones.DataSource = llenar_pagina();
            if (nro_pagina == 0)
            {
                btn_anterior.Enabled = false;
            }
            else
            {
                btn_anterior.Enabled = true;
            }
            btn_siguiente.Enabled = true;
        }

        private void btn_primera_Click(object sender, EventArgs e)
        {
            nro_pagina = 0;
            dgv_publicaciones.DataSource = llenar_pagina();
            btn_anterior.Enabled = false;
            btn_siguiente.Enabled = true;
        }

        private DataTable llenar_pagina()
        {
            lbl_paginaActual.Text = (nro_pagina + 1).ToString();
            try
            { 
                return resultado_query.Select().Skip(max_filas_por_pagina * nro_pagina).Take(Math.Min(max_filas_por_pagina, total_filas)).CopyToDataTable();
            }
            catch
            {
                MessageBox.Show("No existen publicaciones");
                return new DataTable();
            }
        }

        private void dgv_publicaciones_CellContentClick(object sender, DataGridViewCellEventArgs e){}

        private void btn_seleccionUbicaciones_Click(object sender, EventArgs e)
        {
            if(rol == "Administrativo")
            {
                MessageBox.Show("El administrador no está habilitado para realizar compras.");
            }
            else
            {
                string consultaFechaCreacion = string.Format("SELECT fechaCreacion FROM DATEROS.publicacion WHERE idPublicacion = '" + dgv_publicaciones.CurrentRow.Cells[0].Value.ToString() + "'");
                DataSet dscl = Utilidades.ejecutar(consultaFechaCreacion);
                string fechaCreacion = dscl.Tables[0].Rows[0]["fechaCreacion"].ToString();
            
                if (Properties.Settings.Default.FechaDelSistema >= Convert.ToDateTime(fechaCreacion))
                {
                    this.Hide();
                    Comprar.Seleccion_Ubicaciones su = new Comprar.Seleccion_Ubicaciones(dgv_publicaciones.CurrentRow.Cells[0].Value.ToString(), usuario);
                    su.Show();
                }
                else
                {
                MessageBox.Show("La fecha de compra debe ser mayor a la fecha de creacion de la publicacion. No esta permitido comprar en esta publicacion");
                }
            }
        }
    }
}
