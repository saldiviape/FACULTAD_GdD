﻿namespace PalcoNet.Comprar
{
    partial class Seleccion_Ubicaciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_ubicaciones = new System.Windows.Forms.DataGridView();
            this.Seleccion = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.lab_seleccionGrilla = new System.Windows.Forms.Label();
            this.btn_comprar = new System.Windows.Forms.Button();
            this.lab_metodoDePago = new System.Windows.Forms.Label();
            this.btn_seleccionar = new System.Windows.Forms.Button();
            this.lab_funcion = new System.Windows.Forms.Label();
            this.cmb_funcion = new System.Windows.Forms.ComboBox();
            this.btn_seleccionarFuncion = new System.Windows.Forms.Button();
            this.txt_metodoDePago = new System.Windows.Forms.TextBox();
            this.btn_actualizar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ubicaciones)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_ubicaciones
            // 
            this.dgv_ubicaciones.AllowUserToAddRows = false;
            this.dgv_ubicaciones.AllowUserToDeleteRows = false;
            this.dgv_ubicaciones.AllowUserToOrderColumns = true;
            this.dgv_ubicaciones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_ubicaciones.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Seleccion});
            this.dgv_ubicaciones.Location = new System.Drawing.Point(38, 86);
            this.dgv_ubicaciones.Name = "dgv_ubicaciones";
            this.dgv_ubicaciones.ReadOnly = true;
            this.dgv_ubicaciones.Size = new System.Drawing.Size(824, 250);
            this.dgv_ubicaciones.TabIndex = 16;
            // 
            // Seleccion
            // 
            this.Seleccion.HeaderText = "Seleccion";
            this.Seleccion.Name = "Seleccion";
            this.Seleccion.ReadOnly = true;
            // 
            // lab_seleccionGrilla
            // 
            this.lab_seleccionGrilla.AutoSize = true;
            this.lab_seleccionGrilla.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lab_seleccionGrilla.Location = new System.Drawing.Point(34, 55);
            this.lab_seleccionGrilla.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lab_seleccionGrilla.Name = "lab_seleccionGrilla";
            this.lab_seleccionGrilla.Size = new System.Drawing.Size(260, 18);
            this.lab_seleccionGrilla.TabIndex = 131;
            this.lab_seleccionGrilla.Text = "Seleccione las ubicaciones de la grilla:";
            // 
            // btn_comprar
            // 
            this.btn_comprar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_comprar.Location = new System.Drawing.Point(350, 447);
            this.btn_comprar.Name = "btn_comprar";
            this.btn_comprar.Size = new System.Drawing.Size(198, 40);
            this.btn_comprar.TabIndex = 132;
            this.btn_comprar.Text = "Comprar";
            this.btn_comprar.UseVisualStyleBackColor = true;
            this.btn_comprar.Click += new System.EventHandler(this.btn_comprar_Click);
            // 
            // lab_metodoDePago
            // 
            this.lab_metodoDePago.AutoSize = true;
            this.lab_metodoDePago.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lab_metodoDePago.Location = new System.Drawing.Point(34, 405);
            this.lab_metodoDePago.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lab_metodoDePago.Name = "lab_metodoDePago";
            this.lab_metodoDePago.Size = new System.Drawing.Size(120, 18);
            this.lab_metodoDePago.TabIndex = 137;
            this.lab_metodoDePago.Text = "Método de pago:";
            // 
            // btn_seleccionar
            // 
            this.btn_seleccionar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_seleccionar.Location = new System.Drawing.Point(38, 353);
            this.btn_seleccionar.Name = "btn_seleccionar";
            this.btn_seleccionar.Size = new System.Drawing.Size(125, 34);
            this.btn_seleccionar.TabIndex = 139;
            this.btn_seleccionar.Text = "Seleccionar";
            this.btn_seleccionar.UseVisualStyleBackColor = true;
            this.btn_seleccionar.Click += new System.EventHandler(this.btn_seleccionar_Click);
            // 
            // lab_funcion
            // 
            this.lab_funcion.AutoSize = true;
            this.lab_funcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lab_funcion.Location = new System.Drawing.Point(34, 20);
            this.lab_funcion.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lab_funcion.Name = "lab_funcion";
            this.lab_funcion.Size = new System.Drawing.Size(210, 18);
            this.lab_funcion.TabIndex = 140;
            this.lab_funcion.Text = "Seleccione el dia de la funcion:";
            // 
            // cmb_funcion
            // 
            this.cmb_funcion.FormattingEnabled = true;
            this.cmb_funcion.Location = new System.Drawing.Point(244, 20);
            this.cmb_funcion.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmb_funcion.Name = "cmb_funcion";
            this.cmb_funcion.Size = new System.Drawing.Size(250, 21);
            this.cmb_funcion.TabIndex = 141;
            // 
            // btn_seleccionarFuncion
            // 
            this.btn_seleccionarFuncion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_seleccionarFuncion.Location = new System.Drawing.Point(509, 13);
            this.btn_seleccionarFuncion.Name = "btn_seleccionarFuncion";
            this.btn_seleccionarFuncion.Size = new System.Drawing.Size(173, 34);
            this.btn_seleccionarFuncion.TabIndex = 142;
            this.btn_seleccionarFuncion.Text = "Seleccionar Funcion";
            this.btn_seleccionarFuncion.UseVisualStyleBackColor = true;
            this.btn_seleccionarFuncion.Click += new System.EventHandler(this.btn_seleccionarFuncion_Click);
            // 
            // txt_metodoDePago
            // 
            this.txt_metodoDePago.Enabled = false;
            this.txt_metodoDePago.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_metodoDePago.Location = new System.Drawing.Point(159, 402);
            this.txt_metodoDePago.Name = "txt_metodoDePago";
            this.txt_metodoDePago.Size = new System.Drawing.Size(282, 24);
            this.txt_metodoDePago.TabIndex = 143;
            this.txt_metodoDePago.TextChanged += new System.EventHandler(this.txt_metodoDePago_TextChanged);
            // 
            // btn_actualizar
            // 
            this.btn_actualizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_actualizar.Location = new System.Drawing.Point(447, 402);
            this.btn_actualizar.Name = "btn_actualizar";
            this.btn_actualizar.Size = new System.Drawing.Size(101, 24);
            this.btn_actualizar.TabIndex = 144;
            this.btn_actualizar.Text = "Actualizar";
            this.btn_actualizar.UseVisualStyleBackColor = true;
            this.btn_actualizar.Click += new System.EventHandler(this.btn_actualizar_Click);
            // 
            // Seleccion_Ubicaciones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(901, 509);
            this.Controls.Add(this.btn_actualizar);
            this.Controls.Add(this.txt_metodoDePago);
            this.Controls.Add(this.btn_seleccionarFuncion);
            this.Controls.Add(this.cmb_funcion);
            this.Controls.Add(this.lab_funcion);
            this.Controls.Add(this.btn_seleccionar);
            this.Controls.Add(this.lab_metodoDePago);
            this.Controls.Add(this.btn_comprar);
            this.Controls.Add(this.lab_seleccionGrilla);
            this.Controls.Add(this.dgv_ubicaciones);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Seleccion_Ubicaciones";
            this.Text = "Seleccion de Ubicaciones";
            this.Load += new System.EventHandler(this.Seleccion_Ubicaciones_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ubicaciones)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_ubicaciones;
        private System.Windows.Forms.Label lab_seleccionGrilla;
        private System.Windows.Forms.Button btn_comprar;
        private System.Windows.Forms.Label lab_metodoDePago;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Seleccion;
        private System.Windows.Forms.Button btn_seleccionar;
        private System.Windows.Forms.Label lab_funcion;
        private System.Windows.Forms.ComboBox cmb_funcion;
        private System.Windows.Forms.Button btn_seleccionarFuncion;
        private System.Windows.Forms.TextBox txt_metodoDePago;
        private System.Windows.Forms.Button btn_actualizar;
    }
}