﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PalcoNet.libreria;

namespace PalcoNet.Comprar
{
    public partial class Seleccion_Ubicaciones : Form
    {
        string publicacion;
        string usuario;
        comandos cma = new comandos();

        public Seleccion_Ubicaciones(string publi, string usu)
        {
            this.publicacion = publi;
            this.usuario = usu;
            InitializeComponent();
        }

        private void Seleccion_Ubicaciones_Load(object sender, EventArgs e)
        {
            cma.cargarFunciones(cmb_funcion, publicacion);
            cmb_funcion.DropDownStyle = ComboBoxStyle.DropDownList;

            string consultaExistenciaNroTarjeta = string.Format("SELECT CASE WHEN EXISTS(SELECT nroTarjeta FROM DATEROS.clientes WHERE nroTarjeta IS NOT NULL and username = '" + usuario + "') THEN 1 ELSE 0 END as bit");
            DataSet ds_cent = Utilidades.ejecutar(consultaExistenciaNroTarjeta);
            if (ds_cent.Tables[0].Rows[0]["bit"].ToString() == Convert.ToString(1)) // tiene tarjeta asociada
            {
                string consultaNroTarjeta = string.Format("SELECT nroTarjeta FROM DATEROS.clientes WHERE username = '" + usuario + "'");
                DataSet ds_cnt = Utilidades.ejecutar(consultaNroTarjeta);
                txt_metodoDePago.Text = ds_cnt.Tables[0].Rows[0]["nroTarjeta"].ToString();
                if (txt_metodoDePago.Text == "")
                {
                    btn_comprar.Enabled = false;
                }
                else
                {
                    btn_comprar.Enabled = true;
                }
                // ... y puede comprar sin problemas
            }
            else // no tiene tarjeta asociada
            {
                MessageBox.Show("Para comprar es necesario tener una tarjeta de crédito asociada.");
                Comprar.Alta_Tarjeta at = new Comprar.Alta_Tarjeta(usuario);
                at.Show();
                at.TopMost = true;
            }

        }

        private void btn_seleccionar_Click(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(dgv_ubicaciones.CurrentRow.Cells[0].Value) == false)
            {
                dgv_ubicaciones.CurrentRow.Cells[0].Value = true;
            }
            else
            {
                dgv_ubicaciones.CurrentRow.Cells[0].Value = false;
            }
        }

        private bool comprar(string descr, string ubi)
        {
            try
            {
                string consultaIdCliente = string.Format("SELECT idCliente FROM DATEROS.clientes WHERE username = '" + usuario + "'");
                DataSet ds_cnt = Utilidades.ejecutar(consultaIdCliente);
                string idCliente = ds_cnt.Tables[0].Rows[0]["idCliente"].ToString();

                string compra = string.Format("EXEC DATEROS.comprar '{0}', '{1}', '{2}', '{3}'", idCliente, Properties.Settings.Default.FechaDelSistema, descr, ubi);
                libreria.Utilidades.ejecutar(compra);

                MessageBox.Show("Se ha realizado la compra");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }


        private void btn_comprar_Click(object sender, EventArgs e)
        {
            int i = 0;
            foreach (DataGridViewRow row in dgv_ubicaciones.Rows)
                {
                    if (Convert.ToBoolean(row.Cells[0].Value))
                    {
                       this.comprar(dgv_ubicaciones.Rows[i].Cells[2].Value.ToString(), dgv_ubicaciones.Rows[i].Cells[1].Value.ToString());
                    }
                    i++;
                }
            cma.llenarDataGridView(dgv_ubicaciones, "SELECT f.idFuncion, u.idUbicacion, descripcion, fila, asiento, precio FROM DATEROS.ubicacion u, DATEROS.funcion_ubicacion fu, DATEROS.tipoUbicacion tu, DATEROS.funcion f WHERE fu.idFuncion=f.idFuncion AND tu.idTipoUbicacion=u.idTipoUbicacion AND u.idUbicacion=fu.idUbicacion AND fechaHora= '" + Convert.ToDateTime(cmb_funcion.SelectedValue) + "' AND fu.vendido = 0 ORDER BY 3,4,5,6");
        }

        
        private void btn_seleccionarFuncion_Click(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.FechaDelSistema < Convert.ToDateTime(cmb_funcion.SelectedValue))
            {
                cma.llenarDataGridView(dgv_ubicaciones, "SELECT f.idFuncion, u.idUbicacion, descripcion, fila, asiento, precio FROM DATEROS.ubicacion u, DATEROS.funcion_ubicacion fu, DATEROS.tipoUbicacion tu, DATEROS.funcion f WHERE fu.idFuncion=f.idFuncion AND tu.idTipoUbicacion=u.idTipoUbicacion AND u.idUbicacion=fu.idUbicacion AND fechaHora= '" + Convert.ToDateTime(cmb_funcion.SelectedValue) + "' AND fu.vendido = 0 ORDER BY 3,4,5,6");
            }
            else
            {
                MessageBox.Show("No puede seleccionar una funcion con fecha anterior a la actual");
            }
        }

        private void btn_actualizar_Click(object sender, EventArgs e)
        {
            string consultaNroTarjeta = string.Format("SELECT nroTarjeta FROM DATEROS.clientes WHERE username = '" + usuario + "'");
            DataSet ds_cnt = Utilidades.ejecutar(consultaNroTarjeta);
            txt_metodoDePago.Text = ds_cnt.Tables[0].Rows[0]["nroTarjeta"].ToString();
        }

        private void txt_metodoDePago_TextChanged(object sender, EventArgs e)
        {
            if (txt_metodoDePago.Text == "")
            {
                btn_comprar.Enabled = false;
            }
            else
            {
                btn_comprar.Enabled = true;
            }
        }
    }
}
