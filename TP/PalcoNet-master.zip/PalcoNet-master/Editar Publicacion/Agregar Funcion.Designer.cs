﻿namespace PalcoNet.Editar_Publicacion
{
    partial class Agregar_Funcion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_agregarFuncion = new System.Windows.Forms.Button();
            this.dtp_fechaHorario = new System.Windows.Forms.DateTimePicker();
            this.lab_agregarFuncion = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_agregarFuncion
            // 
            this.btn_agregarFuncion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_agregarFuncion.Location = new System.Drawing.Point(193, 78);
            this.btn_agregarFuncion.Margin = new System.Windows.Forms.Padding(6);
            this.btn_agregarFuncion.Name = "btn_agregarFuncion";
            this.btn_agregarFuncion.Size = new System.Drawing.Size(230, 53);
            this.btn_agregarFuncion.TabIndex = 24;
            this.btn_agregarFuncion.Text = "Agregar Funcion";
            this.btn_agregarFuncion.UseVisualStyleBackColor = true;
            this.btn_agregarFuncion.Click += new System.EventHandler(this.btn_agregarFuncion_Click);
            // 
            // dtp_fechaHorario
            // 
            this.dtp_fechaHorario.CustomFormat = "yyyy/MM/dd HH:mm:ss";
            this.dtp_fechaHorario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_fechaHorario.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_fechaHorario.Location = new System.Drawing.Point(341, 23);
            this.dtp_fechaHorario.Margin = new System.Windows.Forms.Padding(6);
            this.dtp_fechaHorario.Name = "dtp_fechaHorario";
            this.dtp_fechaHorario.Size = new System.Drawing.Size(244, 29);
            this.dtp_fechaHorario.TabIndex = 23;
            // 
            // lab_agregarFuncion
            // 
            this.lab_agregarFuncion.AutoSize = true;
            this.lab_agregarFuncion.Location = new System.Drawing.Point(13, 27);
            this.lab_agregarFuncion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_agregarFuncion.Name = "lab_agregarFuncion";
            this.lab_agregarFuncion.Size = new System.Drawing.Size(318, 24);
            this.lab_agregarFuncion.TabIndex = 25;
            this.lab_agregarFuncion.Text = "Ingrese la fecha de la nueva funcion:";
            // 
            // Agregar_Funcion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(616, 146);
            this.Controls.Add(this.lab_agregarFuncion);
            this.Controls.Add(this.btn_agregarFuncion);
            this.Controls.Add(this.dtp_fechaHorario);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Agregar_Funcion";
            this.Text = "Agregar Funcion";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_agregarFuncion;
        private System.Windows.Forms.DateTimePicker dtp_fechaHorario;
        private System.Windows.Forms.Label lab_agregarFuncion;
    }
}