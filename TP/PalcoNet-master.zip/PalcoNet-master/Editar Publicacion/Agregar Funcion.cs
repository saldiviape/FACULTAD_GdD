﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Editar_Publicacion
{
    public partial class Agregar_Funcion : Form
    {
        comandos cma = new comandos();
        string descripcion;
        string direccion;

        public Agregar_Funcion(string desc, string dir)
        {
            this.descripcion = desc;
            this.direccion = dir;
            InitializeComponent();
        }

        private bool agregarFuncion()
        {
            try
            {
                string agregarFuncion = string.Format("EXEC DATEROS.agregarFuncion '{0}', '{1}', '{2}', '{3}'", descripcion, direccion, Convert.ToDateTime(dtp_fechaHorario.Value.ToString()), Properties.Settings.Default.FechaDelSistema);
                libreria.Utilidades.ejecutar(agregarFuncion);

                MessageBox.Show("Se ha agregado la nueva funcion");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_agregarFuncion_Click(object sender, EventArgs e)
        {
            this.agregarFuncion();
            this.Hide();
        }
    }
}
