﻿namespace PalcoNet.Editar_Publicacion
{
    partial class Agregar_Ubicacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_precio = new System.Windows.Forms.TextBox();
            this.txt_asiento = new System.Windows.Forms.TextBox();
            this.txt_fila = new System.Windows.Forms.TextBox();
            this.btn_agregarUbicacion = new System.Windows.Forms.Button();
            this.cmb_tipoDeUbicacion = new System.Windows.Forms.ComboBox();
            this.lab_precio = new System.Windows.Forms.Label();
            this.lab_tipoDeUbicacion = new System.Windows.Forms.Label();
            this.lab_asiento = new System.Windows.Forms.Label();
            this.lab_fila = new System.Windows.Forms.Label();
            this.cmb_funcion = new System.Windows.Forms.ComboBox();
            this.lab_funcion = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_precio
            // 
            this.txt_precio.Location = new System.Drawing.Point(148, 154);
            this.txt_precio.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_precio.Name = "txt_precio";
            this.txt_precio.Size = new System.Drawing.Size(160, 20);
            this.txt_precio.TabIndex = 35;
            // 
            // txt_asiento
            // 
            this.txt_asiento.Location = new System.Drawing.Point(148, 123);
            this.txt_asiento.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_asiento.Name = "txt_asiento";
            this.txt_asiento.Size = new System.Drawing.Size(160, 20);
            this.txt_asiento.TabIndex = 34;
            // 
            // txt_fila
            // 
            this.txt_fila.Location = new System.Drawing.Point(148, 90);
            this.txt_fila.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txt_fila.Name = "txt_fila";
            this.txt_fila.Size = new System.Drawing.Size(160, 20);
            this.txt_fila.TabIndex = 33;
            // 
            // btn_agregarUbicacion
            // 
            this.btn_agregarUbicacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_agregarUbicacion.Location = new System.Drawing.Point(18, 184);
            this.btn_agregarUbicacion.Name = "btn_agregarUbicacion";
            this.btn_agregarUbicacion.Size = new System.Drawing.Size(290, 35);
            this.btn_agregarUbicacion.TabIndex = 32;
            this.btn_agregarUbicacion.Text = "Agregar Ubicación";
            this.btn_agregarUbicacion.UseVisualStyleBackColor = true;
            this.btn_agregarUbicacion.Click += new System.EventHandler(this.btn_agregarUbicacion_Click);
            // 
            // cmb_tipoDeUbicacion
            // 
            this.cmb_tipoDeUbicacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_tipoDeUbicacion.FormattingEnabled = true;
            this.cmb_tipoDeUbicacion.Location = new System.Drawing.Point(148, 55);
            this.cmb_tipoDeUbicacion.Name = "cmb_tipoDeUbicacion";
            this.cmb_tipoDeUbicacion.Size = new System.Drawing.Size(160, 26);
            this.cmb_tipoDeUbicacion.TabIndex = 31;
            // 
            // lab_precio
            // 
            this.lab_precio.AutoSize = true;
            this.lab_precio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_precio.Location = new System.Drawing.Point(90, 152);
            this.lab_precio.Name = "lab_precio";
            this.lab_precio.Size = new System.Drawing.Size(55, 18);
            this.lab_precio.TabIndex = 30;
            this.lab_precio.Text = "Precio:";
            this.lab_precio.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lab_tipoDeUbicacion
            // 
            this.lab_tipoDeUbicacion.AutoSize = true;
            this.lab_tipoDeUbicacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_tipoDeUbicacion.Location = new System.Drawing.Point(15, 58);
            this.lab_tipoDeUbicacion.Name = "lab_tipoDeUbicacion";
            this.lab_tipoDeUbicacion.Size = new System.Drawing.Size(131, 18);
            this.lab_tipoDeUbicacion.TabIndex = 27;
            this.lab_tipoDeUbicacion.Text = "Tipo de Ubicación:";
            this.lab_tipoDeUbicacion.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lab_asiento
            // 
            this.lab_asiento.AutoSize = true;
            this.lab_asiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_asiento.Location = new System.Drawing.Point(83, 120);
            this.lab_asiento.Name = "lab_asiento";
            this.lab_asiento.Size = new System.Drawing.Size(61, 18);
            this.lab_asiento.TabIndex = 29;
            this.lab_asiento.Text = "Asiento:";
            this.lab_asiento.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lab_fila
            // 
            this.lab_fila.AutoSize = true;
            this.lab_fila.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_fila.Location = new System.Drawing.Point(108, 88);
            this.lab_fila.Name = "lab_fila";
            this.lab_fila.Size = new System.Drawing.Size(35, 18);
            this.lab_fila.TabIndex = 28;
            this.lab_fila.Text = "Fila:";
            this.lab_fila.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmb_funcion
            // 
            this.cmb_funcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_funcion.FormattingEnabled = true;
            this.cmb_funcion.Location = new System.Drawing.Point(148, 18);
            this.cmb_funcion.Name = "cmb_funcion";
            this.cmb_funcion.Size = new System.Drawing.Size(160, 26);
            this.cmb_funcion.TabIndex = 37;
            this.cmb_funcion.SelectedIndexChanged += new System.EventHandler(this.cmb_funcion_SelectedIndexChanged);
            // 
            // lab_funcion
            // 
            this.lab_funcion.AutoSize = true;
            this.lab_funcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_funcion.Location = new System.Drawing.Point(78, 20);
            this.lab_funcion.Name = "lab_funcion";
            this.lab_funcion.Size = new System.Drawing.Size(65, 18);
            this.lab_funcion.TabIndex = 36;
            this.lab_funcion.Text = "Funcion:";
            this.lab_funcion.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Agregar_Ubicacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(329, 236);
            this.Controls.Add(this.cmb_funcion);
            this.Controls.Add(this.lab_funcion);
            this.Controls.Add(this.txt_precio);
            this.Controls.Add(this.txt_asiento);
            this.Controls.Add(this.txt_fila);
            this.Controls.Add(this.btn_agregarUbicacion);
            this.Controls.Add(this.cmb_tipoDeUbicacion);
            this.Controls.Add(this.lab_precio);
            this.Controls.Add(this.lab_tipoDeUbicacion);
            this.Controls.Add(this.lab_asiento);
            this.Controls.Add(this.lab_fila);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Agregar_Ubicacion";
            this.Text = "Agregar Ubicacion";
            this.Load += new System.EventHandler(this.Agregar_Ubicacion_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_precio;
        private System.Windows.Forms.TextBox txt_asiento;
        private System.Windows.Forms.TextBox txt_fila;
        private System.Windows.Forms.Button btn_agregarUbicacion;
        private System.Windows.Forms.ComboBox cmb_tipoDeUbicacion;
        private System.Windows.Forms.Label lab_precio;
        private System.Windows.Forms.Label lab_tipoDeUbicacion;
        private System.Windows.Forms.Label lab_asiento;
        private System.Windows.Forms.Label lab_fila;
        private System.Windows.Forms.ComboBox cmb_funcion;
        private System.Windows.Forms.Label lab_funcion;
    }
}