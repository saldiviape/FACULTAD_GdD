﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PalcoNet.libreria;

namespace PalcoNet.Editar_Publicacion
{
    public partial class Agregar_Ubicacion : Form
    {
        comandos cma = new comandos();
        string descripcion;
        string direccion;

        public Agregar_Ubicacion(string desc, string dir)
        {
            this.descripcion = desc;
            this.direccion = dir;
            InitializeComponent();
        }

        private bool agregarUbicacion()
        {
            try
            {
                string consultaIdPublicacion = string.Format("SELECT idPublicacion FROM DATEROS.publicacion WHERE descripcion = '" + descripcion + "' AND direccion= '" + direccion + "'");
                DataSet dscl = Utilidades.ejecutar(consultaIdPublicacion);
                string idPublicacion = dscl.Tables[0].Rows[0]["idPublicacion"].ToString();

                string agregarUbicacion = string.Format("EXEC DATEROS.agregarUbicacion '{0}', '{1}', '{2}', '{3}', '{4}', '{5}'", idPublicacion, cmb_funcion.Text.Trim(), cmb_tipoDeUbicacion.Text.Trim(), txt_fila.Text.Trim(), txt_asiento.Text.Trim(), txt_precio.Text.Trim());
                libreria.Utilidades.ejecutar(agregarUbicacion);

                MessageBox.Show("Se ha agregado correctamente la ubicacion");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_agregarUbicacion_Click(object sender, EventArgs e)
        {
            this.agregarUbicacion();
            this.Hide();
        }

        private void Agregar_Ubicacion_Load(object sender, EventArgs e)
        {
            string consultaIdPublicacion = string.Format("SELECT idPublicacion FROM DATEROS.publicacion WHERE descripcion = '" + descripcion + "' AND direccion= '" + direccion + "'");
            DataSet dscl = Utilidades.ejecutar(consultaIdPublicacion);
            string idPublicacion = dscl.Tables[0].Rows[0]["idPublicacion"].ToString();

            cmb_tipoDeUbicacion.Enabled = false;
            txt_fila.Enabled = false;
            txt_asiento.Enabled = false;
            txt_precio.Enabled = false;
            btn_agregarUbicacion.Enabled = false;

            cma.cargarTiposUbicacion(cmb_tipoDeUbicacion);
            cma.cargarFunciones(cmb_funcion, idPublicacion);
            cmb_tipoDeUbicacion.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_funcion.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void cmb_funcion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb_funcion.SelectedValue.ToString() != "\0")
            {
                cmb_tipoDeUbicacion.Enabled = true;
                txt_fila.Enabled = true;
                txt_asiento.Enabled = true;
                txt_precio.Enabled = true;
                btn_agregarUbicacion.Enabled = true;
            }
            if (string.IsNullOrEmpty(cmb_funcion.SelectedValue.ToString()))
            {
                cmb_tipoDeUbicacion.Enabled = false;
                txt_fila.Enabled = false;
                txt_asiento.Enabled = false;
                txt_precio.Enabled = false;
                btn_agregarUbicacion.Enabled = false;
            }
        }
    }
}
