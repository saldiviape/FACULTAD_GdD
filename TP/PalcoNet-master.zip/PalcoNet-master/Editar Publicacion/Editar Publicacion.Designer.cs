﻿namespace PalcoNet.Editar_Publicacion
{
    partial class frm_editarPublicacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_modifDatos = new System.Windows.Forms.Button();
            this.btn_agregarFuncion = new System.Windows.Forms.Button();
            this.btn_quitarFuncion = new System.Windows.Forms.Button();
            this.btn_modifUbicaciones = new System.Windows.Forms.Button();
            this.chk_descripcion = new System.Windows.Forms.CheckBox();
            this.chk_direccion = new System.Windows.Forms.CheckBox();
            this.txt_direccion = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_Limpiar = new System.Windows.Forms.Button();
            this.btn_Buscar = new System.Windows.Forms.Button();
            this.txt_descripcion = new System.Windows.Forms.TextBox();
            this.btn_modifGrado = new System.Windows.Forms.Button();
            this.btn_modifRubro = new System.Windows.Forms.Button();
            this.lab_seleccionGrilla = new System.Windows.Forms.Label();
            this.btn_publicar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_modifDatos
            // 
            this.btn_modifDatos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_modifDatos.Location = new System.Drawing.Point(58, 499);
            this.btn_modifDatos.Name = "btn_modifDatos";
            this.btn_modifDatos.Size = new System.Drawing.Size(338, 56);
            this.btn_modifDatos.TabIndex = 6;
            this.btn_modifDatos.Text = "Modificar Datos De Publicacion";
            this.btn_modifDatos.UseVisualStyleBackColor = true;
            this.btn_modifDatos.Click += new System.EventHandler(this.btn_modifDatos_Click);
            // 
            // btn_agregarFuncion
            // 
            this.btn_agregarFuncion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_agregarFuncion.Location = new System.Drawing.Point(58, 561);
            this.btn_agregarFuncion.Name = "btn_agregarFuncion";
            this.btn_agregarFuncion.Size = new System.Drawing.Size(338, 56);
            this.btn_agregarFuncion.TabIndex = 7;
            this.btn_agregarFuncion.Text = "Agregar Funcion";
            this.btn_agregarFuncion.UseVisualStyleBackColor = true;
            this.btn_agregarFuncion.Click += new System.EventHandler(this.btn_agregarFuncion_Click);
            // 
            // btn_quitarFuncion
            // 
            this.btn_quitarFuncion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_quitarFuncion.Location = new System.Drawing.Point(402, 499);
            this.btn_quitarFuncion.Name = "btn_quitarFuncion";
            this.btn_quitarFuncion.Size = new System.Drawing.Size(338, 56);
            this.btn_quitarFuncion.TabIndex = 8;
            this.btn_quitarFuncion.Text = "Quitar Funcion";
            this.btn_quitarFuncion.UseVisualStyleBackColor = true;
            this.btn_quitarFuncion.Click += new System.EventHandler(this.btn_quitarFuncion_Click);
            // 
            // btn_modifUbicaciones
            // 
            this.btn_modifUbicaciones.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_modifUbicaciones.Location = new System.Drawing.Point(402, 561);
            this.btn_modifUbicaciones.Name = "btn_modifUbicaciones";
            this.btn_modifUbicaciones.Size = new System.Drawing.Size(338, 56);
            this.btn_modifUbicaciones.TabIndex = 9;
            this.btn_modifUbicaciones.Text = "Modificar Ubicaciones";
            this.btn_modifUbicaciones.UseVisualStyleBackColor = true;
            this.btn_modifUbicaciones.Click += new System.EventHandler(this.btn_modifUbicaciones_Click);
            // 
            // chk_descripcion
            // 
            this.chk_descripcion.AutoSize = true;
            this.chk_descripcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_descripcion.Location = new System.Drawing.Point(99, 59);
            this.chk_descripcion.Margin = new System.Windows.Forms.Padding(4);
            this.chk_descripcion.Name = "chk_descripcion";
            this.chk_descripcion.Size = new System.Drawing.Size(121, 24);
            this.chk_descripcion.TabIndex = 127;
            this.chk_descripcion.Text = "Descripcion";
            this.chk_descripcion.UseVisualStyleBackColor = true;
            // 
            // chk_direccion
            // 
            this.chk_direccion.AutoSize = true;
            this.chk_direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_direccion.Location = new System.Drawing.Point(99, 93);
            this.chk_direccion.Margin = new System.Windows.Forms.Padding(4);
            this.chk_direccion.Name = "chk_direccion";
            this.chk_direccion.Size = new System.Drawing.Size(103, 24);
            this.chk_direccion.TabIndex = 126;
            this.chk_direccion.Text = "Direccion";
            this.chk_direccion.UseVisualStyleBackColor = true;
            // 
            // txt_direccion
            // 
            this.txt_direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_direccion.Location = new System.Drawing.Point(250, 91);
            this.txt_direccion.Margin = new System.Windows.Forms.Padding(4);
            this.txt_direccion.Name = "txt_direccion";
            this.txt_direccion.Size = new System.Drawing.Size(389, 26);
            this.txt_direccion.TabIndex = 124;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(47, 202);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(707, 247);
            this.dataGridView1.TabIndex = 120;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(43, 18);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(283, 24);
            this.label1.TabIndex = 119;
            this.label1.Text = "Seleccionar Filtros de Búsqueda";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_Limpiar
            // 
            this.btn_Limpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Limpiar.Location = new System.Drawing.Point(47, 136);
            this.btn_Limpiar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Limpiar.Name = "btn_Limpiar";
            this.btn_Limpiar.Size = new System.Drawing.Size(235, 50);
            this.btn_Limpiar.TabIndex = 118;
            this.btn_Limpiar.Text = "Limpiar";
            this.btn_Limpiar.UseVisualStyleBackColor = true;
            this.btn_Limpiar.Click += new System.EventHandler(this.btn_Limpiar_Click);
            // 
            // btn_Buscar
            // 
            this.btn_Buscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Buscar.Location = new System.Drawing.Point(519, 136);
            this.btn_Buscar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Buscar.Name = "btn_Buscar";
            this.btn_Buscar.Size = new System.Drawing.Size(235, 50);
            this.btn_Buscar.TabIndex = 117;
            this.btn_Buscar.Text = "Buscar";
            this.btn_Buscar.UseVisualStyleBackColor = true;
            this.btn_Buscar.Click += new System.EventHandler(this.btn_Buscar_Click);
            // 
            // txt_descripcion
            // 
            this.txt_descripcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_descripcion.Location = new System.Drawing.Point(250, 57);
            this.txt_descripcion.Margin = new System.Windows.Forms.Padding(4);
            this.txt_descripcion.Name = "txt_descripcion";
            this.txt_descripcion.Size = new System.Drawing.Size(389, 26);
            this.txt_descripcion.TabIndex = 116;
            // 
            // btn_modifGrado
            // 
            this.btn_modifGrado.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_modifGrado.Location = new System.Drawing.Point(402, 623);
            this.btn_modifGrado.Name = "btn_modifGrado";
            this.btn_modifGrado.Size = new System.Drawing.Size(338, 56);
            this.btn_modifGrado.TabIndex = 129;
            this.btn_modifGrado.Text = "Modificar Grado";
            this.btn_modifGrado.UseVisualStyleBackColor = true;
            this.btn_modifGrado.Click += new System.EventHandler(this.btn_modifGrado_Click);
            // 
            // btn_modifRubro
            // 
            this.btn_modifRubro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_modifRubro.Location = new System.Drawing.Point(58, 623);
            this.btn_modifRubro.Name = "btn_modifRubro";
            this.btn_modifRubro.Size = new System.Drawing.Size(338, 56);
            this.btn_modifRubro.TabIndex = 128;
            this.btn_modifRubro.Text = "Modificar Rubro";
            this.btn_modifRubro.UseVisualStyleBackColor = true;
            this.btn_modifRubro.Click += new System.EventHandler(this.btn_modifRubro_Click);
            // 
            // lab_seleccionGrilla
            // 
            this.lab_seleccionGrilla.AutoSize = true;
            this.lab_seleccionGrilla.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lab_seleccionGrilla.Location = new System.Drawing.Point(43, 462);
            this.lab_seleccionGrilla.Name = "lab_seleccionGrilla";
            this.lab_seleccionGrilla.Size = new System.Drawing.Size(543, 24);
            this.lab_seleccionGrilla.TabIndex = 130;
            this.lab_seleccionGrilla.Text = "Seleccione una publicacion de la grilla y luego apriete un boton";
            // 
            // btn_publicar
            // 
            this.btn_publicar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_publicar.Location = new System.Drawing.Point(231, 685);
            this.btn_publicar.Name = "btn_publicar";
            this.btn_publicar.Size = new System.Drawing.Size(338, 56);
            this.btn_publicar.TabIndex = 131;
            this.btn_publicar.Text = "Publicar";
            this.btn_publicar.UseVisualStyleBackColor = true;
            this.btn_publicar.Click += new System.EventHandler(this.btn_publicar_Click);
            // 
            // frm_editarPublicacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(798, 758);
            this.Controls.Add(this.btn_publicar);
            this.Controls.Add(this.lab_seleccionGrilla);
            this.Controls.Add(this.btn_modifGrado);
            this.Controls.Add(this.btn_modifRubro);
            this.Controls.Add(this.chk_descripcion);
            this.Controls.Add(this.chk_direccion);
            this.Controls.Add(this.txt_direccion);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Limpiar);
            this.Controls.Add(this.btn_Buscar);
            this.Controls.Add(this.txt_descripcion);
            this.Controls.Add(this.btn_modifUbicaciones);
            this.Controls.Add(this.btn_quitarFuncion);
            this.Controls.Add(this.btn_agregarFuncion);
            this.Controls.Add(this.btn_modifDatos);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frm_editarPublicacion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Editar Publicación";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_modifDatos;
        private System.Windows.Forms.Button btn_agregarFuncion;
        private System.Windows.Forms.Button btn_quitarFuncion;
        private System.Windows.Forms.Button btn_modifUbicaciones;
        private System.Windows.Forms.CheckBox chk_descripcion;
        private System.Windows.Forms.CheckBox chk_direccion;
        private System.Windows.Forms.TextBox txt_direccion;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Limpiar;
        private System.Windows.Forms.Button btn_Buscar;
        private System.Windows.Forms.TextBox txt_descripcion;
        private System.Windows.Forms.Button btn_modifGrado;
        private System.Windows.Forms.Button btn_modifRubro;
        private System.Windows.Forms.Label lab_seleccionGrilla;
        private System.Windows.Forms.Button btn_publicar;
    }
}