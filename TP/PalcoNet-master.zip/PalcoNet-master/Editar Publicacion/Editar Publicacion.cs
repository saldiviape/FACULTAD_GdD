﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Editar_Publicacion
{
    public partial class frm_editarPublicacion : Form
    {
        comandos cma = new comandos();

        public frm_editarPublicacion()
        {
            InitializeComponent();
        }

        private void btn_Limpiar_Click(object sender, EventArgs e)
        {
            Limpiar limpiar = new Limpiar();
            limpiar.limpiarCampos(this);
        }

        private void btn_Buscar_Click(object sender, EventArgs e)
        {
            if (chk_descripcion.Checked & chk_direccion.Checked)
            {
                cma.llenarDataGridView(dataGridView1, "SELECT descripcion, direccion FROM DATEROS.publicacion p, DATEROS.estados e WHERE descripcion LIKE '" + txt_descripcion.Text + "' + '%' AND direccion LIKE '" + txt_direccion.Text + "' + '%' AND p.idEstado = e.idEstado AND e.estado='Borrador'");
            }
            else
            {
                if (chk_descripcion.Checked & !chk_direccion.Checked)
                {
                    cma.llenarDataGridView(dataGridView1, "SELECT descripcion, direccion FROM DATEROS.publicacion p, DATEROS.estados e WHERE descripcion LIKE '" + txt_descripcion.Text + "' + '%' AND p.idEstado = e.idEstado AND e.estado='Borrador'");
                }
                if (!chk_descripcion.Checked & chk_direccion.Checked)
                {
                    cma.llenarDataGridView(dataGridView1, "SELECT descripcion, direccion FROM DATEROS.publicacion p, DATEROS.estados e WHERE direccion LIKE '" + txt_direccion.Text + "' + '%' AND p.idEstado = e.idEstado AND e.estado='Borrador'");
                }
                if (!chk_descripcion.Checked & !chk_direccion.Checked)
                {
                    cma.llenarDataGridView(dataGridView1, "SELECT descripcion, direccion FROM DATEROS.publicacion p, DATEROS.estados e WHERE p.idEstado = e.idEstado AND e.estado='Borrador'");
                }
            }
        }

        private void btn_modifDatos_Click(object sender, EventArgs e)
        {
            Editar_Publicacion.Modificar_Datos md = new Editar_Publicacion.Modificar_Datos(dataGridView1.CurrentRow.Cells[0].Value.ToString(), dataGridView1.CurrentRow.Cells[1].Value.ToString());
            md.Show();
        }

        private void btn_quitarFuncion_Click(object sender, EventArgs e)
        {
            Editar_Publicacion.Quitar_Funcion qf = new Editar_Publicacion.Quitar_Funcion(dataGridView1.CurrentRow.Cells[0].Value.ToString(), dataGridView1.CurrentRow.Cells[1].Value.ToString());
            qf.Show();
        }

        private void btn_modifGrado_Click(object sender, EventArgs e)
        {
            Editar_Publicacion.Modificar_Grado mg = new Editar_Publicacion.Modificar_Grado(dataGridView1.CurrentRow.Cells[0].Value.ToString(), dataGridView1.CurrentRow.Cells[1].Value.ToString());
            mg.Show();
        }

        private void btn_modifRubro_Click(object sender, EventArgs e)
        {
            Editar_Publicacion.Modificar_Rubro mr = new Editar_Publicacion.Modificar_Rubro(dataGridView1.CurrentRow.Cells[0].Value.ToString(), dataGridView1.CurrentRow.Cells[1].Value.ToString());
            mr.Show();
        }

        private void btn_modifUbicaciones_Click(object sender, EventArgs e)
        {
            Editar_Publicacion.Modificar_Ubicaciones mu = new Editar_Publicacion.Modificar_Ubicaciones(dataGridView1.CurrentRow.Cells[0].Value.ToString(), dataGridView1.CurrentRow.Cells[1].Value.ToString());
            mu.Show();
        }

        private void btn_agregarFuncion_Click(object sender, EventArgs e)
        {
            Editar_Publicacion.Agregar_Funcion af = new Editar_Publicacion.Agregar_Funcion(dataGridView1.CurrentRow.Cells[0].Value.ToString(), dataGridView1.CurrentRow.Cells[1].Value.ToString());
            af.Show();
        }

        private bool publicar()
        {
            try
            {
                string publicar = string.Format("EXEC DATEROS.publicar '{0}', '{1}'", dataGridView1.CurrentRow.Cells[0].Value.ToString(), dataGridView1.CurrentRow.Cells[1].Value.ToString());
                libreria.Utilidades.ejecutar(publicar);

                MessageBox.Show("Se ha publicado correctamente");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_publicar_Click(object sender, EventArgs e)
        {
            this.publicar();
        }
    }
}
