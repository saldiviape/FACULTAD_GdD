﻿namespace PalcoNet.Editar_Publicacion
{
    partial class Modificar_Descripcion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_guardarDescripcion = new System.Windows.Forms.Button();
            this.lab_descripcion = new System.Windows.Forms.Label();
            this.txt_descripcion = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_guardarDescripcion
            // 
            this.btn_guardarDescripcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_guardarDescripcion.Location = new System.Drawing.Point(114, 79);
            this.btn_guardarDescripcion.Margin = new System.Windows.Forms.Padding(4);
            this.btn_guardarDescripcion.Name = "btn_guardarDescripcion";
            this.btn_guardarDescripcion.Size = new System.Drawing.Size(303, 43);
            this.btn_guardarDescripcion.TabIndex = 42;
            this.btn_guardarDescripcion.Text = "Guardar Nueva Descripcion";
            this.btn_guardarDescripcion.UseVisualStyleBackColor = true;
            this.btn_guardarDescripcion.Click += new System.EventHandler(this.btn_guardarDescripcion_Click);
            // 
            // lab_descripcion
            // 
            this.lab_descripcion.AutoSize = true;
            this.lab_descripcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_descripcion.Location = new System.Drawing.Point(43, 32);
            this.lab_descripcion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_descripcion.Name = "lab_descripcion";
            this.lab_descripcion.Size = new System.Drawing.Size(115, 24);
            this.lab_descripcion.TabIndex = 41;
            this.lab_descripcion.Text = "Descripción:";
            this.lab_descripcion.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_descripcion
            // 
            this.txt_descripcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_descripcion.Location = new System.Drawing.Point(167, 28);
            this.txt_descripcion.Margin = new System.Windows.Forms.Padding(4);
            this.txt_descripcion.Name = "txt_descripcion";
            this.txt_descripcion.Size = new System.Drawing.Size(325, 29);
            this.txt_descripcion.TabIndex = 40;
            // 
            // Modificar_Descripcion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(529, 150);
            this.Controls.Add(this.btn_guardarDescripcion);
            this.Controls.Add(this.lab_descripcion);
            this.Controls.Add(this.txt_descripcion);
            this.Name = "Modificar_Descripcion";
            this.Text = "Modificar Descripcion";
            this.Load += new System.EventHandler(this.Modificar_Descripcion_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_guardarDescripcion;
        private System.Windows.Forms.Label lab_descripcion;
        private System.Windows.Forms.TextBox txt_descripcion;
    }
}