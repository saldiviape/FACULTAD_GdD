﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Editar_Publicacion
{
    public partial class Modificar_Descripcion : Form
    {
        comandos cma = new comandos();
        string descripcionActual;
        string direccionActual;

        public Modificar_Descripcion(string desc, string dir)
        {
            this.descripcionActual = desc;
            this.direccionActual = dir;
            InitializeComponent();
        }

        private bool modificarDescripcion()
        {
            try
            {
                string cmd = string.Format("EXEC DATEROS.modificacionDescripcion '{0}', '{1}', '{2}'", descripcionActual.Trim(), direccionActual.Trim(), txt_descripcion.Text.Trim());
                libreria.Utilidades.ejecutar(cmd);

                MessageBox.Show("Se ha modificado la descripcion correctamente");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_guardarDescripcion_Click(object sender, EventArgs e)
        {
            this.modificarDescripcion();
            this.Hide();
        }

        private void Modificar_Descripcion_Load(object sender, EventArgs e)
        {
            cma.llenarTextBoxPublicacion(txt_descripcion, "descripcion", descripcionActual, direccionActual);
        }
    }
}
