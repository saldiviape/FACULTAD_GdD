﻿namespace PalcoNet.Editar_Publicacion
{
    partial class Modificar_Direccion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_guardarDireccion = new System.Windows.Forms.Button();
            this.lab_direccion = new System.Windows.Forms.Label();
            this.txt_direccion = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_guardarDireccion
            // 
            this.btn_guardarDireccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_guardarDireccion.Location = new System.Drawing.Point(120, 77);
            this.btn_guardarDireccion.Margin = new System.Windows.Forms.Padding(4);
            this.btn_guardarDireccion.Name = "btn_guardarDireccion";
            this.btn_guardarDireccion.Size = new System.Drawing.Size(303, 43);
            this.btn_guardarDireccion.TabIndex = 45;
            this.btn_guardarDireccion.Text = "Guardar Nueva Direccion";
            this.btn_guardarDireccion.UseVisualStyleBackColor = true;
            this.btn_guardarDireccion.Click += new System.EventHandler(this.btn_guardarDireccion_Click);
            // 
            // lab_direccion
            // 
            this.lab_direccion.AutoSize = true;
            this.lab_direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_direccion.Location = new System.Drawing.Point(48, 30);
            this.lab_direccion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_direccion.Name = "lab_direccion";
            this.lab_direccion.Size = new System.Drawing.Size(95, 24);
            this.lab_direccion.TabIndex = 44;
            this.lab_direccion.Text = "Direccion:";
            this.lab_direccion.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_direccion
            // 
            this.txt_direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_direccion.Location = new System.Drawing.Point(172, 26);
            this.txt_direccion.Margin = new System.Windows.Forms.Padding(4);
            this.txt_direccion.Name = "txt_direccion";
            this.txt_direccion.Size = new System.Drawing.Size(325, 29);
            this.txt_direccion.TabIndex = 43;
            // 
            // Modificar_Direccion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(542, 145);
            this.Controls.Add(this.btn_guardarDireccion);
            this.Controls.Add(this.lab_direccion);
            this.Controls.Add(this.txt_direccion);
            this.Name = "Modificar_Direccion";
            this.Text = "Modificar Direccion";
            this.Load += new System.EventHandler(this.Modificar_Direccion_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_guardarDireccion;
        private System.Windows.Forms.Label lab_direccion;
        private System.Windows.Forms.TextBox txt_direccion;
    }
}