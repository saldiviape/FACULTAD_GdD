﻿namespace PalcoNet.Editar_Publicacion
{
    partial class Modificar_Grado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_modifGrado = new System.Windows.Forms.Button();
            this.lab_grado = new System.Windows.Forms.Label();
            this.cmb_modifGrado = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btn_modifGrado
            // 
            this.btn_modifGrado.Location = new System.Drawing.Point(152, 64);
            this.btn_modifGrado.Name = "btn_modifGrado";
            this.btn_modifGrado.Size = new System.Drawing.Size(203, 40);
            this.btn_modifGrado.TabIndex = 11;
            this.btn_modifGrado.Text = "Modificar Grado";
            this.btn_modifGrado.UseVisualStyleBackColor = true;
            this.btn_modifGrado.Click += new System.EventHandler(this.btn_modifGrado_Click);
            // 
            // lab_grado
            // 
            this.lab_grado.AutoSize = true;
            this.lab_grado.Location = new System.Drawing.Point(12, 24);
            this.lab_grado.Name = "lab_grado";
            this.lab_grado.Size = new System.Drawing.Size(180, 17);
            this.lab_grado.TabIndex = 10;
            this.lab_grado.Text = "Seleccione el nuevo grado:";
            // 
            // cmb_modifGrado
            // 
            this.cmb_modifGrado.FormattingEnabled = true;
            this.cmb_modifGrado.Location = new System.Drawing.Point(198, 21);
            this.cmb_modifGrado.Name = "cmb_modifGrado";
            this.cmb_modifGrado.Size = new System.Drawing.Size(285, 24);
            this.cmb_modifGrado.TabIndex = 9;
            // 
            // Modificar_Grado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 121);
            this.Controls.Add(this.btn_modifGrado);
            this.Controls.Add(this.lab_grado);
            this.Controls.Add(this.cmb_modifGrado);
            this.Name = "Modificar_Grado";
            this.Text = "Modificar Grado";
            this.Load += new System.EventHandler(this.Modificar_Grado_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_modifGrado;
        private System.Windows.Forms.Label lab_grado;
        private System.Windows.Forms.ComboBox cmb_modifGrado;
    }
}