﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Editar_Publicacion
{
    public partial class Modificar_Grado : Form
    {
        comandos cma = new comandos();
        string descripcionActual;
        string direccionActual;

        public Modificar_Grado(string descAct, string dirAct)
        {
            this.direccionActual = dirAct;
            this.descripcionActual = descAct;
            InitializeComponent();
        }

        private bool modifGrado()
        {
            try
            {
                string cmd = string.Format("EXEC DATEROS.modificacionGrado '{0}', '{1}', '{2}'", descripcionActual, direccionActual, cmb_modifGrado.SelectedValue.ToString());
                libreria.Utilidades.ejecutar(cmd);

                MessageBox.Show("Se ha modificado el grado de la publicacion");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_modifGrado_Click(object sender, EventArgs e)
        {
            this.modifGrado();
            this.Hide();
        }

        private void Modificar_Grado_Load(object sender, EventArgs e)
        {
            cma.cargarGrados(cmb_modifGrado);
        }
    }
}
