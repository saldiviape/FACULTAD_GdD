﻿namespace PalcoNet.Editar_Publicacion
{
    partial class Modificar_Rubro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_modifRubro = new System.Windows.Forms.Button();
            this.lab_rubro = new System.Windows.Forms.Label();
            this.cmb_modifRubro = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btn_modifRubro
            // 
            this.btn_modifRubro.Location = new System.Drawing.Point(158, 67);
            this.btn_modifRubro.Name = "btn_modifRubro";
            this.btn_modifRubro.Size = new System.Drawing.Size(203, 40);
            this.btn_modifRubro.TabIndex = 11;
            this.btn_modifRubro.Text = "Modificar Rubro";
            this.btn_modifRubro.UseVisualStyleBackColor = true;
            this.btn_modifRubro.Click += new System.EventHandler(this.btn_modifRubro_Click);
            // 
            // lab_rubro
            // 
            this.lab_rubro.AutoSize = true;
            this.lab_rubro.Location = new System.Drawing.Point(30, 27);
            this.lab_rubro.Name = "lab_rubro";
            this.lab_rubro.Size = new System.Drawing.Size(177, 17);
            this.lab_rubro.TabIndex = 10;
            this.lab_rubro.Text = "Seleccione el nuevo rubro:";
            // 
            // cmb_modifRubro
            // 
            this.cmb_modifRubro.FormattingEnabled = true;
            this.cmb_modifRubro.Location = new System.Drawing.Point(213, 24);
            this.cmb_modifRubro.Name = "cmb_modifRubro";
            this.cmb_modifRubro.Size = new System.Drawing.Size(285, 24);
            this.cmb_modifRubro.TabIndex = 9;
            // 
            // Modificar_Rubro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(522, 128);
            this.Controls.Add(this.btn_modifRubro);
            this.Controls.Add(this.lab_rubro);
            this.Controls.Add(this.cmb_modifRubro);
            this.Name = "Modificar_Rubro";
            this.Text = "Modificar Rubro";
            this.Load += new System.EventHandler(this.Modificar_Rubro_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_modifRubro;
        private System.Windows.Forms.Label lab_rubro;
        private System.Windows.Forms.ComboBox cmb_modifRubro;
    }
}