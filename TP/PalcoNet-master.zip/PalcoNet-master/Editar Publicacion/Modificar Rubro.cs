﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Editar_Publicacion
{
    public partial class Modificar_Rubro : Form
    {
        comandos cma = new comandos();
        string descripcionActual;
        string direccionActual;

        public Modificar_Rubro(string descAct, string dirAct)
        {
            this.direccionActual = dirAct;
            this.descripcionActual = descAct;
            InitializeComponent();
        }

        private bool modifRubro()
        {
            try
            {
                string cmd = string.Format("EXEC DATEROS.modificacionRubro '{0}', '{1}', '{2}'", descripcionActual, direccionActual, cmb_modifRubro.SelectedValue.ToString());
                libreria.Utilidades.ejecutar(cmd);

                MessageBox.Show("Se ha modificado el rubro de la publicacion");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_modifRubro_Click(object sender, EventArgs e)
        {
            this.modifRubro();
            this.Hide();
        }

        private void Modificar_Rubro_Load(object sender, EventArgs e)
        {
            cma.cargarRubros(cmb_modifRubro);
            cmb_modifRubro.DropDownStyle = ComboBoxStyle.DropDownList;
        }
    }
}
