﻿namespace PalcoNet.Editar_Publicacion
{
    partial class Modificar_Ubicaciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_quitarUbi = new System.Windows.Forms.Button();
            this.btn_agregarUbi = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_quitarUbi
            // 
            this.btn_quitarUbi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_quitarUbi.Location = new System.Drawing.Point(45, 105);
            this.btn_quitarUbi.Name = "btn_quitarUbi";
            this.btn_quitarUbi.Size = new System.Drawing.Size(276, 56);
            this.btn_quitarUbi.TabIndex = 7;
            this.btn_quitarUbi.Text = "Quitar Ubicacion";
            this.btn_quitarUbi.UseVisualStyleBackColor = true;
            this.btn_quitarUbi.Click += new System.EventHandler(this.btn_quitarUbi_Click);
            // 
            // btn_agregarUbi
            // 
            this.btn_agregarUbi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_agregarUbi.Location = new System.Drawing.Point(45, 32);
            this.btn_agregarUbi.Name = "btn_agregarUbi";
            this.btn_agregarUbi.Size = new System.Drawing.Size(276, 56);
            this.btn_agregarUbi.TabIndex = 6;
            this.btn_agregarUbi.Text = "Agregar Nueva Ubicacion";
            this.btn_agregarUbi.UseVisualStyleBackColor = true;
            this.btn_agregarUbi.Click += new System.EventHandler(this.btn_agregarUbi_Click);
            // 
            // Modificar_Ubicaciones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(363, 195);
            this.Controls.Add(this.btn_quitarUbi);
            this.Controls.Add(this.btn_agregarUbi);
            this.Name = "Modificar_Ubicaciones";
            this.Text = "Modificar Ubicaciones";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_quitarUbi;
        private System.Windows.Forms.Button btn_agregarUbi;
    }
}