﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Editar_Publicacion
{
    public partial class Modificar_Ubicaciones : Form
    {
        string descripcion;
        string direccion;

        public Modificar_Ubicaciones(string desc, string dir)
        {
            this.descripcion = desc;
            this.direccion = dir;
            InitializeComponent();
        }

        private void btn_agregarUbi_Click(object sender, EventArgs e)
        {
            Editar_Publicacion.Agregar_Ubicacion au = new Editar_Publicacion.Agregar_Ubicacion(descripcion, direccion);
            au.Show();
        }

        private void btn_quitarUbi_Click(object sender, EventArgs e)
        {
            Editar_Publicacion.Quitar_Ubicacion qu = new Editar_Publicacion.Quitar_Ubicacion(descripcion, direccion);
            qu.Show();
        }
    }
}
