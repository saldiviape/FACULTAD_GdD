﻿namespace PalcoNet.Editar_Publicacion
{
    partial class Modificar_Datos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_modifDescripcion = new System.Windows.Forms.Button();
            this.btn_modifDireccion = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_modifDescripcion
            // 
            this.btn_modifDescripcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_modifDescripcion.Location = new System.Drawing.Point(81, 23);
            this.btn_modifDescripcion.Margin = new System.Windows.Forms.Padding(4);
            this.btn_modifDescripcion.Name = "btn_modifDescripcion";
            this.btn_modifDescripcion.Size = new System.Drawing.Size(258, 43);
            this.btn_modifDescripcion.TabIndex = 39;
            this.btn_modifDescripcion.Text = "Modificar Descripcion";
            this.btn_modifDescripcion.UseVisualStyleBackColor = true;
            this.btn_modifDescripcion.Click += new System.EventHandler(this.btn_modifDescripcion_Click);
            // 
            // btn_modifDireccion
            // 
            this.btn_modifDireccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_modifDireccion.Location = new System.Drawing.Point(81, 79);
            this.btn_modifDireccion.Margin = new System.Windows.Forms.Padding(4);
            this.btn_modifDireccion.Name = "btn_modifDireccion";
            this.btn_modifDireccion.Size = new System.Drawing.Size(258, 43);
            this.btn_modifDireccion.TabIndex = 40;
            this.btn_modifDireccion.Text = "Modificar Direccion";
            this.btn_modifDireccion.UseVisualStyleBackColor = true;
            this.btn_modifDireccion.Click += new System.EventHandler(this.btn_modifDireccion_Click);
            // 
            // Modificar_Datos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(404, 153);
            this.Controls.Add(this.btn_modifDireccion);
            this.Controls.Add(this.btn_modifDescripcion);
            this.Name = "Modificar_Datos";
            this.Text = "Modificar Datos de Publicacion";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Modificar_Datos_FormClosed);
            this.Load += new System.EventHandler(this.Modificar_Datos_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_modifDescripcion;
        private System.Windows.Forms.Button btn_modifDireccion;
    }
}