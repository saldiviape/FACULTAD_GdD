﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Editar_Publicacion
{
    public partial class Modificar_Datos : Form
    {
        comandos cma = new comandos();
        string direccionActual;
        string descripcionActual;

        public Modificar_Datos(string descAct, string dirAct)
        {
            direccionActual = dirAct;
            descripcionActual = descAct;
            InitializeComponent();
        }

        private void btn_modifDescripcion_Click(object sender, EventArgs e)
        {
            Editar_Publicacion.Modificar_Descripcion md = new Editar_Publicacion.Modificar_Descripcion(descripcionActual, direccionActual);
            md.Show();
            this.Hide();
        }

        private void Modificar_Datos_Load(object sender, EventArgs e){}

        private void btn_modifDireccion_Click(object sender, EventArgs e)
        {
            Editar_Publicacion.Modificar_Direccion mdi = new Editar_Publicacion.Modificar_Direccion(descripcionActual, direccionActual);
            mdi.Show();
            this.Hide();
        }

        private void lab_descripcion_Click(object sender, EventArgs e){}

        private void txt_descripcion_TextChanged(object sender, EventArgs e){}

        private void Modificar_Datos_FormClosed(object sender, FormClosedEventArgs e)
        {
            MessageBox.Show("Realice nuevamente la busqueda para obtener los datos actualizados.");
        }
    }
}
