﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Editar_Publicacion
{
    public partial class Quitar_Funcion : Form
    {
        comandos cma = new comandos();
        string direccionActual;
        string descripcionActual;

        public Quitar_Funcion(string descAct, string dirAct)
        {
            descripcionActual = descAct;
            direccionActual = dirAct;
            InitializeComponent();
        }

        private bool quitarFuncion()
        {
            try
            {
                string cmd = string.Format("EXEC DATEROS.bajaFuncion '{0}', '{1}', '{2}'", descripcionActual, direccionActual, dataGridView1.CurrentRow.Cells[1].Value.ToString());
                libreria.Utilidades.ejecutar(cmd);

                MessageBox.Show("Se ha dado de baja la funcion");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_quitarFuncion_Click(object sender, EventArgs e)
        {
            this.quitarFuncion();
            this.Hide();
        }

        private void Quitar_Funcion_Load(object sender, EventArgs e)
        {
            cma.llenarDataGridView(dataGridView1, "SELECT f.idPublicacion, f.fechaHora FROM DATEROS.publicacion p, DATEROS.funcion f WHERE p.idPublicacion=f.idPublicacion AND descripcion='" + descripcionActual + "' AND direccion=  '" + direccionActual + "'");
        }
    }
}
