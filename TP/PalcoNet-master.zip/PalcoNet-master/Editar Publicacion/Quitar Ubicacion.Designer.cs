﻿namespace PalcoNet.Editar_Publicacion
{
    partial class Quitar_Ubicacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lab_quitarUbi = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btn_quitarUbicacion = new System.Windows.Forms.Button();
            this.btn_seleccionarFuncion = new System.Windows.Forms.Button();
            this.cmb_funcion = new System.Windows.Forms.ComboBox();
            this.lab_funcion = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lab_quitarUbi
            // 
            this.lab_quitarUbi.AutoSize = true;
            this.lab_quitarUbi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lab_quitarUbi.Location = new System.Drawing.Point(21, 76);
            this.lab_quitarUbi.Name = "lab_quitarUbi";
            this.lab_quitarUbi.Size = new System.Drawing.Size(324, 24);
            this.lab_quitarUbi.TabIndex = 136;
            this.lab_quitarUbi.Text = "Seleccione una ubicacion de la grilla:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(25, 104);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(926, 311);
            this.dataGridView1.TabIndex = 135;
            // 
            // btn_quitarUbicacion
            // 
            this.btn_quitarUbicacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_quitarUbicacion.Location = new System.Drawing.Point(321, 442);
            this.btn_quitarUbicacion.Name = "btn_quitarUbicacion";
            this.btn_quitarUbicacion.Size = new System.Drawing.Size(338, 56);
            this.btn_quitarUbicacion.TabIndex = 134;
            this.btn_quitarUbicacion.Text = "Quitar Ubicacion";
            this.btn_quitarUbicacion.UseVisualStyleBackColor = true;
            this.btn_quitarUbicacion.Click += new System.EventHandler(this.btn_quitarUbicacion_Click);
            // 
            // btn_seleccionarFuncion
            // 
            this.btn_seleccionarFuncion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_seleccionarFuncion.Location = new System.Drawing.Point(655, 16);
            this.btn_seleccionarFuncion.Margin = new System.Windows.Forms.Padding(4);
            this.btn_seleccionarFuncion.Name = "btn_seleccionarFuncion";
            this.btn_seleccionarFuncion.Size = new System.Drawing.Size(231, 42);
            this.btn_seleccionarFuncion.TabIndex = 145;
            this.btn_seleccionarFuncion.Text = "Seleccionar Funcion";
            this.btn_seleccionarFuncion.UseVisualStyleBackColor = true;
            this.btn_seleccionarFuncion.Click += new System.EventHandler(this.btn_seleccionarFuncion_Click);
            // 
            // cmb_funcion
            // 
            this.cmb_funcion.FormattingEnabled = true;
            this.cmb_funcion.Location = new System.Drawing.Point(301, 25);
            this.cmb_funcion.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmb_funcion.Name = "cmb_funcion";
            this.cmb_funcion.Size = new System.Drawing.Size(332, 24);
            this.cmb_funcion.TabIndex = 144;
            // 
            // lab_funcion
            // 
            this.lab_funcion.AutoSize = true;
            this.lab_funcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lab_funcion.Location = new System.Drawing.Point(21, 25);
            this.lab_funcion.Name = "lab_funcion";
            this.lab_funcion.Size = new System.Drawing.Size(273, 24);
            this.lab_funcion.TabIndex = 143;
            this.lab_funcion.Text = "Seleccione el dia de la funcion:";
            // 
            // Quitar_Ubicacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 517);
            this.Controls.Add(this.btn_seleccionarFuncion);
            this.Controls.Add(this.cmb_funcion);
            this.Controls.Add(this.lab_funcion);
            this.Controls.Add(this.lab_quitarUbi);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btn_quitarUbicacion);
            this.Name = "Quitar_Ubicacion";
            this.Text = "Quitar Ubicacion";
            this.Load += new System.EventHandler(this.Quitar_Ubicacion_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lab_quitarUbi;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btn_quitarUbicacion;
        private System.Windows.Forms.Button btn_seleccionarFuncion;
        private System.Windows.Forms.ComboBox cmb_funcion;
        private System.Windows.Forms.Label lab_funcion;
    }
}