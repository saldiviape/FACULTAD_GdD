﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PalcoNet.libreria;

namespace PalcoNet.Editar_Publicacion
{
    public partial class Quitar_Ubicacion : Form
    {
        comandos cma = new comandos();
        string descripcion;
        string direccion;

        public Quitar_Ubicacion(string desc, string dir)
        {
            this.descripcion = desc;
            this.direccion = dir;
            InitializeComponent();
        }

        private void Quitar_Ubicacion_Load(object sender, EventArgs e)
        {
            string consultaIdPublicacion = string.Format("SELECT idPublicacion FROM DATEROS.publicacion WHERE descripcion = '" + descripcion + "' AND direccion= '" + direccion + "'");
            DataSet dscl = Utilidades.ejecutar(consultaIdPublicacion);
            string idPublicacion = dscl.Tables[0].Rows[0]["idPublicacion"].ToString();

            cma.cargarFunciones(cmb_funcion, idPublicacion);
            cmb_funcion.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private bool quitarUbicacion()
        {
            try
            {
                string cmd = string.Format("EXEC DATEROS.bajaUbicacion '{0}', '{1}'", dataGridView1.CurrentRow.Cells[0].Value.ToString(), dataGridView1.CurrentRow.Cells[1].Value.ToString());
                libreria.Utilidades.ejecutar(cmd);

                MessageBox.Show("Se ha dado de baja la ubicacion");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_quitarUbicacion_Click(object sender, EventArgs e)
        {
            this.quitarUbicacion();
            this.Hide();
        }

        private void btn_seleccionarFuncion_Click(object sender, EventArgs e)
        {
            cma.llenarDataGridView(dataGridView1, "SELECT fu.idFuncion, fu.idUbicacion, tu.descripcion, fila, asiento, precio FROM DATEROS.ubicacion u, DATEROS.funcion_ubicacion fu, DATEROS.tipoUbicacion tu WHERE u.idUbicacion = fu.idUbicacion AND u.idTipoUbicacion = tu.idTipoUbicacion AND idFuncion= (SELECT DATEROS.dameidFuncion('" + Convert.ToDateTime(cmb_funcion.SelectedValue) + "', (SELECT DATEROS.dameidPublicacion('" + descripcion + "', '" + direccion + "'))))");
        }
    }
}
