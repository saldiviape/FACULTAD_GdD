﻿namespace PalcoNet.Generar_Publicacion
{
    partial class frm_asignarFechasYUbicaciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lab_consigna = new System.Windows.Forms.Label();
            this.grp_fechasHorarios = new System.Windows.Forms.GroupBox();
            this.btn_eliminarFuncion = new System.Windows.Forms.Button();
            this.btn_eliminarTodasLasFunciones = new System.Windows.Forms.Button();
            this.btn_agregarFunciones = new System.Windows.Forms.Button();
            this.lst_fechasHorarios = new System.Windows.Forms.ListBox();
            this.btn_cargarFuncionEnLaLista = new System.Windows.Forms.Button();
            this.dtp_fechaHorario = new System.Windows.Forms.DateTimePicker();
            this.btn_agregarUbicacion = new System.Windows.Forms.Button();
            this.btn_crearOtraPublicacion = new System.Windows.Forms.Button();
            this.grp_fechasHorarios.SuspendLayout();
            this.SuspendLayout();
            // 
            // lab_consigna
            // 
            this.lab_consigna.AutoSize = true;
            this.lab_consigna.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_consigna.Location = new System.Drawing.Point(29, 23);
            this.lab_consigna.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_consigna.Name = "lab_consigna";
            this.lab_consigna.Size = new System.Drawing.Size(726, 24);
            this.lab_consigna.TabIndex = 8;
            this.lab_consigna.Text = "Para crear una publicación, es necesario agregarles nuevas funciones y ubicacione" +
    "s:";
            this.lab_consigna.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // grp_fechasHorarios
            // 
            this.grp_fechasHorarios.Controls.Add(this.btn_eliminarFuncion);
            this.grp_fechasHorarios.Controls.Add(this.btn_eliminarTodasLasFunciones);
            this.grp_fechasHorarios.Controls.Add(this.btn_agregarFunciones);
            this.grp_fechasHorarios.Controls.Add(this.lst_fechasHorarios);
            this.grp_fechasHorarios.Controls.Add(this.btn_cargarFuncionEnLaLista);
            this.grp_fechasHorarios.Controls.Add(this.dtp_fechaHorario);
            this.grp_fechasHorarios.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grp_fechasHorarios.Location = new System.Drawing.Point(33, 63);
            this.grp_fechasHorarios.Margin = new System.Windows.Forms.Padding(4);
            this.grp_fechasHorarios.Name = "grp_fechasHorarios";
            this.grp_fechasHorarios.Padding = new System.Windows.Forms.Padding(4);
            this.grp_fechasHorarios.Size = new System.Drawing.Size(288, 384);
            this.grp_fechasHorarios.TabIndex = 9;
            this.grp_fechasHorarios.TabStop = false;
            this.grp_fechasHorarios.Text = "Asignación de Fechas-Horarios";
            // 
            // btn_eliminarFuncion
            // 
            this.btn_eliminarFuncion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eliminarFuncion.Location = new System.Drawing.Point(19, 258);
            this.btn_eliminarFuncion.Margin = new System.Windows.Forms.Padding(4);
            this.btn_eliminarFuncion.Name = "btn_eliminarFuncion";
            this.btn_eliminarFuncion.Size = new System.Drawing.Size(93, 53);
            this.btn_eliminarFuncion.TabIndex = 24;
            this.btn_eliminarFuncion.Text = "Eliminar función";
            this.btn_eliminarFuncion.UseVisualStyleBackColor = true;
            this.btn_eliminarFuncion.Click += new System.EventHandler(this.btn_eliminarFuncion_Click);
            // 
            // btn_eliminarTodasLasFunciones
            // 
            this.btn_eliminarTodasLasFunciones.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eliminarTodasLasFunciones.Location = new System.Drawing.Point(120, 258);
            this.btn_eliminarTodasLasFunciones.Margin = new System.Windows.Forms.Padding(4);
            this.btn_eliminarTodasLasFunciones.Name = "btn_eliminarTodasLasFunciones";
            this.btn_eliminarTodasLasFunciones.Size = new System.Drawing.Size(147, 53);
            this.btn_eliminarTodasLasFunciones.TabIndex = 23;
            this.btn_eliminarTodasLasFunciones.Text = "Eliminar todas las funciones";
            this.btn_eliminarTodasLasFunciones.UseVisualStyleBackColor = true;
            this.btn_eliminarTodasLasFunciones.Click += new System.EventHandler(this.btn_eliminarTodasLasFunciones_Click);
            // 
            // btn_agregarFunciones
            // 
            this.btn_agregarFunciones.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_agregarFunciones.Location = new System.Drawing.Point(19, 319);
            this.btn_agregarFunciones.Margin = new System.Windows.Forms.Padding(4);
            this.btn_agregarFunciones.Name = "btn_agregarFunciones";
            this.btn_agregarFunciones.Size = new System.Drawing.Size(248, 49);
            this.btn_agregarFunciones.TabIndex = 22;
            this.btn_agregarFunciones.Text = "Agregar Funciones";
            this.btn_agregarFunciones.UseVisualStyleBackColor = true;
            this.btn_agregarFunciones.Click += new System.EventHandler(this.btn_agregarFunciones_Click);
            // 
            // lst_fechasHorarios
            // 
            this.lst_fechasHorarios.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst_fechasHorarios.FormattingEnabled = true;
            this.lst_fechasHorarios.ItemHeight = 17;
            this.lst_fechasHorarios.Location = new System.Drawing.Point(19, 117);
            this.lst_fechasHorarios.Margin = new System.Windows.Forms.Padding(4);
            this.lst_fechasHorarios.Name = "lst_fechasHorarios";
            this.lst_fechasHorarios.Size = new System.Drawing.Size(247, 123);
            this.lst_fechasHorarios.TabIndex = 21;
            // 
            // btn_cargarFuncionEnLaLista
            // 
            this.btn_cargarFuncionEnLaLista.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cargarFuncionEnLaLista.Location = new System.Drawing.Point(19, 73);
            this.btn_cargarFuncionEnLaLista.Margin = new System.Windows.Forms.Padding(4);
            this.btn_cargarFuncionEnLaLista.Name = "btn_cargarFuncionEnLaLista";
            this.btn_cargarFuncionEnLaLista.Size = new System.Drawing.Size(248, 37);
            this.btn_cargarFuncionEnLaLista.TabIndex = 20;
            this.btn_cargarFuncionEnLaLista.Text = "Cargar Función en la lista";
            this.btn_cargarFuncionEnLaLista.UseVisualStyleBackColor = true;
            this.btn_cargarFuncionEnLaLista.Click += new System.EventHandler(this.btn_cargarFuncionEnLaLista_Click);
            // 
            // dtp_fechaHorario
            // 
            this.dtp_fechaHorario.CustomFormat = "yyyy/MM/dd HH:mm:ss";
            this.dtp_fechaHorario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_fechaHorario.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_fechaHorario.Location = new System.Drawing.Point(19, 36);
            this.dtp_fechaHorario.Margin = new System.Windows.Forms.Padding(4);
            this.dtp_fechaHorario.Name = "dtp_fechaHorario";
            this.dtp_fechaHorario.Size = new System.Drawing.Size(247, 29);
            this.dtp_fechaHorario.TabIndex = 0;
            this.dtp_fechaHorario.ValueChanged += new System.EventHandler(this.dtp_fechaHorario_ValueChanged);
            // 
            // btn_agregarUbicacion
            // 
            this.btn_agregarUbicacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_agregarUbicacion.Location = new System.Drawing.Point(397, 147);
            this.btn_agregarUbicacion.Margin = new System.Windows.Forms.Padding(4);
            this.btn_agregarUbicacion.Name = "btn_agregarUbicacion";
            this.btn_agregarUbicacion.Size = new System.Drawing.Size(268, 55);
            this.btn_agregarUbicacion.TabIndex = 23;
            this.btn_agregarUbicacion.Text = "Agregar Ubicaciones";
            this.btn_agregarUbicacion.UseVisualStyleBackColor = true;
            this.btn_agregarUbicacion.Click += new System.EventHandler(this.btn_agregarUbicacion_Click);
            // 
            // btn_crearOtraPublicacion
            // 
            this.btn_crearOtraPublicacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_crearOtraPublicacion.Location = new System.Drawing.Point(397, 239);
            this.btn_crearOtraPublicacion.Margin = new System.Windows.Forms.Padding(4);
            this.btn_crearOtraPublicacion.Name = "btn_crearOtraPublicacion";
            this.btn_crearOtraPublicacion.Size = new System.Drawing.Size(268, 55);
            this.btn_crearOtraPublicacion.TabIndex = 24;
            this.btn_crearOtraPublicacion.Text = "Crear Otra Publicación";
            this.btn_crearOtraPublicacion.UseVisualStyleBackColor = true;
            this.btn_crearOtraPublicacion.Click += new System.EventHandler(this.btn_crearOtraPublicacion_Click);
            // 
            // frm_asignarFechasYUbicaciones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(789, 476);
            this.Controls.Add(this.btn_crearOtraPublicacion);
            this.Controls.Add(this.grp_fechasHorarios);
            this.Controls.Add(this.btn_agregarUbicacion);
            this.Controls.Add(this.lab_consigna);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frm_asignarFechasYUbicaciones";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Asignar Fechas-Horarios y Ubicaciones a la Publicación Generada";
            this.Load += new System.EventHandler(this.frm_asignarFechasYUbicaciones_Load);
            this.grp_fechasHorarios.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lab_consigna;
        private System.Windows.Forms.GroupBox grp_fechasHorarios;
        private System.Windows.Forms.DateTimePicker dtp_fechaHorario;
        private System.Windows.Forms.Button btn_cargarFuncionEnLaLista;
        private System.Windows.Forms.ListBox lst_fechasHorarios;
        private System.Windows.Forms.Button btn_agregarFunciones;
        private System.Windows.Forms.Button btn_eliminarFuncion;
        private System.Windows.Forms.Button btn_eliminarTodasLasFunciones;
        private System.Windows.Forms.Button btn_agregarUbicacion;
        private System.Windows.Forms.Button btn_crearOtraPublicacion;
    }
}