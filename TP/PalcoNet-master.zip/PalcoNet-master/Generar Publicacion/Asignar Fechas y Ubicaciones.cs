﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Generar_Publicacion
{
    public partial class frm_asignarFechasYUbicaciones : Form
    {
        comandos cma = new comandos();
        string usuarioActual;
        string rolActual;
        string descripcion;
        string direccion;

        public frm_asignarFechasYUbicaciones(string u, string r, string dir, string desc)
        {
            this.usuarioActual = u;
            this.rolActual = r;
            this.descripcion = desc;
            this.direccion = dir;
            InitializeComponent();
        }

        private void btn_crearOtraPublicacion_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_generarPublicacion f = new frm_generarPublicacion(usuarioActual, rolActual);
            f.Show();
        }

        private void btn_volverAlMenuDeSeleccionDeFuncionalidad_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_seleccionDeFuncionalidad f = new frm_seleccionDeFuncionalidad(usuarioActual, rolActual);
            f.Show();
        }

        private bool agregarFuncion(DateTime item)
        {
            try
            {
                string agregarFuncion = string.Format("EXEC DATEROS.agregarFuncion '{0}', '{1}', '{2}', '{3}'", descripcion, direccion, Convert.ToDateTime(item.ToString()), Properties.Settings.Default.FechaDelSistema);
                libreria.Utilidades.ejecutar(agregarFuncion);

                MessageBox.Show("Se ha creado correctamente la funcion");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_eliminarFuncion_Click(object sender, EventArgs e)
        {
            lst_fechasHorarios.Items.Remove(lst_fechasHorarios.SelectedItem);
        }

        private void btn_cargarFuncionEnLaLista_Click(object sender, EventArgs e)
        {
            lst_fechasHorarios.Items.Add(Convert.ToDateTime(dtp_fechaHorario.Value.ToString()));
        }

        private void btn_eliminarTodasLasFunciones_Click(object sender, EventArgs e)
        {
            lst_fechasHorarios.Items.Clear();
        }

        private void btn_agregarFunciones_Click(object sender, EventArgs e)
        {
            foreach (DateTime item in lst_fechasHorarios.Items)
                this.agregarFuncion(item);
        }

        private void frm_asignarFechasYUbicaciones_Load(object sender, EventArgs e){}

        private void btn_agregarUbicacion_Click(object sender, EventArgs e)
        {
            Editar_Publicacion.Agregar_Ubicacion af = new Editar_Publicacion.Agregar_Ubicacion(descripcion, direccion);
            af.Show();
        }

        private void dtp_fechaHorario_ValueChanged(object sender, EventArgs e){}
    }
}
