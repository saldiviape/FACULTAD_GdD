﻿namespace PalcoNet.Generar_Publicacion
{
    partial class frm_generarPublicacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lab_descripcion = new System.Windows.Forms.Label();
            this.txt_descripcion = new System.Windows.Forms.TextBox();
            this.lab_direccion = new System.Windows.Forms.Label();
            this.txt_direccion = new System.Windows.Forms.TextBox();
            this.cmb_rubro = new System.Windows.Forms.ComboBox();
            this.cmb_grado = new System.Windows.Forms.ComboBox();
            this.cmb_estado = new System.Windows.Forms.ComboBox();
            this.lab_estado = new System.Windows.Forms.Label();
            this.lab_grado = new System.Windows.Forms.Label();
            this.lab_rubro = new System.Windows.Forms.Label();
            this.btn_generarPublicacion = new System.Windows.Forms.Button();
            this.btn_limpiarCampos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lab_descripcion
            // 
            this.lab_descripcion.AutoSize = true;
            this.lab_descripcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_descripcion.Location = new System.Drawing.Point(61, 42);
            this.lab_descripcion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_descripcion.Name = "lab_descripcion";
            this.lab_descripcion.Size = new System.Drawing.Size(115, 24);
            this.lab_descripcion.TabIndex = 7;
            this.lab_descripcion.Text = "Descripción:";
            this.lab_descripcion.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_descripcion
            // 
            this.txt_descripcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_descripcion.Location = new System.Drawing.Point(185, 38);
            this.txt_descripcion.Margin = new System.Windows.Forms.Padding(4);
            this.txt_descripcion.Name = "txt_descripcion";
            this.txt_descripcion.Size = new System.Drawing.Size(325, 29);
            this.txt_descripcion.TabIndex = 6;
            // 
            // lab_direccion
            // 
            this.lab_direccion.AutoSize = true;
            this.lab_direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_direccion.Location = new System.Drawing.Point(83, 79);
            this.lab_direccion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_direccion.Name = "lab_direccion";
            this.lab_direccion.Size = new System.Drawing.Size(95, 24);
            this.lab_direccion.TabIndex = 9;
            this.lab_direccion.Text = "Dirección:";
            this.lab_direccion.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_direccion
            // 
            this.txt_direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_direccion.Location = new System.Drawing.Point(185, 75);
            this.txt_direccion.Margin = new System.Windows.Forms.Padding(4);
            this.txt_direccion.Name = "txt_direccion";
            this.txt_direccion.Size = new System.Drawing.Size(325, 29);
            this.txt_direccion.TabIndex = 8;
            // 
            // cmb_rubro
            // 
            this.cmb_rubro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_rubro.FormattingEnabled = true;
            this.cmb_rubro.Location = new System.Drawing.Point(185, 112);
            this.cmb_rubro.Margin = new System.Windows.Forms.Padding(4);
            this.cmb_rubro.Name = "cmb_rubro";
            this.cmb_rubro.Size = new System.Drawing.Size(325, 32);
            this.cmb_rubro.TabIndex = 12;
            // 
            // cmb_grado
            // 
            this.cmb_grado.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_grado.FormattingEnabled = true;
            this.cmb_grado.Location = new System.Drawing.Point(185, 151);
            this.cmb_grado.Margin = new System.Windows.Forms.Padding(4);
            this.cmb_grado.Name = "cmb_grado";
            this.cmb_grado.Size = new System.Drawing.Size(325, 32);
            this.cmb_grado.TabIndex = 13;
            // 
            // cmb_estado
            // 
            this.cmb_estado.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_estado.FormattingEnabled = true;
            this.cmb_estado.Location = new System.Drawing.Point(185, 191);
            this.cmb_estado.Margin = new System.Windows.Forms.Padding(4);
            this.cmb_estado.Name = "cmb_estado";
            this.cmb_estado.Size = new System.Drawing.Size(325, 32);
            this.cmb_estado.TabIndex = 14;
            // 
            // lab_estado
            // 
            this.lab_estado.AutoSize = true;
            this.lab_estado.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_estado.Location = new System.Drawing.Point(104, 194);
            this.lab_estado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_estado.Name = "lab_estado";
            this.lab_estado.Size = new System.Drawing.Size(73, 24);
            this.lab_estado.TabIndex = 17;
            this.lab_estado.Text = "Estado:";
            this.lab_estado.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lab_grado
            // 
            this.lab_grado.AutoSize = true;
            this.lab_grado.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_grado.Location = new System.Drawing.Point(111, 155);
            this.lab_grado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_grado.Name = "lab_grado";
            this.lab_grado.Size = new System.Drawing.Size(67, 24);
            this.lab_grado.TabIndex = 16;
            this.lab_grado.Text = "Grado:";
            this.lab_grado.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lab_rubro
            // 
            this.lab_rubro.AutoSize = true;
            this.lab_rubro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_rubro.Location = new System.Drawing.Point(112, 116);
            this.lab_rubro.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_rubro.Name = "lab_rubro";
            this.lab_rubro.Size = new System.Drawing.Size(67, 24);
            this.lab_rubro.TabIndex = 15;
            this.lab_rubro.Text = "Rubro:";
            this.lab_rubro.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_generarPublicacion
            // 
            this.btn_generarPublicacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_generarPublicacion.Location = new System.Drawing.Point(283, 240);
            this.btn_generarPublicacion.Margin = new System.Windows.Forms.Padding(4);
            this.btn_generarPublicacion.Name = "btn_generarPublicacion";
            this.btn_generarPublicacion.Size = new System.Drawing.Size(229, 43);
            this.btn_generarPublicacion.TabIndex = 18;
            this.btn_generarPublicacion.Text = "Generar Publicación";
            this.btn_generarPublicacion.UseVisualStyleBackColor = true;
            this.btn_generarPublicacion.Click += new System.EventHandler(this.btn_generarPublicacion_Click);
            // 
            // btn_limpiarCampos
            // 
            this.btn_limpiarCampos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_limpiarCampos.Location = new System.Drawing.Point(45, 240);
            this.btn_limpiarCampos.Margin = new System.Windows.Forms.Padding(4);
            this.btn_limpiarCampos.Name = "btn_limpiarCampos";
            this.btn_limpiarCampos.Size = new System.Drawing.Size(229, 43);
            this.btn_limpiarCampos.TabIndex = 19;
            this.btn_limpiarCampos.Text = "Limpiar Campos";
            this.btn_limpiarCampos.UseVisualStyleBackColor = true;
            this.btn_limpiarCampos.Click += new System.EventHandler(this.btn_limpiarCampos_Click);
            // 
            // frm_generarPublicacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(564, 313);
            this.Controls.Add(this.btn_limpiarCampos);
            this.Controls.Add(this.btn_generarPublicacion);
            this.Controls.Add(this.lab_estado);
            this.Controls.Add(this.lab_grado);
            this.Controls.Add(this.lab_rubro);
            this.Controls.Add(this.cmb_estado);
            this.Controls.Add(this.cmb_grado);
            this.Controls.Add(this.cmb_rubro);
            this.Controls.Add(this.lab_direccion);
            this.Controls.Add(this.txt_direccion);
            this.Controls.Add(this.lab_descripcion);
            this.Controls.Add(this.txt_descripcion);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frm_generarPublicacion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Generar Publicacion";
            this.Load += new System.EventHandler(this.frm_generarPublicacion_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lab_descripcion;
        private System.Windows.Forms.TextBox txt_descripcion;
        private System.Windows.Forms.Label lab_direccion;
        private System.Windows.Forms.TextBox txt_direccion;
        private System.Windows.Forms.ComboBox cmb_rubro;
        private System.Windows.Forms.ComboBox cmb_grado;
        private System.Windows.Forms.ComboBox cmb_estado;
        private System.Windows.Forms.Label lab_estado;
        private System.Windows.Forms.Label lab_grado;
        private System.Windows.Forms.Label lab_rubro;
        private System.Windows.Forms.Button btn_generarPublicacion;
        private System.Windows.Forms.Button btn_limpiarCampos;
    }
}