﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PalcoNet.libreria;

namespace PalcoNet.Generar_Publicacion
{
    public partial class frm_generarPublicacion : Form
    {
        comandos cma = new comandos();

        string usuarioActual;
        string rolActual;

        public frm_generarPublicacion(string u, string r)
        {
            this.usuarioActual = u;
            this.rolActual = r;
            InitializeComponent();
        }

        private void btn_generarPublicacion_Click(object sender, EventArgs e)
        {
            string consultaExistenciaPublicacion = string.Format("IF EXISTS (SELECT * FROM DATEROS.publicacion WHERE descripcion = '" + txt_descripcion.Text + "' AND direccion = '" + txt_direccion.Text + "') BEGIN SELECT distinct 'ya existe' as 'resultado' FROM DATEROS.publicacion END ELSE BEGIN SELECT distinct 'no existe' as 'resultado' FROM DATEROS.publicacion END");
            DataSet dscEP = Utilidades.ejecutar(consultaExistenciaPublicacion);
            string BD_resultado = dscEP.Tables[0].Rows[0]["resultado"].ToString();
            if (BD_resultado == "ya existe")
            {
                MessageBox.Show("La publicación ya existe.\nNo puede crearse una publicación con los mismos datos que una ya existente");
            }
            else if (BD_resultado == "no existe")
            {
                this.Hide();
                this.generarPublicacion();
                frm_asignarFechasYUbicaciones f = new frm_asignarFechasYUbicaciones(usuarioActual, rolActual, txt_direccion.Text.Trim(), txt_descripcion.Text.Trim());
                f.Show();
            }
        }

        private void frm_generarPublicacion_Load(object sender, EventArgs e)
        {
            cma.cargarGrados(cmb_grado);
            cma.cargarRubros(cmb_rubro);
            cma.cargarEstados(cmb_estado);
            cmb_grado.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_rubro.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_estado.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void btn_limpiarCampos_Click(object sender, EventArgs e)
        {
            Limpiar limpiar = new Limpiar();
            limpiar.limpiarCampos(this);
        }

        private bool generarPublicacion()
        {
            try
            {
                string generarPubli = string.Format("EXEC DATEROS.generarPublicacion '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}'", txt_descripcion.Text.Trim(), txt_direccion.Text.Trim(), cmb_rubro.SelectedValue.ToString(), cmb_grado.SelectedValue.ToString(), cmb_estado.SelectedValue.ToString(), Properties.Settings.Default.FechaDelSistema, usuarioActual);
                libreria.Utilidades.ejecutar(generarPubli);

                MessageBox.Show("Se ha creado correctamente la publicacion");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }
    }
}