﻿namespace PalcoNet.Generar_Rendicion_Comisiones
{
    partial class frm_generarPagoDeComisiones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_empresa = new System.Windows.Forms.Label();
            this.cb_empresas = new System.Windows.Forms.ComboBox();
            this.lbl_cantidad = new System.Windows.Forms.Label();
            this.txt_cantidad = new System.Windows.Forms.TextBox();
            this.btn_rendir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_empresa
            // 
            this.lbl_empresa.AutoSize = true;
            this.lbl_empresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empresa.Location = new System.Drawing.Point(30, 30);
            this.lbl_empresa.Name = "lbl_empresa";
            this.lbl_empresa.Size = new System.Drawing.Size(100, 30);
            this.lbl_empresa.TabIndex = 0;
            this.lbl_empresa.Text = "Empresa";
            // 
            // cb_empresas
            // 
            this.cb_empresas.AutoSize = true;
            this.cb_empresas.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_empresas.Location = new System.Drawing.Point(125, 25);
            this.cb_empresas.Name = "cb_empresas";
            this.cb_empresas.Size = new System.Drawing.Size(199, 30);
            this.cb_empresas.TabIndex = 0;
            this.cb_empresas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            // 
            // lbl_cantidad
            // 
            this.lbl_cantidad.AutoSize = true;
            this.lbl_cantidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cantidad.Location = new System.Drawing.Point(30, 100);
            this.lbl_cantidad.Name = "lbl_cantidad";
            this.lbl_cantidad.Size = new System.Drawing.Size(100, 30);
            this.lbl_cantidad.TabIndex = 0;
            this.lbl_cantidad.Text = "Cantidad";
            // 
            // txt_cantidad
            // 
            this.txt_cantidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_cantidad.Location = new System.Drawing.Point(125, 100);
            this.txt_cantidad.Margin = new System.Windows.Forms.Padding(4);
            this.txt_cantidad.Name = "txt_cantidad";
            this.txt_cantidad.Size = new System.Drawing.Size(151, 30);
            this.txt_cantidad.TabIndex = 311;
            // 
            // btn_rendir
            // 
            this.btn_rendir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_rendir.Location = new System.Drawing.Point(100, 246);
            this.btn_rendir.Margin = new System.Windows.Forms.Padding(4);
            this.btn_rendir.Name = "btn_rendir";
            this.btn_rendir.Size = new System.Drawing.Size(235, 50);
            this.btn_rendir.TabIndex = 321;
            this.btn_rendir.Text = "Rendir comisiones";
            this.btn_rendir.UseVisualStyleBackColor = true;
            this.btn_rendir.Click += new System.EventHandler(this.btn_rendir_Click);
            // 
            // frm_generarPagoDeComisiones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(484, 461);
            this.MaximizeBox = false;
            this.Name = "frm_generarPagoDeComisiones";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Generar Pago de Comisiones";
            this.ResumeLayout(false);
            this.Controls.Add(this.lbl_empresa);
            this.Controls.Add(this.cb_empresas);
            this.Controls.Add(this.lbl_cantidad);
            this.Controls.Add(this.txt_cantidad);
            this.Controls.Add(this.btn_rendir);
        }

        #endregion

        private System.Windows.Forms.Label lbl_empresa;
        private System.Windows.Forms.ComboBox cb_empresas;
        private System.Windows.Forms.Label lbl_cantidad;
        private System.Windows.Forms.TextBox txt_cantidad;
        private System.Windows.Forms.Button btn_rendir;
    }
}