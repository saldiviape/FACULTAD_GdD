﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Generar_Rendicion_Comisiones
{
    public partial class frm_generarPagoDeComisiones : Form
    {
        comandos cma = new comandos();
        DataTable usernameDeEmpresas;
        string username;
        string idEmpresa;

        public frm_generarPagoDeComisiones()
        {
            InitializeComponent();
            DataTable tb = new DataTable();
            usernameDeEmpresas = cma.traerUsernameDeEmpresas();
            cb_empresas.ValueMember = usernameDeEmpresas.Columns[0].ToString();
            cb_empresas.DisplayMember = usernameDeEmpresas.Columns[0].ToString();
            cb_empresas.DataSource = usernameDeEmpresas;
        }

        public void frm_generarPagoDeComisiones_Load()
        {
        }

        private void rendicion()
        {
            string fecha = Properties.Settings.Default.FechaDelSistema.ToString();
            DataRowView drv = cb_empresas.SelectedItem as DataRowView;
            username = drv.Row["username"].ToString();
            idEmpresa = drv.Row["idEmpresa"].ToString();
            Dictionary<string, string> item_factura;
            List<Dictionary<string, string>> conjunto_items_factura = new List<Dictionary<string, string>>();
            Decimal total_recaudado = 0;
            Decimal total_a_pagar = 0;
            string cantidad_string = txt_cantidad.Text.Trim();
            int cantidad_compras_a_rendir = 0;
            string nroFactura;
            if (String.IsNullOrEmpty(cantidad_string) || (int.TryParse(cantidad_string, out cantidad_compras_a_rendir) && cantidad_compras_a_rendir > 0))
            {
                int cantidad_rendidas = 0;
                string ejecucionComprasDeEmpresa = string.Format("EXEC DATEROS.comprasDeEmpresa '{0}', '{1}'", username, fecha);
                DataSet comprasEmpresa = libreria.Utilidades.ejecutar(ejecucionComprasDeEmpresa);
                DataTable dt = comprasEmpresa.Tables[0];
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        item_factura = new Dictionary<string, string>();
                        string porcentaje = Convert.ToString(row["porcentaje"]);
                        string precio = Convert.ToString(row["precio"]);
                        Decimal monto_por_compra = Convert.ToDecimal(precio) * (1 - Convert.ToDecimal(porcentaje));
                        total_recaudado += Convert.ToDecimal(precio);
                        total_a_pagar += monto_por_compra;
                        string idCompra = Convert.ToString(row["idCompra"]);
                        string descripcionPublicacion = Convert.ToString(row["descripcion"]);
                        string fila = Convert.ToString(row["fila"]);
                        string asiento = Convert.ToString(row["asiento"]);
                        item_factura.Add("idCompra", idCompra);
                        string descripcion = string.Format("Publicacion: {0} - Fila: {1} - Asiento: {2}", descripcionPublicacion, fila, asiento);
                        item_factura.Add("descripcion", descripcion);
                        item_factura.Add("monto", Math.Truncate(monto_por_compra).ToString() + (monto_por_compra - Math.Truncate(monto_por_compra)).ToString().Substring(1).Replace(',', '.'));
                        cantidad_rendidas += 1;
                        conjunto_items_factura.Add(item_factura);
                        if (!String.IsNullOrEmpty(cantidad_string) && cantidad_rendidas == cantidad_compras_a_rendir)
                        {
                            break;
                        }
                    }
                    string cmd = string.Format("EXEC DATEROS.altaFactura {0}, '{1}', {2}", idEmpresa, fecha, Math.Truncate(total_a_pagar).ToString() + (total_a_pagar - Math.Truncate(total_a_pagar)).ToString().Substring(1).Replace(',', '.'));
                    libreria.Utilidades.ejecutar(cmd);
                    nroFactura = cma.traerIdDeFactura(idEmpresa, fecha).Rows[0][0].ToString();
                    foreach (Dictionary<string, string> i_f in conjunto_items_factura)
                    {
                        cmd = string.Format("EXEC DATEROS.altaItemFactura {0}, {1}, '{2}', {3}", nroFactura, i_f["idCompra"], i_f["descripcion"], i_f["monto"]);
                        libreria.Utilidades.ejecutar(cmd);
                    }
                    MessageBox.Show(string.Format("Factura creada exitosamente.{0}Se rindieron {1} compras.", Environment.NewLine, cantidad_rendidas.ToString()));
                }
                else
                {
                    MessageBox.Show("No se encontraron compras sin rendir para la empresa especificada.");
                }
            }
            else
            {
                MessageBox.Show("El valor ingresado para la cantidad debe ser un número mayor a 0.");
            }
        }

        private void btn_rendir_Click(object sender, EventArgs e)
        {
            this.rendicion();
        }

    }
}
