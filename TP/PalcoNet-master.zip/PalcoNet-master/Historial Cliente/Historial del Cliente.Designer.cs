﻿namespace PalcoNet.Historial_Cliente
{
    partial class frm_historialDelCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_historial = new System.Windows.Forms.Label();
            this.dgv_historial = new System.Windows.Forms.DataGridView();
            this.btn_primera = new System.Windows.Forms.Button();
            this.btn_anterior = new System.Windows.Forms.Button();
            this.btn_siguiente = new System.Windows.Forms.Button();
            this.btn_ultima = new System.Windows.Forms.Button();
            this.lbl_paginaActual = new System.Windows.Forms.Label();
            this.lbl_separador = new System.Windows.Forms.Label();
            this.lbl_paginasTotales = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_historial)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_historial
            // 
            this.lbl_historial.AutoSize = true;
            this.lbl_historial.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_historial.Location = new System.Drawing.Point(284, 23);
            this.lbl_historial.Name = "lbl_historial";
            this.lbl_historial.Size = new System.Drawing.Size(299, 32);
            this.lbl_historial.TabIndex = 0;
            this.lbl_historial.Text = "Historial de Compras";
            // 
            // dgv_historial
            // 
            this.dgv_historial.AllowUserToAddRows = false;
            this.dgv_historial.AllowUserToDeleteRows = false;
            this.dgv_historial.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_historial.Location = new System.Drawing.Point(12, 87);
            this.dgv_historial.Name = "dgv_historial";
            this.dgv_historial.ReadOnly = true;
            this.dgv_historial.RowTemplate.Height = 34;
            this.dgv_historial.Size = new System.Drawing.Size(858, 583);
            this.dgv_historial.TabIndex = 1;
            // 
            // btn_primera
            // 
            this.btn_primera.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_primera.Location = new System.Drawing.Point(13, 706);
            this.btn_primera.Name = "btn_primera";
            this.btn_primera.Size = new System.Drawing.Size(125, 38);
            this.btn_primera.TabIndex = 2;
            this.btn_primera.Text = "Primera";
            this.btn_primera.UseVisualStyleBackColor = true;
            this.btn_primera.Click += new System.EventHandler(this.btn_primera_Click);
            // 
            // btn_anterior
            // 
            this.btn_anterior.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_anterior.Location = new System.Drawing.Point(179, 706);
            this.btn_anterior.Name = "btn_anterior";
            this.btn_anterior.Size = new System.Drawing.Size(125, 38);
            this.btn_anterior.TabIndex = 2;
            this.btn_anterior.Text = "Anterior";
            this.btn_anterior.UseVisualStyleBackColor = true;
            this.btn_anterior.Click += new System.EventHandler(this.btn_anterior_Click);
            // 
            // btn_siguiente
            // 
            this.btn_siguiente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_siguiente.Location = new System.Drawing.Point(583, 706);
            this.btn_siguiente.Name = "btn_siguiente";
            this.btn_siguiente.Size = new System.Drawing.Size(125, 38);
            this.btn_siguiente.TabIndex = 3;
            this.btn_siguiente.Text = "Siguiente";
            this.btn_siguiente.UseVisualStyleBackColor = true;
            this.btn_siguiente.Click += new System.EventHandler(this.btn_siguiente_Click);
            // 
            // btn_ultima
            // 
            this.btn_ultima.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ultima.Location = new System.Drawing.Point(748, 706);
            this.btn_ultima.Name = "btn_ultima";
            this.btn_ultima.Size = new System.Drawing.Size(125, 38);
            this.btn_ultima.TabIndex = 3;
            this.btn_ultima.Text = "Última";
            this.btn_ultima.UseVisualStyleBackColor = true;
            this.btn_ultima.Click += new System.EventHandler(this.btn_ultima_Click);
            // 
            // lbl_paginaActual
            // 
            this.lbl_paginaActual.AutoSize = true;
            this.lbl_paginaActual.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_paginaActual.Location = new System.Drawing.Point(395, 715);
            this.lbl_paginaActual.Name = "lbl_paginaActual";
            this.lbl_paginaActual.Size = new System.Drawing.Size(16, 18);
            this.lbl_paginaActual.TabIndex = 4;
            this.lbl_paginaActual.Text = "1";
            // 
            // lbl_separador
            // 
            this.lbl_separador.AutoSize = true;
            this.lbl_separador.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_separador.Location = new System.Drawing.Point(439, 715);
            this.lbl_separador.Name = "lbl_separador";
            this.lbl_separador.Size = new System.Drawing.Size(12, 18);
            this.lbl_separador.TabIndex = 5;
            this.lbl_separador.Text = "/";
            // 
            // lbl_paginasTotales
            // 
            this.lbl_paginasTotales.AutoSize = true;
            this.lbl_paginasTotales.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_paginasTotales.Location = new System.Drawing.Point(449, 715);
            this.lbl_paginasTotales.Name = "lbl_paginasTotales";
            this.lbl_paginasTotales.Size = new System.Drawing.Size(16, 18);
            this.lbl_paginasTotales.TabIndex = 6;
            this.lbl_paginasTotales.Text = "1";
            // 
            // frm_historialDelCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(884, 766);
            this.Controls.Add(this.lbl_paginasTotales);
            this.Controls.Add(this.lbl_separador);
            this.Controls.Add(this.lbl_paginaActual);
            this.Controls.Add(this.btn_primera);
            this.Controls.Add(this.btn_anterior);
            this.Controls.Add(this.btn_siguiente);
            this.Controls.Add(this.btn_ultima);
            this.Controls.Add(this.dgv_historial);
            this.Controls.Add(this.lbl_historial);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frm_historialDelCliente";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Historial del Cliente";
            this.Load += new System.EventHandler(this.frm_historialDelCliente_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_historial)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_historial;
        private System.Windows.Forms.DataGridView dgv_historial;
        private System.Windows.Forms.Button btn_primera;
        private System.Windows.Forms.Button btn_anterior;
        private System.Windows.Forms.Button btn_siguiente;
        private System.Windows.Forms.Button btn_ultima;
        private System.Windows.Forms.Label lbl_paginaActual;
        private System.Windows.Forms.Label lbl_separador;
        private System.Windows.Forms.Label lbl_paginasTotales;
    }
}