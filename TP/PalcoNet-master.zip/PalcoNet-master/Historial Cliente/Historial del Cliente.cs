﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Historial_Cliente
{
    public partial class frm_historialDelCliente : Form
    {
        comandos cma = new comandos();
        string usuarioActual;
        string rolActual;
        int total_filas = 0;
        int total_paginas = 0;
        int max_filas_por_pagina = 20;
        int nro_pagina = 0;
        DataTable resultado_query;

        public frm_historialDelCliente(string usuarioActual, string rolActual)
        {
            InitializeComponent();
            this.usuarioActual = string.Format("'{0}'", usuarioActual);
            this.rolActual = rolActual;
        }
        
        private void btn_primera_Click(object sender, EventArgs e)
        {
            nro_pagina = 0;
            dgv_historial.DataSource = llenar_pagina();
            btn_anterior.Enabled = false;
            btn_siguiente.Enabled = true;
        }

        private void btn_anterior_Click(object sender, EventArgs e)
        {
            nro_pagina -= 1;
            dgv_historial.DataSource = llenar_pagina();
            if (nro_pagina == 0)
            {
                btn_anterior.Enabled = false;
            }
            else
            {
                btn_anterior.Enabled = true;
            }
            btn_siguiente.Enabled = true;
        }

        private void btn_siguiente_Click(object sender, EventArgs e)
        {
            nro_pagina += 1;
            dgv_historial.DataSource = llenar_pagina();
            if (nro_pagina == (total_paginas - 1))
            {
                btn_siguiente.Enabled = false;
            }
            else
            {
                btn_siguiente.Enabled = true;
            }
            btn_anterior.Enabled = true;
        }

        private void btn_ultima_Click(object sender, EventArgs e)
        {
            nro_pagina = total_paginas - 1;
            dgv_historial.DataSource = llenar_pagina();
            btn_anterior.Enabled = true;
            btn_siguiente.Enabled = false;
        }

        private void frm_historialDelCliente_Load(object sender, EventArgs e)
        {
            string where = " ";
            if (this.rolActual != "Administrativo")
            {
                string id_cliente = cma.consultaBasicaDeUnResultado(string.Format("select idCliente from DATEROS.clientes where username = {0}", this.usuarioActual));
                id_cliente = string.Format("'{0}'", id_cliente);
                where = string.Format(" where c.idCliente = {0} ", id_cliente);
            }
            string consulta = string.Format(@"select c.idCliente, p.descripcion, c.fecha, c.metodoDePago, c.puntaje 
                                                from DATEROS.compra c 
                                                    join DATEROS.compra_publicacion cp on c.idCompra = cp.idCompra 
	                                                join DATEROS.publicacion p on cp.idPublicacion = p.idPublicacion 
                                                {0}
                                                UNION
                                                select c.idCliente, p.descripcion, c.fecha, c.metodoDePago, c.puntaje 
                                                from DATEROS.compra c
	                                                join DATEROS.funcion_ubicacion fu on c.idCompra = fu.idCompra
	                                                join DATEROS.funcion f on fu.idFuncion = f.idFuncion
	                                                join DATEROS.publicacion p on p.idPublicacion = f.idPublicacion 
                                                {0}
                                                order by c.idCliente, c.fecha", where);
            resultado_query = cma.llenarDataGridView(dgv_historial, consulta);
            total_filas = resultado_query.Rows.Count;
            total_paginas = total_filas / max_filas_por_pagina + ((total_filas % max_filas_por_pagina > 0) ? 1 : 0);
            lbl_paginasTotales.Text = total_paginas.ToString();
            btn_anterior.Enabled = false;
            dgv_historial.DataSource = llenar_pagina();
        }

        private DataTable llenar_pagina()
        {
            try
            {
                lbl_paginaActual.Text = (nro_pagina + 1).ToString();
                return resultado_query.Select().Skip(max_filas_por_pagina * nro_pagina).Take(Math.Min(max_filas_por_pagina, total_filas)).CopyToDataTable();
            }
            catch
            {
                MessageBox.Show("No existen compras.");
                return new DataTable();
            }
        }
    }
}
