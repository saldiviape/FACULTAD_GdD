﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Listado_Estadistico
{
    public partial class frm_listadoEstadistico : Form
    {
        comandos cma = new comandos();
       
        public frm_listadoEstadistico()
        {
            InitializeComponent();
        }

        private void btn_obtenerListado_Click(object sender, EventArgs e)
        {
            if (cmb_listado.SelectedItem.ToString() == "Clientes con mayor cantidad de compras")
            {
                if (cmb_trimestre.SelectedItem.ToString() == "1) Enero-Febrero-Marzo")
                    cma.llenarDataGridView(dgv_listado, "SELECT TOP 5 idCliente, COUNT(idCliente) AS 'Cantidad De Compras' FROM DATEROS.compra WHERE MONTH(fecha) BETWEEN 1 AND 3 AND YEAR(fecha)='" + txt_año.Text + "' GROUP BY idCliente ORDER BY 2 DESC");
                if (cmb_trimestre.SelectedItem.ToString() == "2) Abril-Mayo-Junio")
                    cma.llenarDataGridView(dgv_listado, "SELECT TOP 5 idCliente, COUNT(idCliente) AS 'Cantidad De Compras' FROM DATEROS.compra WHERE MONTH(fecha) BETWEEN 4 AND 6 AND YEAR(fecha)='" + txt_año.Text + "' GROUP BY idCliente ORDER BY 2 DESC");
                if (cmb_trimestre.SelectedItem.ToString() == "3) Julio-Agosto-Septiembre")
                    cma.llenarDataGridView(dgv_listado, "SELECT TOP 5 idCliente, COUNT(idCliente) AS 'Cantidad De Compras' FROM DATEROS.compra WHERE MONTH(fecha) BETWEEN 7 AND 9 AND YEAR(fecha)='" + txt_año.Text + "' GROUP BY idCliente ORDER BY 2 DESC");
                if (cmb_trimestre.SelectedItem.ToString() == "4) Octubre-Noviembre-Diciembre")
                    cma.llenarDataGridView(dgv_listado, "SELECT TOP 5 idCliente, COUNT(idCliente) AS 'Cantidad De Compras' FROM DATEROS.compra WHERE MONTH(fecha) BETWEEN 10 AND 12 AND YEAR(fecha)='" + txt_año.Text + "' GROUP BY idCliente ORDER BY 2 DESC");
            }
            else
            {
                if (cmb_listado.SelectedItem.ToString() == "Empresas con mayor cantidad de localidades no vendidas")
                {
                    if (cmb_trimestre.SelectedItem.ToString() == "1) Enero-Febrero-Marzo")
                        cma.llenarDataGridView(dgv_listado, "SELECT TOP 5 idEmpresa, COUNT(vendido) AS 'Localidades No Vendidas' FROM DATEROS.empresas e, DATEROS.publicacion p, DATEROS.funcion f, DATEROS.funcion_ubicacion fu, DATEROS.usuario u WHERE e.username=u.username and u.username=p.username AND p.idPublicacion=f.idPublicacion AND f.idFuncion=fu.idFuncion AND vendido=0 AND MONTH(fechaHora) BETWEEN 1 AND 3 AND YEAR(fechaHora)= '" + txt_año.Text + "' GROUP BY idEmpresa ORDER BY 2 DESC");
                    if (cmb_trimestre.SelectedItem.ToString() == "2) Abril-Mayo-Junio")
                        cma.llenarDataGridView(dgv_listado, "SELECT TOP 5 idEmpresa, COUNT(vendido) AS 'Localidades No Vendidas' FROM DATEROS.empresas e, DATEROS.publicacion p, DATEROS.funcion f, DATEROS.funcion_ubicacion fu, DATEROS.usuario u WHERE e.username=u.username and u.username=p.username AND p.idPublicacion=f.idPublicacion AND f.idFuncion=fu.idFuncion AND vendido=0 AND MONTH(fechaHora) BETWEEN 4 AND 6 AND YEAR(fechaHora)= '" + txt_año.Text + "' GROUP BY idEmpresa ORDER BY 2 DESC");
                    if (cmb_trimestre.SelectedItem.ToString() == "3) Julio-Agosto-Septiembre")
                        cma.llenarDataGridView(dgv_listado, "SELECT TOP 5 idEmpresa, COUNT(vendido) AS 'Localidades No Vendidas' FROM DATEROS.empresas e, DATEROS.publicacion p, DATEROS.funcion f, DATEROS.funcion_ubicacion fu, DATEROS.usuario u WHERE e.username=u.username and u.username=p.username AND p.idPublicacion=f.idPublicacion AND f.idFuncion=fu.idFuncion AND vendido=0 AND MONTH(fechaHora) BETWEEN 7 AND 9 AND YEAR(fechaHora)= '" + txt_año.Text + "' GROUP BY idEmpresa ORDER BY 2 DESC");
                    if (cmb_trimestre.SelectedItem.ToString() == "4) Octubre-Noviembre-Diciembre")
                        cma.llenarDataGridView(dgv_listado, "SELECT TOP 5 idEmpresa, COUNT(vendido) AS 'Localidades No Vendidas' FROM DATEROS.empresas e, DATEROS.publicacion p, DATEROS.funcion f, DATEROS.funcion_ubicacion fu, DATEROS.usuario u WHERE e.username=u.username and u.username=p.username AND p.idPublicacion=f.idPublicacion AND f.idFuncion=fu.idFuncion AND vendido=0 AND MONTH(fechaHora) BETWEEN 10 AND 12 AND YEAR(fechaHora)= '" + txt_año.Text + "' GROUP BY idEmpresa ORDER BY 2 DESC");
                }
                else
                {
                    if (cmb_listado.SelectedItem.ToString() == "Clientes con mayores puntos vencidos")
                        if (cmb_trimestre.SelectedItem.ToString() == "1) Enero-Febrero-Marzo")
                            cma.llenarDataGridView(dgv_listado, "SELECT TOP 5 idCliente, SUM(puntos) AS 'Cantidad De Puntos Vencidos' FROM DATEROS.puntosTrimestralesClientes WHERE (anio < '" + txt_año.Text + "') GROUP BY idCliente ORDER BY 2 DESC");
                        if (cmb_trimestre.SelectedItem.ToString() == "2) Abril-Mayo-Junio")
                            cma.llenarDataGridView(dgv_listado, "SELECT TOP 5 idCliente, SUM(puntos) AS 'Cantidad De Puntos Vencidos' FROM DATEROS.puntosTrimestralesClientes WHERE (anio < '" + txt_año.Text + "') OR (anio = '" + txt_año.Text + "' AND trimestre < 2) GROUP BY idCliente ORDER BY 2 DESC");
                        if (cmb_trimestre.SelectedItem.ToString() == "3) Julio-Agosto-Septiembre")
                            cma.llenarDataGridView(dgv_listado, "SELECT TOP 5 idCliente, SUM(puntos) AS 'Cantidad De Puntos Vencidos' FROM DATEROS.puntosTrimestralesClientes WHERE (anio < '" + txt_año.Text + "') OR (anio = '" + txt_año.Text + "' AND trimestre < 3) GROUP BY idCliente ORDER BY 2 DESC");
                        if (cmb_trimestre.SelectedItem.ToString() == "4) Octubre-Noviembre-Diciembre")
                            cma.llenarDataGridView(dgv_listado, "SELECT TOP 5 idCliente, SUM(puntos) AS 'Cantidad De Puntos Vencidos' FROM DATEROS.puntosTrimestralesClientes WHERE (anio < '" + txt_año.Text + "') OR (anio = '" + txt_año.Text + "' AND trimestre < 4) GROUP BY idCliente ORDER BY 2 DESC");
                }
            }
        }

       private void dgv_listado_CellContentClick(object sender, DataGridViewCellEventArgs e){}

       private void frm_listadoEstadistico_Load(object sender, EventArgs e)
       {
           this.gradoTableAdapter.Fill(this.gD2C2018DataSet.grado);
           cmb_listado.DropDownStyle = ComboBoxStyle.DropDownList;
           cmb_trimestre.DropDownStyle = ComboBoxStyle.DropDownList;
       }

       private void cmb_listado_SelectedIndexChanged(object sender, EventArgs e){}
    }
}