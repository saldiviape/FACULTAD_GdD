Curso: k3522

Grupo: 60

Integrantes:
	Saldivia, Pablo Eduardo	- 140.568-8 - saldiviape@gmail.com
	Santos, Gastón			- 147.743-2
	Neagoe, Martín			- 143.741-0
	Digiorno, Christian		- 152.106-8
		