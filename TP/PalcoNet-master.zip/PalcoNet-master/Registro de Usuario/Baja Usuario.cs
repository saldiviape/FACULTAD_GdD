﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalcoNet.Registro_de_Usuario
{
    public partial class Baja_Usuario : Form
    {
        comandos cma = new comandos();

        public Baja_Usuario()
        {
            InitializeComponent();
        }

        private void btn_Limpiar_Click(object sender, EventArgs e)
        {
            Limpiar limpiar = new Limpiar();
            limpiar.limpiarCampos(this);
        }

        private void btn_Buscar_Click(object sender, EventArgs e)
        {
            if (chk_exacto_nom.CheckState.ToString() == "Checked")
                try
                {
                    cma.llenarDataGridView(dataGridView1, "SELECT username FROM DATEROS.usuario WHERE username='" + txt_nombre.Text + "'");
                }
                catch (Exception error)
                {
                    MessageBox.Show("Ha ocurrido un error: " + error.Message);
                }
            else
                try
                {
                    string nombre = txt_nombre.Text.ToString();
                    cma.llenarDataGridView(dataGridView1, "SELECT username FROM DATEROS.usuario WHERE username LIKE '" + txt_nombre.Text + "' + '%'");
                }
                catch (Exception error)
                {
                    MessageBox.Show("Ha ocurrido un error: " + error.Message);
                }
        }

        private bool bajaUsuario()
        {
            var CheckBoxList = this.Controls.OfType<CheckBox>().ToList();

            try
            {
                string bajaUsuario = string.Format("EXEC DATEROS.bajaUsuario '{0}'", dataGridView1.CurrentRow.Cells[0].Value.ToString());
                libreria.Utilidades.ejecutar(bajaUsuario);

                MessageBox.Show("El usuario ha sido dado de baja correctamente");
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void btn_baja_Click(object sender, EventArgs e)
        {
            this.bajaUsuario();
        }

        private void btn_modifPass_Click(object sender, EventArgs e)
        {
            Registro_de_Usuario.Modificacion_Password mp = new Registro_de_Usuario.Modificacion_Password(dataGridView1.CurrentRow.Cells[0].Value.ToString());
            mp.Show();
        }
    }
}
