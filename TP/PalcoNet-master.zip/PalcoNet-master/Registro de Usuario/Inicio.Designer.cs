﻿namespace PalcoNet.Registro_de_Usuario
{
    partial class Inicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_baja = new System.Windows.Forms.Button();
            this.btn_modificarPassword = new System.Windows.Forms.Button();
            this.lab_regDeUsuario = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_baja
            // 
            this.btn_baja.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_baja.Location = new System.Drawing.Point(116, 147);
            this.btn_baja.Margin = new System.Windows.Forms.Padding(4);
            this.btn_baja.Name = "btn_baja";
            this.btn_baja.Size = new System.Drawing.Size(235, 50);
            this.btn_baja.TabIndex = 102;
            this.btn_baja.Text = "Dar de Baja Usuario / Modificar Password";
            this.btn_baja.UseVisualStyleBackColor = true;
            this.btn_baja.Visible = false;
            this.btn_baja.Click += new System.EventHandler(this.btn_baja_Click);
            // 
            // btn_modificarPassword
            // 
            this.btn_modificarPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_modificarPassword.Location = new System.Drawing.Point(116, 89);
            this.btn_modificarPassword.Margin = new System.Windows.Forms.Padding(4);
            this.btn_modificarPassword.Name = "btn_modificarPassword";
            this.btn_modificarPassword.Size = new System.Drawing.Size(235, 50);
            this.btn_modificarPassword.TabIndex = 104;
            this.btn_modificarPassword.Text = "Modificar Password";
            this.btn_modificarPassword.UseVisualStyleBackColor = true;
            this.btn_modificarPassword.Visible = false;
            this.btn_modificarPassword.Click += new System.EventHandler(this.btn_modificarPassword_Click);
            // 
            // lab_regDeUsuario
            // 
            this.lab_regDeUsuario.AutoSize = true;
            this.lab_regDeUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_regDeUsuario.Location = new System.Drawing.Point(92, 16);
            this.lab_regDeUsuario.Name = "lab_regDeUsuario";
            this.lab_regDeUsuario.Size = new System.Drawing.Size(284, 32);
            this.lab_regDeUsuario.TabIndex = 105;
            this.lab_regDeUsuario.Text = "Registro de Usuario";
            // 
            // Inicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 235);
            this.Controls.Add(this.lab_regDeUsuario);
            this.Controls.Add(this.btn_modificarPassword);
            this.Controls.Add(this.btn_baja);
            this.Name = "Inicio";
            this.Text = "Inicio Registro De Usuario";
            this.Load += new System.EventHandler(this.Inicio_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_baja;
        private System.Windows.Forms.Button btn_modificarPassword;
        private System.Windows.Forms.Label lab_regDeUsuario;
    }
}