﻿namespace PalcoNet.Registro_de_Usuario
{
    partial class Modificacion_Password
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_nuevaContraseña = new System.Windows.Forms.Label();
            this.txt_nuevaContraseña = new System.Windows.Forms.TextBox();
            this.btn_confirmar = new System.Windows.Forms.Button();
            this.chk_mostrarContraseña = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // lbl_nuevaContraseña
            // 
            this.lbl_nuevaContraseña.AutoSize = true;
            this.lbl_nuevaContraseña.Location = new System.Drawing.Point(66, 31);
            this.lbl_nuevaContraseña.Name = "lbl_nuevaContraseña";
            this.lbl_nuevaContraseña.Size = new System.Drawing.Size(192, 17);
            this.lbl_nuevaContraseña.TabIndex = 0;
            this.lbl_nuevaContraseña.Text = "Ingrese la nueva contraseña:";
            // 
            // txt_nuevaContraseña
            // 
            this.txt_nuevaContraseña.Location = new System.Drawing.Point(264, 31);
            this.txt_nuevaContraseña.Name = "txt_nuevaContraseña";
            this.txt_nuevaContraseña.PasswordChar = '●';
            this.txt_nuevaContraseña.Size = new System.Drawing.Size(282, 22);
            this.txt_nuevaContraseña.TabIndex = 1;
            // 
            // btn_confirmar
            // 
            this.btn_confirmar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_confirmar.Location = new System.Drawing.Point(216, 108);
            this.btn_confirmar.Name = "btn_confirmar";
            this.btn_confirmar.Size = new System.Drawing.Size(151, 40);
            this.btn_confirmar.TabIndex = 2;
            this.btn_confirmar.Text = "Confirmar";
            this.btn_confirmar.UseVisualStyleBackColor = true;
            this.btn_confirmar.Click += new System.EventHandler(this.btn_confirmar_Click);
            // 
            // chk_mostrarContraseña
            // 
            this.chk_mostrarContraseña.AutoSize = true;
            this.chk_mostrarContraseña.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_mostrarContraseña.Location = new System.Drawing.Point(264, 60);
            this.chk_mostrarContraseña.Margin = new System.Windows.Forms.Padding(4);
            this.chk_mostrarContraseña.Name = "chk_mostrarContraseña";
            this.chk_mostrarContraseña.Size = new System.Drawing.Size(177, 24);
            this.chk_mostrarContraseña.TabIndex = 16;
            this.chk_mostrarContraseña.Text = "Mostrar contraseña";
            this.chk_mostrarContraseña.UseVisualStyleBackColor = true;
            this.chk_mostrarContraseña.CheckedChanged += new System.EventHandler(this.chk_mostrarContraseña_CheckedChanged);
            // 
            // Modificacion_Password
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(608, 160);
            this.Controls.Add(this.chk_mostrarContraseña);
            this.Controls.Add(this.btn_confirmar);
            this.Controls.Add(this.txt_nuevaContraseña);
            this.Controls.Add(this.lbl_nuevaContraseña);
            this.Name = "Modificacion_Password";
            this.Text = "Modificacion Password";
            this.Load += new System.EventHandler(this.Modificacion_Password_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_nuevaContraseña;
        private System.Windows.Forms.TextBox txt_nuevaContraseña;
        private System.Windows.Forms.Button btn_confirmar;
        private System.Windows.Forms.CheckBox chk_mostrarContraseña;
    }
}