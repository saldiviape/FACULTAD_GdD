﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PalcoNet.libreria;

namespace PalcoNet.Registro_de_Usuario
{
    public partial class Modificacion_Password : Form
    {
        string username;

        public Modificacion_Password(string usuario)
        {
            InitializeComponent();
            this.username = usuario;
        }

        private bool modifContraseña()
        {
            try
            {
                string nuevaContraseñaIngresada = txt_nuevaContraseña.Text;
                string updateContraseña = string.Format("UPDATE DATEROS.usuario SET password = HASHBYTES('SHA2_256','" + nuevaContraseñaIngresada + "') WHERE username = '" + username + "'");
                DataSet ds_updateContraseña = Utilidades.ejecutar(updateContraseña);
                MessageBox.Show("La nueva contraseña ha sido asignada correctamente");
                this.Close();
                return true;
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
                return false;
            }
        }

        private void Modificacion_Password_Load(object sender, EventArgs e)
        {
            this.Text = "Nueva contraseña para el usuario " + username;
        }

        private void btn_confirmar_Click(object sender, EventArgs e)
        {
            this.modifContraseña();
        }

        private void chk_mostrarContraseña_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_mostrarContraseña.Checked) txt_nuevaContraseña.PasswordChar = '\0';
            else txt_nuevaContraseña.PasswordChar = '●'; 
        }
    }
}
