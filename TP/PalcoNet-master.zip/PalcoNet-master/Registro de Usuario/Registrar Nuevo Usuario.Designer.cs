﻿namespace PalcoNet.Registro_de_Usuario
{
    partial class frm_registrarNuevoUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_registrarNuevoUsuario = new System.Windows.Forms.Button();
            this.chk_mostrarContraseña = new System.Windows.Forms.CheckBox();
            this.lab_contraseña = new System.Windows.Forms.Label();
            this.lab_usuario = new System.Windows.Forms.Label();
            this.txt_contraseña = new System.Windows.Forms.TextBox();
            this.txt_usuario = new System.Windows.Forms.TextBox();
            this.lab_rol = new System.Windows.Forms.Label();
            this.rad_cliente = new System.Windows.Forms.RadioButton();
            this.rad_empresa = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // btn_registrarNuevoUsuario
            // 
            this.btn_registrarNuevoUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_registrarNuevoUsuario.Location = new System.Drawing.Point(40, 186);
            this.btn_registrarNuevoUsuario.Name = "btn_registrarNuevoUsuario";
            this.btn_registrarNuevoUsuario.Size = new System.Drawing.Size(294, 35);
            this.btn_registrarNuevoUsuario.TabIndex = 20;
            this.btn_registrarNuevoUsuario.Text = "Registrar Nuevo Usuario";
            this.btn_registrarNuevoUsuario.UseVisualStyleBackColor = true;
            this.btn_registrarNuevoUsuario.Click += new System.EventHandler(this.btn_registrarNuevoUsuario_Click);
            // 
            // chk_mostrarContraseña
            // 
            this.chk_mostrarContraseña.AutoSize = true;
            this.chk_mostrarContraseña.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_mostrarContraseña.Location = new System.Drawing.Point(128, 94);
            this.chk_mostrarContraseña.Name = "chk_mostrarContraseña";
            this.chk_mostrarContraseña.Size = new System.Drawing.Size(142, 20);
            this.chk_mostrarContraseña.TabIndex = 17;
            this.chk_mostrarContraseña.Text = "Mostrar contraseña";
            this.chk_mostrarContraseña.UseVisualStyleBackColor = true;
            this.chk_mostrarContraseña.CheckedChanged += new System.EventHandler(this.chk_mostrarContraseña_CheckedChanged);
            // 
            // lab_contraseña
            // 
            this.lab_contraseña.AutoSize = true;
            this.lab_contraseña.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_contraseña.Location = new System.Drawing.Point(37, 68);
            this.lab_contraseña.Name = "lab_contraseña";
            this.lab_contraseña.Size = new System.Drawing.Size(89, 18);
            this.lab_contraseña.TabIndex = 19;
            this.lab_contraseña.Text = "Contraseña:";
            this.lab_contraseña.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lab_usuario
            // 
            this.lab_usuario.AutoSize = true;
            this.lab_usuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_usuario.Location = new System.Drawing.Point(62, 34);
            this.lab_usuario.Name = "lab_usuario";
            this.lab_usuario.Size = new System.Drawing.Size(64, 18);
            this.lab_usuario.TabIndex = 18;
            this.lab_usuario.Text = "Usuario:";
            this.lab_usuario.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_contraseña
            // 
            this.txt_contraseña.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_contraseña.Location = new System.Drawing.Point(128, 65);
            this.txt_contraseña.Name = "txt_contraseña";
            this.txt_contraseña.PasswordChar = '●';
            this.txt_contraseña.Size = new System.Drawing.Size(206, 24);
            this.txt_contraseña.TabIndex = 16;
            this.txt_contraseña.TextChanged += new System.EventHandler(this.txt_contraseña_TextChanged);
            // 
            // txt_usuario
            // 
            this.txt_usuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_usuario.Location = new System.Drawing.Point(128, 31);
            this.txt_usuario.Name = "txt_usuario";
            this.txt_usuario.Size = new System.Drawing.Size(206, 24);
            this.txt_usuario.TabIndex = 15;
            this.txt_usuario.TextChanged += new System.EventHandler(this.txt_usuario_TextChanged);
            // 
            // lab_rol
            // 
            this.lab_rol.AutoSize = true;
            this.lab_rol.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_rol.Location = new System.Drawing.Point(91, 125);
            this.lab_rol.Name = "lab_rol";
            this.lab_rol.Size = new System.Drawing.Size(35, 18);
            this.lab_rol.TabIndex = 21;
            this.lab_rol.Text = "Rol:";
            this.lab_rol.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // rad_cliente
            // 
            this.rad_cliente.AutoSize = true;
            this.rad_cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rad_cliente.Location = new System.Drawing.Point(132, 123);
            this.rad_cliente.Name = "rad_cliente";
            this.rad_cliente.Size = new System.Drawing.Size(71, 22);
            this.rad_cliente.TabIndex = 22;
            this.rad_cliente.Text = "Cliente";
            this.rad_cliente.UseVisualStyleBackColor = true;
            this.rad_cliente.CheckedChanged += new System.EventHandler(this.rad_cliente_CheckedChanged);
            // 
            // rad_empresa
            // 
            this.rad_empresa.AutoSize = true;
            this.rad_empresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rad_empresa.Location = new System.Drawing.Point(132, 147);
            this.rad_empresa.Name = "rad_empresa";
            this.rad_empresa.Size = new System.Drawing.Size(86, 22);
            this.rad_empresa.TabIndex = 23;
            this.rad_empresa.Text = "Empresa";
            this.rad_empresa.UseVisualStyleBackColor = true;
            this.rad_empresa.CheckedChanged += new System.EventHandler(this.rad_empresa_CheckedChanged);
            // 
            // frm_registrarNuevoUsuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(372, 249);
            this.Controls.Add(this.rad_empresa);
            this.Controls.Add(this.rad_cliente);
            this.Controls.Add(this.lab_rol);
            this.Controls.Add(this.btn_registrarNuevoUsuario);
            this.Controls.Add(this.chk_mostrarContraseña);
            this.Controls.Add(this.lab_contraseña);
            this.Controls.Add(this.lab_usuario);
            this.Controls.Add(this.txt_contraseña);
            this.Controls.Add(this.txt_usuario);
            this.MaximizeBox = false;
            this.Name = "frm_registrarNuevoUsuario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registrar Nuevo Usuario";
            this.Load += new System.EventHandler(this.frm_registrarNuevoUsuario_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_registrarNuevoUsuario;
        private System.Windows.Forms.CheckBox chk_mostrarContraseña;
        private System.Windows.Forms.Label lab_contraseña;
        private System.Windows.Forms.Label lab_usuario;
        private System.Windows.Forms.TextBox txt_contraseña;
        private System.Windows.Forms.TextBox txt_usuario;
        private System.Windows.Forms.Label lab_rol;
        private System.Windows.Forms.RadioButton rad_cliente;
        private System.Windows.Forms.RadioButton rad_empresa;
    }
}