﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PalcoNet.libreria;
using System.Windows.Forms;

namespace PalcoNet.Registro_de_Usuario
{
    public partial class frm_registrarNuevoUsuario : Form
    {
        public frm_registrarNuevoUsuario()
        {
            InitializeComponent();
        }

        private void txt_usuario_TextChanged(object sender, EventArgs e)
        {
            if (txt_usuario.Text != "\0")
            {
                lab_contraseña.Enabled = true;
                txt_contraseña.Enabled = true;
                chk_mostrarContraseña.Enabled = true;
            }
            if (string.IsNullOrEmpty(txt_usuario.Text))
            {
                lab_contraseña.Enabled = false;
                txt_contraseña.Enabled = false;
                chk_mostrarContraseña.Enabled = false;
            }
        }

        private void frm_registrarNuevoUsuario_Load(object sender, EventArgs e)
        {
            lab_contraseña.Enabled = false;
            txt_contraseña.Enabled = false;
            chk_mostrarContraseña.Enabled = false;
            lab_rol.Enabled = false;
            rad_cliente.Enabled = false;
            rad_empresa.Enabled = false;
            btn_registrarNuevoUsuario.Enabled = false;
        }

        private void txt_contraseña_TextChanged(object sender, EventArgs e)
        {
            if (txt_contraseña.Text != "\0")
            {
                lab_rol.Enabled = true;
                rad_cliente.Enabled = true;
                rad_empresa.Enabled = true;
            }
            if (string.IsNullOrEmpty(txt_contraseña.Text))
            {
                lab_rol.Enabled = false;
                rad_cliente.Enabled = false;
                rad_empresa.Enabled = false;
            }
        }

        private void chk_mostrarContraseña_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_mostrarContraseña.Checked) txt_contraseña.PasswordChar = '\0';
            else txt_contraseña.PasswordChar = '●';    
        }

        private void rad_cliente_CheckedChanged(object sender, EventArgs e)
        {
            btn_registrarNuevoUsuario.Enabled = false;
            if (rad_cliente.Checked == true & rad_empresa.Checked == false)
            {
                btn_registrarNuevoUsuario.Enabled = true;
            }
            if (rad_cliente.Checked == false & rad_empresa.Checked == true)
            {
                btn_registrarNuevoUsuario.Enabled = true;
            }
        }

        private void rad_empresa_CheckedChanged(object sender, EventArgs e)
        {
            btn_registrarNuevoUsuario.Enabled = false;
            if (rad_cliente.Checked == true & rad_empresa.Checked == false)
            {
                btn_registrarNuevoUsuario.Enabled = true;
            }
            if (rad_cliente.Checked == false & rad_empresa.Checked == true)
            {
                btn_registrarNuevoUsuario.Enabled = true;
            }
        }

        private void btn_registrarNuevoUsuario_Click(object sender, EventArgs e)
        {
            string usernameIngresado = txt_usuario.Text;
            string passwordIngresada = txt_contraseña.Text;

            try
            {
                string consultaExistenciaUsername = string.Format("IF EXISTS(SELECT username FROM DATEROS.usuario WHERE username= '" + usernameIngresado + "') BEGIN SELECT distinct 'ya existe' as 'resultado' FROM DATEROS.usuario END ELSE BEGIN SELECT distinct 'no existe' as 'resultado' FROM DATEROS.usuario END");
                DataSet dscEU = Utilidades.ejecutar(consultaExistenciaUsername);
                string BD_resultado = dscEU.Tables[0].Rows[0]["resultado"].ToString();
                if (BD_resultado == "ya existe")
                {
                    MessageBox.Show("Ya existe este nombre de usuario. Ingrese uno distinto.");
                }
                else if (BD_resultado == "no existe")
                {
                    string INSERT_sobre_tabla_usuario = string.Format("INSERT INTO DATEROS.usuario VALUES ('" + usernameIngresado + "', HASHBYTES('SHA2_256', '" + passwordIngresada + "'), 'Habilitado')");
                    DataSet ds_u = Utilidades.ejecutar(INSERT_sobre_tabla_usuario);

                    if (rad_cliente.Checked)
                    {
                        Abm_Cliente.Alta a = new Abm_Cliente.Alta(usernameIngresado, "Cliente");
                        a.Show();
                    }

                    if (rad_empresa.Checked)
                    {
                        Abm_Empresa_Espectaculo.Alta a = new Abm_Empresa_Espectaculo.Alta(usernameIngresado, "Empresa");
                        a.Show();
                    }
                }
            }

            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
            } 
            
            
        }
    }
}
