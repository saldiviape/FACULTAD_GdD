﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace PalcoNet
{
    class comandos
    {
        SqlConnection con = new SqlConnection("Data Source=localhost\\SQLSERVER2012;Initial Catalog=GD2C2018;Persist Security Info=True;User ID=gdEspectaculos2018;Password=gd2018");

        public void cargarRoles(ComboBox cmb_rol, string usuario)
        {
            con.Open();
            SqlCommand comando = new SqlCommand("SELECT DISTINCT ru.username, r.nombre FROM DATEROS.roles_usuario ru JOIN DATEROS.rol r ON (ru.idRol = r.idRol) WHERE ru.username = '" + usuario + "' AND r.idRol NOT IN (SELECT * FROM DATEROS.rolesInhabilitados)", con);

            SqlDataAdapter da = new SqlDataAdapter(comando);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();

            DataRow fila = dt.NewRow();
            fila["nombre"] = "Selecciona un rol";
            dt.Rows.InsertAt(fila, 0);

            cmb_rol.ValueMember = "ru.nombre";
            cmb_rol.DisplayMember = "nombre";
            cmb_rol.DataSource = dt;
        }

        public void cargarTodosLosRoles(ComboBox cbx_rol)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT DISTINCT nombre FROM DATEROS.rol", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();

            DataRow fila = dt.NewRow();
            fila["nombre"] = "Selecciona un rol";
            dt.Rows.InsertAt(fila, 0);

            cbx_rol.ValueMember = "nombre";
            cbx_rol.DisplayMember = "nombre";
            cbx_rol.DataSource = dt;
        }

        public void cargarFunciones(ComboBox cmb_funcion, string publicacion)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT DISTINCT CONVERT(DateTime, fechaHora) as fechaHora FROM DATEROS.funcion WHERE idPublicacion = '" + publicacion + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();

            cmb_funcion.ValueMember = "fechaHora";
            cmb_funcion.DisplayMember = "fechaHora";
            cmb_funcion.DataSource = dt;
        }

        public void cargarPremiosCanjeables(ComboBox cmb_premiosDisponibles, int pts)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT descripcion FROM DATEROS.premios WHERE puntosNecesarios <= " + pts + "", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            DataRow fila = dt.NewRow();
            //fila["descripcion"] = "";
            //dt.Rows.InsertAt(fila, 0);
            cmb_premiosDisponibles.ValueMember = "descripcion";
            cmb_premiosDisponibles.DisplayMember = "descripcion";
            cmb_premiosDisponibles.DataSource = dt;
        }

        public void cargarEstados(ComboBox cbx_estado)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT estado FROM DATEROS.estados", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();

            DataRow fila = dt.NewRow();
            fila["estado"] = "Selecciona un estado";
            dt.Rows.InsertAt(fila, 0);

            cbx_estado.ValueMember = "estado";
            cbx_estado.DisplayMember = "estado";
            cbx_estado.DataSource = dt;
        }

        public void cargarTiposUbicacion(ComboBox cbx_ubi)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT DISTINCT descripcion FROM DATEROS.tipoUbicacion", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();

            DataRow fila = dt.NewRow();
            fila["descripcion"] = "Selecciona un tipo de ubicacion";
            dt.Rows.InsertAt(fila, 0);

            cbx_ubi.ValueMember = "descripcion";
            cbx_ubi.DisplayMember = "descripcion";
            cbx_ubi.DataSource = dt;
        }

        public void cargarRubros(ComboBox cbx_rubro)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT descripcion FROM DATEROS.rubro", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();

            DataRow fila = dt.NewRow();
            fila["descripcion"] = "Selecciona un rubro";
            dt.Rows.InsertAt(fila, 0);

            cbx_rubro.ValueMember = "descripcion";
            cbx_rubro.DisplayMember = "descripcion";
            cbx_rubro.DataSource = dt;
        }

        public DataTable llenarDataGridView(DataGridView dgv, string consulta)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(consulta, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgv.DataSource = dt;
            con.Close();
            return dt;
        }

        public void mostrarTodasFuncionalidades(ComboBox combo)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT nombre FROM DATEROS.funcionalidad", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();

            DataRow fila = dt.NewRow();
            fila["nombre"] = "Selecciona una funcionalidad";
            dt.Rows.InsertAt(fila, 0);

            combo.ValueMember = "fn.nombre";
            combo.DisplayMember = "nombre";
            combo.DataSource = dt;
        }

        public void cargarFuncionalidadesRol(ComboBox combo, string rol)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT DISTINCT f.nombre FROM DATEROS.rol r, DATEROS.funcionalidad_rol rf, DATEROS.funcionalidad f WHERE rf.idFuncionalidad = f.idFuncionalidad AND r.idRol=rf.idRol AND r.idRol='" + rol + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();

            DataRow fila = dt.NewRow();
            fila["nombre"] = "Selecciona una funcionalidad";
            dt.Rows.InsertAt(fila, 0);

            combo.ValueMember = "f.nombre";
            combo.DisplayMember = "nombre";
            combo.DataSource = dt;
        }

        public void cargarGrados(ComboBox combo)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT DISTINCT prioridad FROM DATEROS.grado", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();

            DataRow fila = dt.NewRow();
            fila["prioridad"] = "Selecciona un grado";
            dt.Rows.InsertAt(fila, 0);

            combo.ValueMember = "prioridad";
            combo.DisplayMember = "prioridad";
            combo.DataSource = dt;
        }

        public void cargarGradosInhabilitados(ComboBox combo)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT DISTINCT prioridad FROM DATEROS.grado WHERE estado=0", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();

            DataRow fila = dt.NewRow();
            fila["prioridad"] = "Selecciona un grado";
            dt.Rows.InsertAt(fila, 0);

            combo.ValueMember = "prioridad";
            combo.DisplayMember = "prioridad";
            combo.DataSource = dt;
        }

        public void llenarTextBoxEmpresa(TextBox tb, string sentencia, string empresa)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM DATEROS.empresas WHERE razonSocial = '" + empresa + "'", con);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                tb.Text = dr[sentencia].ToString();
            }
            con.Close();
        }

        public void llenarTextBoxCliente(TextBox tb, string sentencia, string tipoDoc, string doc)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM DATEROS.clientes WHERE docTipo = '" + tipoDoc + "' AND docNum = '" + doc + "'", con);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                tb.Text = dr[sentencia].ToString();
            }
            con.Close();
        }

        public void llenarTextBoxPublicacion(TextBox tb, string sentencia, string descripcion, string direccion)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM DATEROS.publicacion WHERE descripcion = '" + descripcion + "' AND direccion = '" + direccion + "'", con);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                tb.Text = dr[sentencia].ToString();
            }
            con.Close();
        }

        public void llenarTextBoxTarjeta(TextBox tb, string sentencia, string tipoDoc, string doc)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM DATEROS.tarjeta WHERE nroTarjeta = (SELECT nroTarjeta FROM DATEROS.clientes WHERE docTipo = '" + tipoDoc + "' AND docNum = '" + doc + "')", con);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                tb.Text = dr[sentencia].ToString();
            }
            con.Close();
        }

        public void llenarDTPTarjeta(DateTimePicker dtp, string sentencia, string tipoDoc, string doc)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM DATEROS.tarjeta WHERE nroTarjeta = (SELECT nroTarjeta FROM DATEROS.clientes WHERE docTipo = '" + tipoDoc + "' AND docNum = '" + doc + "')", con);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                dtp.Text = dr[sentencia].ToString();
            }
            con.Close();
        }

        public void llenarDTPCliente(DateTimePicker dtp, string sentencia, string tipoDoc, string doc)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM DATEROS.clientes WHERE docTipo = '" + tipoDoc + "' AND docNum = '" + doc + "'", con);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                dtp.Text = dr[sentencia].ToString();
            }
            con.Close();
        }

        public string consultaBasicaDeUnResultado(string consulta)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(consulta, con);
            string resultado = (string)cmd.ExecuteScalar().ToString();
            con.Close();
            return resultado;
        }

	public DataTable traerUsernameDeEmpresas()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select username, idEmpresa from DATEROS.empresas", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            return dt;
        }

    public DataTable traerIdDeFactura(string idEmpresa, string fecha)
    {
        con.Open();
        string query = string.Format("SELECT TOP 1 nroFactura FROM DATEROS.factura WHERE idEmpresa = {0} and fecha = '{1}' ORDER BY nroFactura DESC", idEmpresa, fecha);
        SqlCommand cmd = new SqlCommand(query, con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        con.Close();
        return dt;
    }

    }
}
