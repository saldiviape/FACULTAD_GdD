﻿namespace PalcoNet
{
    partial class frm_seleccionDeRol
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lab_usuario = new System.Windows.Forms.Label();
            this.lab_rol = new System.Windows.Forms.Label();
            this.txt_usuario = new System.Windows.Forms.TextBox();
            this.cmb_rol = new System.Windows.Forms.ComboBox();
            this.btn_acceder = new System.Windows.Forms.Button();
            this.btn_volver = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lab_usuario
            // 
            this.lab_usuario.AutoSize = true;
            this.lab_usuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_usuario.Location = new System.Drawing.Point(29, 34);
            this.lab_usuario.Name = "lab_usuario";
            this.lab_usuario.Size = new System.Drawing.Size(64, 18);
            this.lab_usuario.TabIndex = 6;
            this.lab_usuario.Text = "Usuario:";
            this.lab_usuario.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lab_rol
            // 
            this.lab_rol.AutoSize = true;
            this.lab_rol.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_rol.Location = new System.Drawing.Point(58, 68);
            this.lab_rol.Name = "lab_rol";
            this.lab_rol.Size = new System.Drawing.Size(35, 18);
            this.lab_rol.TabIndex = 7;
            this.lab_rol.Text = "Rol:";
            this.lab_rol.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_usuario
            // 
            this.txt_usuario.Enabled = false;
            this.txt_usuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_usuario.Location = new System.Drawing.Point(95, 31);
            this.txt_usuario.Name = "txt_usuario";
            this.txt_usuario.Size = new System.Drawing.Size(206, 24);
            this.txt_usuario.TabIndex = 8;
            // 
            // cmb_rol
            // 
            this.cmb_rol.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_rol.FormattingEnabled = true;
            this.cmb_rol.Location = new System.Drawing.Point(95, 65);
            this.cmb_rol.Name = "cmb_rol";
            this.cmb_rol.Size = new System.Drawing.Size(206, 26);
            this.cmb_rol.TabIndex = 10;
            this.cmb_rol.Text = "Cliente";
            this.cmb_rol.SelectedIndexChanged += new System.EventHandler(this.cmb_rol_SelectedIndexChanged);
            // 
            // btn_acceder
            // 
            this.btn_acceder.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_acceder.Location = new System.Drawing.Point(208, 109);
            this.btn_acceder.Name = "btn_acceder";
            this.btn_acceder.Size = new System.Drawing.Size(93, 33);
            this.btn_acceder.TabIndex = 11;
            this.btn_acceder.Text = "Acceder";
            this.btn_acceder.UseVisualStyleBackColor = true;
            this.btn_acceder.Click += new System.EventHandler(this.btn_acceder_Click);
            // 
            // btn_volver
            // 
            this.btn_volver.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_volver.Location = new System.Drawing.Point(32, 109);
            this.btn_volver.Name = "btn_volver";
            this.btn_volver.Size = new System.Drawing.Size(93, 33);
            this.btn_volver.TabIndex = 12;
            this.btn_volver.Text = "Volver";
            this.btn_volver.UseVisualStyleBackColor = true;
            this.btn_volver.Click += new System.EventHandler(this.btn_volver_Click);
            // 
            // frm_seleccionDeRol
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(331, 167);
            this.Controls.Add(this.btn_volver);
            this.Controls.Add(this.btn_acceder);
            this.Controls.Add(this.cmb_rol);
            this.Controls.Add(this.txt_usuario);
            this.Controls.Add(this.lab_rol);
            this.Controls.Add(this.lab_usuario);
            this.MaximizeBox = false;
            this.Name = "frm_seleccionDeRol";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ingreso al Sistema - Selección de Rol";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frm_seleccionDeRol_FormClosed);
            this.Load += new System.EventHandler(this.frm_seleccionDeRol_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lab_usuario;
        private System.Windows.Forms.Label lab_rol;
        private System.Windows.Forms.TextBox txt_usuario;
        private System.Windows.Forms.ComboBox cmb_rol;
        private System.Windows.Forms.Button btn_acceder;
        private System.Windows.Forms.Button btn_volver;
    }
}