﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using PalcoNet.libreria;

namespace PalcoNet
{
    public partial class frm_seleccionDeRol : Form
    {
        string usuarioActual;
        string rolActual;
        comandos c = new comandos();
        
        public frm_seleccionDeRol(string us)
        {
            InitializeComponent();
            this.usuarioActual = us;
        }

        private void frm_seleccionDeRol_Load(object sender, EventArgs e)
        {
            txt_usuario.Text = usuarioActual;
            c.cargarRoles(cmb_rol, usuarioActual);
            btn_acceder.Enabled = false;
            cmb_rol.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void btn_volver_Click(object sender, EventArgs e)
        {
            this.Hide(); 
            frm_ingresoAlSistema f = new frm_ingresoAlSistema();
            f.Show();
        }

        private void cmb_rol_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.rolActual = cmb_rol.SelectedValue.ToString();
            if (cmb_rol.SelectedIndex != 0) //Si está seleccionado algún rol...
            {
                btn_acceder.Enabled = true;
            }
            else //Si no está seleccionado ningún rol...
            {
                btn_acceder.Enabled = false;
            }

        }

        private void btn_acceder_Click(object sender, EventArgs e)
        {
            this.rolActual = cmb_rol.SelectedValue.ToString();
            frm_seleccionDeFuncionalidad f = new frm_seleccionDeFuncionalidad(usuarioActual, rolActual);
            f.Show();
            this.Hide();
        }

        private void frm_seleccionDeRol_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
