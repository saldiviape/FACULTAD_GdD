﻿namespace PalcoNet
{
    partial class frm_ingresoAlSistema
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_usuario = new System.Windows.Forms.TextBox();
            this.txt_contraseña = new System.Windows.Forms.TextBox();
            this.lab_usuario = new System.Windows.Forms.Label();
            this.lab_contraseña = new System.Windows.Forms.Label();
            this.chk_mostrarContraseña = new System.Windows.Forms.CheckBox();
            this.btn_acceder = new System.Windows.Forms.Button();
            this.btn_nuevoUsuario = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_usuario
            // 
            this.txt_usuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_usuario.Location = new System.Drawing.Point(154, 33);
            this.txt_usuario.Margin = new System.Windows.Forms.Padding(4);
            this.txt_usuario.Name = "txt_usuario";
            this.txt_usuario.Size = new System.Drawing.Size(273, 29);
            this.txt_usuario.TabIndex = 0;
            this.txt_usuario.TextChanged += new System.EventHandler(this.txt_usuario_TextChanged);
            // 
            // txt_contraseña
            // 
            this.txt_contraseña.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_contraseña.Location = new System.Drawing.Point(154, 75);
            this.txt_contraseña.Margin = new System.Windows.Forms.Padding(4);
            this.txt_contraseña.Name = "txt_contraseña";
            this.txt_contraseña.PasswordChar = '●';
            this.txt_contraseña.Size = new System.Drawing.Size(273, 29);
            this.txt_contraseña.TabIndex = 1;
            this.txt_contraseña.TextChanged += new System.EventHandler(this.txt_contraseña_TextChanged);
            // 
            // lab_usuario
            // 
            this.lab_usuario.AutoSize = true;
            this.lab_usuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_usuario.Location = new System.Drawing.Point(66, 37);
            this.lab_usuario.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_usuario.Name = "lab_usuario";
            this.lab_usuario.Size = new System.Drawing.Size(79, 24);
            this.lab_usuario.TabIndex = 5;
            this.lab_usuario.Text = "Usuario:";
            this.lab_usuario.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lab_contraseña
            // 
            this.lab_contraseña.AutoSize = true;
            this.lab_contraseña.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_contraseña.Location = new System.Drawing.Point(33, 79);
            this.lab_contraseña.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_contraseña.Name = "lab_contraseña";
            this.lab_contraseña.Size = new System.Drawing.Size(111, 24);
            this.lab_contraseña.TabIndex = 6;
            this.lab_contraseña.Text = "Contraseña:";
            this.lab_contraseña.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // chk_mostrarContraseña
            // 
            this.chk_mostrarContraseña.AutoSize = true;
            this.chk_mostrarContraseña.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_mostrarContraseña.Location = new System.Drawing.Point(154, 111);
            this.chk_mostrarContraseña.Margin = new System.Windows.Forms.Padding(4);
            this.chk_mostrarContraseña.Name = "chk_mostrarContraseña";
            this.chk_mostrarContraseña.Size = new System.Drawing.Size(177, 24);
            this.chk_mostrarContraseña.TabIndex = 2;
            this.chk_mostrarContraseña.Text = "Mostrar contraseña";
            this.chk_mostrarContraseña.UseVisualStyleBackColor = true;
            this.chk_mostrarContraseña.CheckedChanged += new System.EventHandler(this.chk_mostrarContraseña_CheckedChanged);
            // 
            // btn_acceder
            // 
            this.btn_acceder.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_acceder.Location = new System.Drawing.Point(317, 158);
            this.btn_acceder.Margin = new System.Windows.Forms.Padding(4);
            this.btn_acceder.Name = "btn_acceder";
            this.btn_acceder.Size = new System.Drawing.Size(125, 39);
            this.btn_acceder.TabIndex = 13;
            this.btn_acceder.Text = "Acceder";
            this.btn_acceder.UseVisualStyleBackColor = true;
            this.btn_acceder.Click += new System.EventHandler(this.btn_acceder_Click);
            // 
            // btn_nuevoUsuario
            // 
            this.btn_nuevoUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_nuevoUsuario.Location = new System.Drawing.Point(20, 158);
            this.btn_nuevoUsuario.Name = "btn_nuevoUsuario";
            this.btn_nuevoUsuario.Size = new System.Drawing.Size(254, 39);
            this.btn_nuevoUsuario.TabIndex = 14;
            this.btn_nuevoUsuario.Text = "Registrar Nuevo Usuario";
            this.btn_nuevoUsuario.UseVisualStyleBackColor = true;
            this.btn_nuevoUsuario.Click += new System.EventHandler(this.btn_nuevoUsuario_Click);
            // 
            // frm_ingresoAlSistema
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(475, 216);
            this.Controls.Add(this.btn_nuevoUsuario);
            this.Controls.Add(this.btn_acceder);
            this.Controls.Add(this.chk_mostrarContraseña);
            this.Controls.Add(this.lab_contraseña);
            this.Controls.Add(this.lab_usuario);
            this.Controls.Add(this.txt_contraseña);
            this.Controls.Add(this.txt_usuario);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frm_ingresoAlSistema";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ingreso al Sistema";
            this.Load += new System.EventHandler(this.frm_ingresoAlSistema_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_usuario;
        private System.Windows.Forms.TextBox txt_contraseña;
        private System.Windows.Forms.Label lab_usuario;
        private System.Windows.Forms.Label lab_contraseña;
        private System.Windows.Forms.CheckBox chk_mostrarContraseña;
        private System.Windows.Forms.Button btn_acceder;
        private System.Windows.Forms.Button btn_nuevoUsuario;
    }
}

