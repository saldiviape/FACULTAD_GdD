﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using PalcoNet.libreria;
using System.Security.Cryptography;

namespace PalcoNet
{
    public partial class frm_ingresoAlSistema : Form
    {
        Int32 cantIngresosFallidos = 0;

        public frm_ingresoAlSistema()
        {
            InitializeComponent();
        }

        private void chk_mostrarContraseña_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_mostrarContraseña.Checked) txt_contraseña.PasswordChar = '\0';
            else txt_contraseña.PasswordChar = '●';            
        }

        private void btn_acceder_Click(object sender, EventArgs e)
        {
            string userIngresado = txt_usuario.Text;
            string passwordIngresada = txt_contraseña.Text;
            
            try
            {
                string consultaLogin = string.Format("SELECT username, CONVERT(VARCHAR(255), password, 1) 'passwordString', estado FROM DATEROS.usuario WHERE username = '" + userIngresado + "' AND estado IN ('Habilitado', 'Pausado')");
                DataSet dscl = Utilidades.ejecutar(consultaLogin);
                string BD_username = dscl.Tables[0].Rows[0]["username"].ToString();
                string BD_password = dscl.Tables[0].Rows[0]["passwordString"].ToString();
                string BD_estado = dscl.Tables[0].Rows[0]["estado"].ToString();
                
                //Para hashear la contraseña...
                SHA256CryptoServiceProvider provider = new SHA256CryptoServiceProvider();
                byte[] inputBytes2 = Encoding.UTF8.GetBytes(passwordIngresada);
                byte[] hashedBytes2 = provider.ComputeHash(inputBytes2);
                StringBuilder output = new StringBuilder();
                for (int i = 0; i < hashedBytes2.Length; i++) output.Append(hashedBytes2[i].ToString("x2").ToUpper());
                string passwordIngresadaHasheada = "0x" + output.ToString();
                
                if (BD_password == passwordIngresadaHasheada) //Si la contraseña es correcta, ...
                {
                    //MessageBox.Show("Has ingresado con éxito, " + BD_username + ". \nBienvenido al sistema.", "Bienvenido " + BD_username, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txt_usuario.Enabled = true;
                    cantIngresosFallidos = 0;
                    this.Hide();

                    string consultaCantRoles = string.Format("SELECT COUNT(username) 'cantRoles' FROM DATEROS.roles_usuario WHERE username = '" + userIngresado + "'");
                    DataSet dsccr = Utilidades.ejecutar(consultaCantRoles);
                    Int32 BD_cantRoles = Convert.ToInt32(dsccr.Tables[0].Rows[0]["cantRoles"]);

                    if (BD_estado == "Pausado")
                    {
                        frm_nuevaContraseñaParaEmpresaOCliente f = new frm_nuevaContraseñaParaEmpresaOCliente(BD_username, BD_cantRoles);
                        f.Show();
                        string updateEstadoHabilitado = string.Format("UPDATE DATEROS.usuario SET estado = 'Habilitado' WHERE username = '" + userIngresado + "'");
                        DataSet dsuei = Utilidades.ejecutar(updateEstadoHabilitado);
                    }
                    else {
                        if (BD_cantRoles == 1) //Si userIngresado tiene asignado solamente 1 rol...
                        {
                            //Entra directo al formulario de selección de funcionalidad
                            string consultaRol = string.Format("SELECT ru.username, r.nombre FROM DATEROS.roles_usuario ru JOIN DATEROS.rol r ON (ru.idRol = r.idRol) WHERE ru.username = '" + userIngresado + "' and r.idRol NOT IN (SELECT * FROM DATEROS.rolesInhabilitados)");
                            DataSet dscr = Utilidades.ejecutar(consultaRol);
                            string BD_rol = dscr.Tables[0].Rows[0]["nombre"].ToString();

                            frm_seleccionDeFuncionalidad sdf = new frm_seleccionDeFuncionalidad(BD_username, BD_rol);
                            sdf.Show();
                        }
                        else //Si userIngresado tiene asignado más de 1 rol...
                        {
                            //Primero debe elegir el rol... una vez elegido el rol, elegirá lo que quiere hacer (funcionalidad)
                            frm_seleccionDeRol sdr = new frm_seleccionDeRol(userIngresado);
                            sdr.Show();
                        }
                        }
                    }            
                else //Si la contraseña es incorrecta, ...
                {
                    txt_usuario.Enabled = false;
                    cantIngresosFallidos++; 
                    if (cantIngresosFallidos < 3)
                    {
                        MessageBox.Show("La contraseña que ha ingresado no es correcta. \nIngrese la contraseña nuevamente por favor.\n\nCantidad de ingresos fallidos: " + cantIngresosFallidos, "Contraseña incorrecta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else
                    {
                        //Se ejecuta la query para inhabilitar el usuario
                        string updateEstadoInhabilitado = string.Format("UPDATE DATEROS.usuario SET estado = 'Inhabilitado' WHERE username = '" + userIngresado + "'");
                        DataSet dsuei = Utilidades.ejecutar(updateEstadoInhabilitado);
                        //Y se informa con un mensaje lo ocurrido
                        MessageBox.Show("Ha alcanzado el límite de ingresos fallidos. \nEl usuario " + BD_username + " ha sido inhabilitado.", "Usuario " + BD_username + " inhabilitado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
            }
            catch (Exception error)
            {
                MessageBox.Show("El usuario que ha ingresado no es correcto o no posee roles habilitados. \nIngrese un usuario nuevamente por favor.", "Usuario incorrecto", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_usuario.Text = "\0";
                txt_contraseña.Text = "\0";
                txt_usuario.Focus();
            }
        }

        private void frm_ingresoAlSistema_Load(object sender, EventArgs e)
        {
            lab_contraseña.Enabled = false;
            txt_contraseña.Enabled = false;
            chk_mostrarContraseña.Enabled = false;
            btn_acceder.Enabled = false;
        }

        private void txt_usuario_TextChanged(object sender, EventArgs e)
        {
            if (txt_usuario.Text != "\0")
            {
                lab_contraseña.Enabled = true;
                txt_contraseña.Enabled = true;
                chk_mostrarContraseña.Enabled = true;
            }
            if (string.IsNullOrEmpty(txt_usuario.Text))
            {
                lab_contraseña.Enabled = false;
                txt_contraseña.Enabled = false;
                chk_mostrarContraseña.Enabled = false;
            }
        }

        private void txt_contraseña_TextChanged(object sender, EventArgs e)
        {
            if (txt_contraseña.Text != "\0")
            {
                btn_acceder.Enabled = true;
            }
            if (string.IsNullOrEmpty(txt_contraseña.Text))
            {
                btn_acceder.Enabled = false;
            }
        }

        private void btn_nuevoUsuario_Click(object sender, EventArgs e)
        {
            /*
            Registro_de_Usuario.frm_registroDeUsuario rdu = new Registro_de_Usuario.frm_registroDeUsuario();
            rdu.Show();
            */
            Registro_de_Usuario.frm_registrarNuevoUsuario rNU = new Registro_de_Usuario.frm_registrarNuevoUsuario();
            rNU.Show();
        }
    }
}