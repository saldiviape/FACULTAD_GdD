﻿namespace PalcoNet
{
    partial class frm_nuevaContraseñaParaEmpresaOCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_guardar = new System.Windows.Forms.Button();
            this.chk_mostrarContraseña = new System.Windows.Forms.CheckBox();
            this.lab_ingreseNuevaContraseña = new System.Windows.Forms.Label();
            this.txt_contraseña = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_guardar
            // 
            this.btn_guardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_guardar.Location = new System.Drawing.Point(464, 106);
            this.btn_guardar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_guardar.Name = "btn_guardar";
            this.btn_guardar.Size = new System.Drawing.Size(125, 39);
            this.btn_guardar.TabIndex = 17;
            this.btn_guardar.Text = "Guardar";
            this.btn_guardar.UseVisualStyleBackColor = true;
            this.btn_guardar.Click += new System.EventHandler(this.btn_guardar_Click);
            // 
            // chk_mostrarContraseña
            // 
            this.chk_mostrarContraseña.AutoSize = true;
            this.chk_mostrarContraseña.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_mostrarContraseña.Location = new System.Drawing.Point(315, 74);
            this.chk_mostrarContraseña.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chk_mostrarContraseña.Name = "chk_mostrarContraseña";
            this.chk_mostrarContraseña.Size = new System.Drawing.Size(177, 24);
            this.chk_mostrarContraseña.TabIndex = 15;
            this.chk_mostrarContraseña.Text = "Mostrar contraseña";
            this.chk_mostrarContraseña.UseVisualStyleBackColor = true;
            this.chk_mostrarContraseña.CheckedChanged += new System.EventHandler(this.chk_mostrarContraseña_CheckedChanged);
            // 
            // lab_ingreseNuevaContraseña
            // 
            this.lab_ingreseNuevaContraseña.AutoSize = true;
            this.lab_ingreseNuevaContraseña.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_ingreseNuevaContraseña.Location = new System.Drawing.Point(28, 42);
            this.lab_ingreseNuevaContraseña.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_ingreseNuevaContraseña.Name = "lab_ingreseNuevaContraseña";
            this.lab_ingreseNuevaContraseña.Size = new System.Drawing.Size(270, 24);
            this.lab_ingreseNuevaContraseña.TabIndex = 16;
            this.lab_ingreseNuevaContraseña.Text = "Ingrese una nueva contraseña:";
            this.lab_ingreseNuevaContraseña.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_contraseña
            // 
            this.txt_contraseña.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_contraseña.Location = new System.Drawing.Point(315, 38);
            this.txt_contraseña.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_contraseña.Name = "txt_contraseña";
            this.txt_contraseña.PasswordChar = '●';
            this.txt_contraseña.Size = new System.Drawing.Size(273, 29);
            this.txt_contraseña.TabIndex = 14;
            this.txt_contraseña.TextChanged += new System.EventHandler(this.txt_contraseña_TextChanged);
            // 
            // frm_nuevaContraseñaParaEmpresaOCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(621, 170);
            this.Controls.Add(this.btn_guardar);
            this.Controls.Add(this.chk_mostrarContraseña);
            this.Controls.Add(this.lab_ingreseNuevaContraseña);
            this.Controls.Add(this.txt_contraseña);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "frm_nuevaContraseñaParaEmpresaOCliente";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Nueva contraseña";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frm_nuevaContraseñaParaEmpresaOCliente_FormClosed);
            this.Load += new System.EventHandler(this.frm_nuevaContraseñaParaEmpresaOCliente_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_guardar;
        private System.Windows.Forms.CheckBox chk_mostrarContraseña;
        private System.Windows.Forms.Label lab_ingreseNuevaContraseña;
        private System.Windows.Forms.TextBox txt_contraseña;
    }
}