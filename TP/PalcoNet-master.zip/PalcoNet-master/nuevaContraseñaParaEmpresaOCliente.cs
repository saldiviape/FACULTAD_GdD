﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using PalcoNet.libreria;
using System.Security.Cryptography;

namespace PalcoNet
{
    public partial class frm_nuevaContraseñaParaEmpresaOCliente : Form
    {
        string userIngresado;
        int BD_cantRoles;

        public frm_nuevaContraseñaParaEmpresaOCliente(string u, int r)
        {
            this.userIngresado = u;
            this.BD_cantRoles = r;
            InitializeComponent();
        }

        private void frm_nuevaContraseñaParaEmpresaOCliente_Load(object sender, EventArgs e)
        {
            this.Text = "Nueva contraseña para el usuario " + userIngresado;
        }

        private void chk_mostrarContraseña_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_mostrarContraseña.Checked) txt_contraseña.PasswordChar = '\0';
            else txt_contraseña.PasswordChar = '●'; 
        }

        private void frm_nuevaContraseñaParaEmpresaOCliente_FormClosed(object sender, FormClosedEventArgs e){}

        private void btn_guardar_Click(object sender, EventArgs e)
        {
            try
            {
            string nuevaContraseñaIngresada = txt_contraseña.Text;
            string updateContraseña = string.Format("UPDATE DATEROS.usuario SET password = HASHBYTES('SHA2_256','" + nuevaContraseñaIngresada + "'),	estado = 'Habilitado' WHERE username = '" + userIngresado + "'");
            DataSet ds_updateContraseña = Utilidades.ejecutar(updateContraseña);
            this.Close();
            
                
                
            //Ahora debería mostrarse el formulario de seleccion de funcionalidad, no antes
            if (BD_cantRoles == 1) //Si userIngresado tiene asignado solamente 1 rol...
            {
                //Entra directo al formulario de selección de funcionalidad
                string consultaRol = string.Format("SELECT ru.username, r.nombre FROM DATEROS.roles_usuario ru JOIN DATEROS.rol r ON (ru.idRol = r.idRol) WHERE ru.username = '" + userIngresado + "'");
                DataSet dscr = Utilidades.ejecutar(consultaRol);
                string BD_rol = dscr.Tables[0].Rows[0]["nombre"].ToString();

                frm_seleccionDeFuncionalidad sdf = new frm_seleccionDeFuncionalidad(userIngresado, BD_rol);
                sdf.Show();
            }
            else //Si userIngresado tiene asignado más de 1 rol...
            {
                //Primero debe elegir el rol... una vez elegido el rol, elegirá lo que quiere hacer (funcionalidad)
                frm_seleccionDeRol sdr = new frm_seleccionDeRol(userIngresado);
                sdr.Show();
            }
            
            }
            catch (Exception error)
            {
                MessageBox.Show("Ha ocurrido un error: " + error.Message);
            }

        }

        private void txt_contraseña_TextChanged(object sender, EventArgs e)
        {

        }
    }
}