﻿namespace PalcoNet
{
    partial class frm_seleccionDeFuncionalidad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lab_usuario_rol = new System.Windows.Forms.Label();
            this.lab_seleccionFuncionalidad = new System.Windows.Forms.Label();
            this.cmb_seleccionFuncionalidad = new System.Windows.Forms.ComboBox();
            this.btn_acceder = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lab_usuario_rol
            // 
            this.lab_usuario_rol.AutoSize = true;
            this.lab_usuario_rol.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_usuario_rol.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lab_usuario_rol.Location = new System.Drawing.Point(35, 25);
            this.lab_usuario_rol.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_usuario_rol.Name = "lab_usuario_rol";
            this.lab_usuario_rol.Size = new System.Drawing.Size(207, 24);
            this.lab_usuario_rol.TabIndex = 13;
            this.lab_usuario_rol.Text = "Usuario: ___  ·  Rol: ___";
            // 
            // lab_seleccionFuncionalidad
            // 
            this.lab_seleccionFuncionalidad.AutoSize = true;
            this.lab_seleccionFuncionalidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lab_seleccionFuncionalidad.Location = new System.Drawing.Point(35, 65);
            this.lab_seleccionFuncionalidad.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lab_seleccionFuncionalidad.Name = "lab_seleccionFuncionalidad";
            this.lab_seleccionFuncionalidad.Size = new System.Drawing.Size(264, 24);
            this.lab_seleccionFuncionalidad.TabIndex = 119;
            this.lab_seleccionFuncionalidad.Text = "Seleccione una funcionalidad:";
            this.lab_seleccionFuncionalidad.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmb_seleccionFuncionalidad
            // 
            this.cmb_seleccionFuncionalidad.FormattingEnabled = true;
            this.cmb_seleccionFuncionalidad.Location = new System.Drawing.Point(320, 65);
            this.cmb_seleccionFuncionalidad.Name = "cmb_seleccionFuncionalidad";
            this.cmb_seleccionFuncionalidad.Size = new System.Drawing.Size(267, 24);
            this.cmb_seleccionFuncionalidad.TabIndex = 120;
            // 
            // btn_acceder
            // 
            this.btn_acceder.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_acceder.Location = new System.Drawing.Point(230, 111);
            this.btn_acceder.Margin = new System.Windows.Forms.Padding(4);
            this.btn_acceder.Name = "btn_acceder";
            this.btn_acceder.Size = new System.Drawing.Size(183, 53);
            this.btn_acceder.TabIndex = 121;
            this.btn_acceder.Text = "Acceder";
            this.btn_acceder.UseVisualStyleBackColor = true;
            this.btn_acceder.Click += new System.EventHandler(this.btn_acceder_Click);
            // 
            // frm_seleccionDeFuncionalidad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(641, 190);
            this.Controls.Add(this.btn_acceder);
            this.Controls.Add(this.cmb_seleccionFuncionalidad);
            this.Controls.Add(this.lab_seleccionFuncionalidad);
            this.Controls.Add(this.lab_usuario_rol);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "frm_seleccionDeFuncionalidad";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Selección de Funcionalidad";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frm_seleccionDeFuncionalidad_FormClosed);
            this.Load += new System.EventHandler(this.frm_seleccionDeFuncionalidad_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lab_usuario_rol;
        private System.Windows.Forms.Label lab_seleccionFuncionalidad;
        private System.Windows.Forms.ComboBox cmb_seleccionFuncionalidad;
        private System.Windows.Forms.Button btn_acceder;
    }
}