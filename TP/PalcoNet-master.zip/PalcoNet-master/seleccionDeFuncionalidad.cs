﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using PalcoNet.libreria;

namespace PalcoNet
{
    public partial class frm_seleccionDeFuncionalidad : Form
    {
        comandos cma = new comandos();
        string usuarioActual;
        string rolActual;
              
        public frm_seleccionDeFuncionalidad(string usuario, string rol)
        {
            InitializeComponent();
            this.usuarioActual = usuario;
            this.rolActual = rol;
        }

        private void frm_seleccionDeFuncionalidad_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void frm_seleccionDeFuncionalidad_Load(object sender, EventArgs e)
        {
            string consultaIdRol = string.Format("SELECT idRol FROM DATEROS.rol WHERE nombre = '" + rolActual + "'");
            DataSet dscr = Utilidades.ejecutar(consultaIdRol);
            string idRol = dscr.Tables[0].Rows[0]["idRol"].ToString();

            lab_usuario_rol.Text = usuarioActual + " (" + rolActual + ")";
            cma.cargarFuncionalidadesRol(cmb_seleccionFuncionalidad, idRol);
            cmb_seleccionFuncionalidad.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void btn_acceder_Click(object sender, EventArgs e)
        {
             switch (cmb_seleccionFuncionalidad.SelectedValue.ToString())
             {
                case "ABM de Rol":
                Abm_Rol.frm_abmRol rol = new Abm_Rol.frm_abmRol();
                rol.Show();
                break;
                
                case "Registro de Usuario":
                Registro_de_Usuario.Inicio rdu = new Registro_de_Usuario.Inicio(rolActual, usuarioActual);
                rdu.Show();
                break;

                case "ABM de Cliente":
                Abm_Cliente.frm_abmCliente cli = new Abm_Cliente.frm_abmCliente(usuarioActual, rolActual);
                cli.Show();
                break;

                case "ABM de Empresa":
                Abm_Empresa_Espectaculo.frm_abmEmpresa emp = new Abm_Empresa_Espectaculo.frm_abmEmpresa(usuarioActual, rolActual);
                emp.Show();
                break;

                case "ABM de Rubro":
                Abm_Rubro.frm_abmRubro rub = new Abm_Rubro.frm_abmRubro();
                rub.Show();
                break;

                case "ABM de Grado de Publicación":
                Abm_Grado.frm_abmGradoDePublicacion gdp = new Abm_Grado.frm_abmGradoDePublicacion();
                gdp.Show();
                break;

                case "Generar Publicación":
                Generar_Publicacion.frm_generarPublicacion gp = new Generar_Publicacion.frm_generarPublicacion(usuarioActual, rolActual);
                gp.Show();
                break;

                case "Editar Publicación":
                Editar_Publicacion.frm_editarPublicacion ep = new Editar_Publicacion.frm_editarPublicacion();
                ep.Show();
                break;

                case "Comprar":
                Comprar.frm_comprar comp = new Comprar.frm_comprar(usuarioActual, rolActual);
                comp.Show();
                break;

                case "Historial del Cliente":
                Historial_Cliente.frm_historialDelCliente hdc = new Historial_Cliente.frm_historialDelCliente(usuarioActual, rolActual);
                hdc.Show();
                break;

                case "Canje y Administración de Puntos":
                Canje_Puntos.frm_canjeYAdministracionDePuntos punt = new Canje_Puntos.frm_canjeYAdministracionDePuntos(usuarioActual);
                punt.Show();
                break;

                case "Generar Pago de Comisiones":
                Generar_Rendicion_Comisiones.frm_generarPagoDeComisiones pc = new Generar_Rendicion_Comisiones.frm_generarPagoDeComisiones();
                pc.Show();
                break;

                case "Listado Estadístico":
                Listado_Estadistico.frm_listadoEstadistico le = new Listado_Estadistico.frm_listadoEstadistico();
                le.Show();
                break;

                default:
                break;
             }
        }
    }
}
